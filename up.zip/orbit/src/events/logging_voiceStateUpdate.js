const { EmbedBuilder, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        if (!newState.guild) return;

        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[newState.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (guildConfig.ignores?.includes(`voice_${oldState.channelId}`)) return;
            if (guildConfig.ignores?.includes(`voice_${newState.channelId}`)) return;

            const logChannel = guildConfig.channels?.voice || guildConfig.channels?.server;
            if (!logChannel) return;

            const channel = newState.guild.channels.cache.get(logChannel);
            if (!channel) return;

            const member = newState.member;
            let action = '';
            let color = '#808080';

            if (!oldState.channelId && newState.channelId) {
                action = `📞 Joined voice channel ${newState.channel}`;
                color = '#00ff00';
            } else if (oldState.channelId && !newState.channelId) {
                action = `📴 Left voice channel ${oldState.channel}`;
                color = '#ff0000';
            } else if (oldState.channelId !== newState.channelId) {
                action = `🔄 Switched from ${oldState.channel} to ${newState.channel}`;
                color = '#ffa500';
            } else {
                // Mute/deafen changes
                if (oldState.serverMute !== newState.serverMute) {
                    action = newState.serverMute ? '🔇 Server Muted' : '🔊 Server Unmuted';
                } else if (oldState.serverDeaf !== newState.serverDeaf) {
                    action = newState.serverDeaf ? '🔇 Server Deafened' : '🔊 Server Undeafened';
                } else if (oldState.selfMute !== newState.selfMute) {
                    action = newState.selfMute ? '🔇 Self Muted' : '🔊 Self Unmuted';
                } else if (oldState.selfDeaf !== newState.selfDeaf) {
                    action = newState.selfDeaf ? '🔇 Self Deafened' : '🔊 Self Undeafened';
                } else {
                    return; // Other changes we don't log
                }
                color = '#808080';
            }

            const embed = new EmbedBuilder()
                .setTitle('🎤 Voice State Update')
                .setColor(color)
                .addFields(
                    { name: 'Member', value: `${member.user.tag} (${member.user.id})`, inline: true },
                    { name: 'Action', value: action }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (voiceStateUpdate):', error);
        }
    }
};
