const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildRoleDelete,
    async execute(role) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[role.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.server || guildConfig.channels?.moderation;
            if (!logChannel) return;

            const channel = role.guild.channels.cache.get(logChannel);
            if (!channel) return;

            let executor = null;

            try {
                const auditLogs = await role.guild.fetchAuditLogs({
                    type: AuditLogEvent.RoleDelete,
                    limit: 1
                });
                const deleteLog = auditLogs.entries.first();
                if (deleteLog && deleteLog.target.id === role.id) {
                    executor = deleteLog.executor;
                }
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setTitle('🗑️ Role Deleted')
                .setColor('#ff0000')
                .addFields(
                    { name: 'Role Name', value: role.name, inline: true },
                    { name: 'ID', value: role.id, inline: true },
                    { name: 'Deleted By', value: executor ? `${executor.tag}` : 'Unknown' }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (roleDelete):', error);
        }
    }
};
