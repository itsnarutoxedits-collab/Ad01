const { Events, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const welcomeManager = require('../functions/welcomeManager');
const Canvas = require('canvas');
const path = require('path');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        if (member.user.bot) return; // Optional: Ignore bots? Usually welcomers welcome bots too. Let's keep it open.

        const guildId = member.guild.id;
        const data = welcomeManager.getGuildData(guildId);

        // --- JOIN DM ---
        if (data.joindm && data.joindm.enabled && data.joindm.message) {
            const msg = data.joindm.message
                .replace(/{user}/g, member.user.username)
                .replace(/{server}/g, member.guild.name)
                .replace(/{count}/g, member.guild.memberCount);

            try {
                await member.send(msg);
            } catch (e) {
                // User has DMs closed
            }
        }

        // --- WELCOME CHANNEL ---
        if (data.welcome && data.welcome.enabled && data.welcome.channel) {
            const channel = member.guild.channels.cache.get(data.welcome.channel);
            if (channel) {
                const replacements = (str) => {
                    if (!str) return '';
                    return str
                        .replace(/{user}/g, `<@${member.id}>`)
                        .replace(/{server}/g, member.guild.name)
                        .replace(/{count}/g, member.guild.memberCount);
                };

                const content = replacements(data.welcome.message);
                const embeds = [];
                const files = [];

                // --- CARD GENERATION ---
                if (data.welcome.card) {
                    try {
                        const canvas = Canvas.createCanvas(700, 250);
                        const ctx = canvas.getContext('2d');

                        // Background
                        // For now simple gradient if no bg image configured (feature scope limit)
                        const grd = ctx.createLinearGradient(0, 0, 700, 250);
                        grd.addColorStop(0, '#1a1a1a');
                        grd.addColorStop(1, '#2b2d31');
                        ctx.fillStyle = grd;
                        ctx.fillRect(0, 0, 700, 250);

                        // Circle Avatar
                        ctx.save();
                        ctx.beginPath();
                        ctx.arc(125, 125, 80, 0, Math.PI * 2, true);
                        ctx.closePath();
                        ctx.clip();

                        const avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 256 });
                        const avatar = await Canvas.loadImage(avatarURL);
                        ctx.drawImage(avatar, 45, 45, 160, 160);
                        ctx.restore();

                        // Border
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 5;
                        ctx.beginPath();
                        ctx.arc(125, 125, 80, 0, Math.PI * 2, true);
                        ctx.stroke();

                        // Text
                        ctx.fillStyle = '#ffffff';
                        ctx.font = 'bold 45px sans-serif'; // Default system font
                        ctx.fillText('WELCOME', 250, 110);

                        ctx.font = '30px sans-serif';
                        ctx.fillText(member.user.username, 250, 160);

                        ctx.fillStyle = '#aaaaaa';
                        ctx.font = '20px sans-serif';
                        ctx.fillText(`Member #${member.guild.memberCount}`, 250, 200);

                        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'welcome-card.png' });
                        files.push(attachment);
                    } catch (e) {
                        console.error('Welcome Card Error:', e);
                    }
                }

                // --- EMBED GENERATION ---
                if (data.welcome.embed) {
                    const eData = data.welcome.embed;
                    const embed = new EmbedBuilder();
                    if (eData.title) embed.setTitle(replacements(eData.title));
                    if (eData.desc) embed.setDescription(replacements(eData.desc));
                    if (eData.color) embed.setColor(eData.color);
                    if (eData.image) embed.setImage(eData.image);
                    if (eData.thumbnail) embed.setThumbnail(eData.thumbnail);
                    else if (data.welcome.card) embed.setImage('attachment://welcome-card.png'); // Use card as image if embed exists and no explicit image

                    // If embed exists, push it
                    if (eData.title || eData.desc) embeds.push(embed);
                }

                // Sending
                const payload = {};
                if (content && content !== 'null') payload.content = content;
                if (embeds.length > 0) payload.embeds = embeds;
                if (files.length > 0) payload.files = files;

                if (payload.content || payload.embeds || payload.files) {
                    await channel.send(payload).catch(e => console.error('Welcome Send Error:', e));
                }
            }
        }
    }
};
