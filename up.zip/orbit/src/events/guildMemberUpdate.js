const { Events, EmbedBuilder } = require('discord.js');
const welcomeManager = require('../functions/welcomeManager');

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        // Boost Detection: Old has no premiumSince, New has premiumSince
        if (!oldMember.premiumSince && newMember.premiumSince) {
            const guildId = newMember.guild.id;
            const data = welcomeManager.getGuildData(guildId);

            if (data.boost && data.boost.enabled && data.boost.channel) {
                const channel = newMember.guild.channels.cache.get(data.boost.channel);
                if (channel) {
                    const msg = (data.boost.message || 'Thank you for boosting!')
                        .replace(/{user}/g, `<@${newMember.id}>`)
                        .replace(/{server}/g, newMember.guild.name)
                        .replace(/{count}/g, newMember.guild.premiumSubscriptionCount);

                    await channel.send({ content: msg, embeds: [new EmbedBuilder().setDescription(`🚀 **${newMember.user.tag}** just boosted the server!`).setColor('#f47fff')] }).catch(() => { });
                }
            }
        }
    }
};
