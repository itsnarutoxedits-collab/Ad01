const { Events, EmbedBuilder } = require('discord.js');
const welcomeManager = require('../functions/welcomeManager');

module.exports = {
    name: Events.GuildMemberRemove,
    async execute(member) {
        if (member.user.bot) return;

        const guildId = member.guild.id;
        const data = welcomeManager.getGuildData(guildId);

        if (data.leave && data.leave.enabled && data.leave.channel) {
            const channel = member.guild.channels.cache.get(data.leave.channel);
            if (channel) {
                constreplacements = (str) => {
                    if (!str) return '';
                    return str
                        .replace(/{user}/g, member.user.tag) // No mention on leave
                        .replace(/{server}/g, member.guild.name)
                        .replace(/{count}/g, member.guild.memberCount);
                };

                const msg = replacements(data.leave.message);
                const embeds = [];

                if (data.leave.embed && data.leave.embed.desc) {
                    const embed = new EmbedBuilder()
                        .setDescription(replacements(data.leave.embed.desc))
                        .setColor('Red');
                    embeds.push(embed);
                }

                if (msg || embeds.length > 0) {
                    await channel.send({ content: msg || null, embeds: embeds }).catch(() => { });
                }
            }
        }
    }
};
