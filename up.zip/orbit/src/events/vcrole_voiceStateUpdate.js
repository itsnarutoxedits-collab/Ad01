const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/vcrole.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        // Ignore simple updates like mute/deafen that don't change channel
        if (oldState.channelId === newState.channelId) return;

        const guild = newState.guild;
        const guildId = guild.id;
        const data = getData();
        const config = data[guildId];

        if (!config) return;

        const member = newState.member;
        const roleId = member.user.bot ? config.bot : config.human;

        if (!roleId) return;

        const role = guild.roles.cache.get(roleId);
        if (!role) return;

        // 1. User LEFT a channel (or switched)
        // If old config was active, we might want to remove it.
        // Actually, VCRole logic: YOU HAVE ROLE WHILE IN VC.
        // So if they are NO LONGER in a channel (newState.channelId is null), remove it.
        // Or if they switched to a channel that DOESN'T trigger it? 
        // Current logic: One global VCRole per guild (human/bot).
        // So:
        // - In VC -> Have Role
        // - Not in VC -> Remove Role

        const isInVc = !!newState.channelId;

        if (isInVc) {
            // Add Role
            if (!member.roles.cache.has(roleId)) {
                try {
                    await member.roles.add(role);
                } catch (e) {
                    console.error(`Failed to give VC role in ${guild.name}:`, e);
                }
            }
        } else {
            // Remove Role
            if (member.roles.cache.has(roleId)) {
                try {
                    await member.roles.remove(role);
                } catch (e) {
                    console.error(`Failed to remove VC role in ${guild.name}:`, e);
                }
            }
        }
    },
};
