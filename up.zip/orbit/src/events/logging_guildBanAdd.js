const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildBanAdd,
    async execute(ban) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[ban.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.moderation || guildConfig.channels?.member;
            if (!logChannel) return;

            const channel = ban.guild.channels.cache.get(logChannel);
            if (!channel) return;

            let executor = null;
            let reason = ban.reason || 'No reason provided';

            try {
                const auditLogs = await ban.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanAdd,
                    limit: 1
                });
                const banLog = auditLogs.entries.first();
                if (banLog && banLog.target.id === ban.user.id) {
                    executor = banLog.executor;
                    reason = banLog.reason || reason;
                }
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setTitle('🔨 Member Banned')
                .setColor('#ff0000')
                .setThumbnail(ban.user.displayAvatarURL())
                .addFields(
                    { name: 'User', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                    { name: 'Banned By', value: executor ? `${executor.tag}` : 'Unknown', inline: true },
                    { name: 'Reason', value: reason }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (guildBanAdd):', error);
        }
    }
};
