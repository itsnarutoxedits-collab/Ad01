const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildRoleCreate,
    async execute(role) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[role.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.server || guildConfig.channels?.moderation;
            if (!logChannel) return;

            const channel = role.guild.channels.cache.get(logChannel);
            if (!channel) return;

            let executor = null;

            try {
                const auditLogs = await role.guild.fetchAuditLogs({
                    type: AuditLogEvent.RoleCreate,
                    limit: 1
                });
                const createLog = auditLogs.entries.first();
                if (createLog && createLog.target.id === role.id) {
                    executor = createLog.executor;
                }
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setTitle('🎭 Role Created')
                .setColor(role.color || '#00ff00')
                .addFields(
                    { name: 'Role', value: `${role} (${role.name})`, inline: true },
                    { name: 'ID', value: role.id, inline: true },
                    { name: 'Color', value: role.hexColor, inline: true },
                    { name: 'Created By', value: executor ? `${executor.tag}` : 'Unknown' }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (roleCreate):', error);
        }
    }
};
