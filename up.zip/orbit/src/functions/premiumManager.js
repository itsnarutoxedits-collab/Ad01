const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'premium.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({ users: {}, activatedGuilds: [] }), 'utf8');
}

ensureDataFile();

let store = { users: {}, activatedGuilds: [] };
try {
    const raw = fs.readFileSync(DATA_PATH, 'utf8');
    const parsed = JSON.parse(raw);

    // Migration check: if 'users' is an array, convert to object
    if (Array.isArray(parsed.users)) {
        const newUsers = {};
        parsed.users.forEach(id => {
            newUsers[id] = {
                expires: Date.now() + (365 * 24 * 60 * 60 * 1000), // Default 1 year for legacy
                count: 5, // Default 5 keys for legacy
                maxKeys: 5
            };
        });
        store = { users: newUsers, activatedGuilds: parsed.guilds || [] };
        console.log('Migrated Premium JSON structure.');
        saveStore();
    } else {
        store = parsed;
    }
} catch (e) {
    store = { users: {}, activatedGuilds: [] };
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

/**
 * Add or extend premium for a user
 * @param {string} userId 
 * @param {number} durationDays 
 * @param {number} count Max server count (keys)
 */
function addPremiumUser(userId, durationDays, count) {
    const durationMs = durationDays * 24 * 60 * 60 * 1000;
    const now = Date.now();

    if (!store.users[userId]) {
        store.users[userId] = {
            expires: now + durationMs,
            count: 0, // Keys used
            maxKeys: count
        };
    } else {
        // Extend time if not expired, or set new if expired
        const currentExp = store.users[userId].expires;
        if (currentExp > now) {
            store.users[userId].expires = currentExp + durationMs;
        } else {
            store.users[userId].expires = now + durationMs;
        }
        // Update limits
        store.users[userId].maxKeys = count;
    }
    saveStore();
    return store.users[userId];
}

function removePremiumUser(userId) {
    if (store.users[userId]) {
        delete store.users[userId];

        // Deactivate all guilds activated by this user?
        // Logic: Bitzxier usually keeps them until expiry or manual remove.
        // For strictness, we should remove them.
        store.activatedGuilds = store.activatedGuilds.filter(g => g.activatedBy !== userId);

        saveStore();
        return true;
    }
    return false;
}

function getPremiumUser(userId) {
    if (!store.users[userId]) return null;
    const data = store.users[userId];
    // We do NOT auto-expire here anymore to allow messageCreate to handle notification first.
    // Or we keep it lazy but rely on checkExpiration for the notification event.
    // Let's keep strict lazy expiry here for safety, but checkExpiration will be called first.
    if (Date.now() > data.expires) {
        removePremiumUser(userId);
        return null;
    }
    return data;
}

/**
 * Check if a user or guild has expired premium and return details for notification
 */
function checkExpiry(userId, guildId) {
    const result = { userExpired: false, guildExpired: false, data: null };

    // Check User Expiry
    if (store.users[userId]) {
        if (Date.now() > store.users[userId].expires) {
            result.userExpired = true;
            result.data = { ...store.users[userId] };
            removePremiumUser(userId); // Cleanup
        }
    }

    // Check Guild Expiry (activated by this user or just generally for the guild?)
    // Bitzxier checks if the GUILD's premium (provided by anyone) has expired.
    // Orbit binds guild activation to a user.
    // We should check if the guild is activated, and if the activator's sub has expired.
    // If so, we flag it.

    const guildPrem = store.activatedGuilds.find(g => g.id === guildId);
    if (guildPrem) {
        const activator = store.users[guildPrem.activatedBy];
        // If activator is gone or expired
        if (!activator || Date.now() > activator.expires) {
            result.guildExpired = true;
            // cleanup handled by removePremiumUser or explicitly here?
            // removePremiumUser cleans up their guilds.
            // If activator is missing (already cleaned), it's expired.
            // But if we just cleaned it in the block above, we are good.
            // If activator was someone else and they expired, we need to clean.

            if (!activator) {
                // Already gone, just remove guild record
                deactivateGuild(guildId, null);
            } else if (Date.now() > activator.expires) {
                // Expired but not cleaned yet (e.g. different user triggered this check)
                removePremiumUser(guildPrem.activatedBy);
            }
        }
    }

    return result;
}

/**
 * Activate premium for a guild using a user's key
 * @param {string} guildId 
 * @param {string} userId 
 */
function activateGuild(guildId, userId) {
    const user = getPremiumUser(userId);
    if (!user) return { success: false, message: 'You do not have premium.' };

    if (user.count >= user.maxKeys) return { success: false, message: 'You have used all your premium keys.' };

    const existing = store.activatedGuilds.find(g => g.id === guildId);
    if (existing) return { success: false, message: 'This server is already premium.' };

    // Activate
    user.count++;
    store.activatedGuilds.push({
        id: guildId,
        activatedBy: userId,
        activatedAt: Date.now()
    });
    saveStore();
    return { success: true };
}

/**
 * Deactivate premium for a guild
 * @param {string} guildId 
 * @param {string} userId Requesting user (must be the activator or global owner)
 */
function deactivateGuild(guildId, userId) {
    const index = store.activatedGuilds.findIndex(g => g.id === guildId);
    if (index === -1) return { success: false, message: 'This server is not premium.' };

    const data = store.activatedGuilds[index];

    // Check ownership of key
    // If userId provided, verify match (unless forcefully by admin, handled outside)
    if (userId && data.activatedBy !== userId) return { success: false, message: 'You did not activate premium on this server.' };

    // Restore key to user
    const user = store.users[data.activatedBy]; // Don't check expiry here, just decrement count
    if (user) {
        user.count = Math.max(0, user.count - 1);
    }

    store.activatedGuilds.splice(index, 1);
    saveStore();
    return { success: true };
}

function isGuildPremium(guildId) {
    const data = store.activatedGuilds.find(g => g.id === guildId);
    if (!data) return false;

    // Check if activator is still valid
    const user = getPremiumUser(data.activatedBy);
    if (!user) {
        // Activator expired, remove guild
        deactivateGuild(guildId, null);
        return false;
    }
    return true;
}

function getStats() {
    const now = Date.now();
    // Prune expired on stat check (lazy)
    const activeUsers = Object.keys(store.users).filter(k => store.users[k].expires > now).length;
    return {
        users: activeUsers,
        guilds: store.activatedGuilds.length
    };
}

module.exports = {
    addPremiumUser,
    removePremiumUser,
    getPremiumUser,
    activateGuild,
    deactivateGuild,
    isGuildPremium,
    getStats,
    checkExpiry,
    redeemTrial,
    transferPremium
};

/**
 * Redeem 3-day trial for a user
 * @param {string} userId 
 */
function redeemTrial(userId) {
    if (store.users[userId] && store.users[userId].usedTrial) {
        return { success: false, message: 'You have already used your trial.' };
    }

    // Create new or extend
    const durationMs = 3 * 24 * 60 * 60 * 1000; // 3 Days Trial
    const now = Date.now();

    if (!store.users[userId]) {
        store.users[userId] = {
            expires: now + durationMs,
            count: 0,
            maxKeys: 1, // Trial gives 1 key
            usedTrial: true
        };
    } else {
        // Existing user claiming trial? Usually only for new.
        // Let's allow only if they have no active sub?
        if (store.users[userId].expires > now) {
            // Extend
            store.users[userId].expires += durationMs;
            store.users[userId].usedTrial = true;
        } else {
            // Reactivate
            store.users[userId].expires = now + durationMs;
            store.users[userId].maxKeys = 1;
            store.users[userId].usedTrial = true;
        }
    }
    saveStore();
    return { success: true, expires: store.users[userId].expires };
}

/**
 * Transfer premium from one user to another
 * @param {string} fromId 
 * @param {string} toId 
 */
function transferPremium(fromId, toId) {
    const sender = store.users[fromId];
    if (!sender || sender.expires < Date.now()) return { success: false, message: 'You do not have an active premium subscription.' };

    const recipient = store.users[toId];
    if (recipient && recipient.expires > Date.now()) return { success: false, message: 'Target user already has premium. Cannot stack transfers.' };

    // Move to recipient
    store.users[toId] = {
        expires: sender.expires,
        count: 0, // Reset usages for new owner? Bitzxier parity: Transfer moves the "Subscription". Keys are usually reset or transferred. Let's reset count (fresh start).
        maxKeys: sender.maxKeys,
        usedTrial: sender.usedTrial || false
    };

    // Remove from sender
    delete store.users[fromId];
    // Deactivate sender's guilds?
    // Proper transfer implies moving the "rights".
    // We should probably deactivate sender's guilds or warn them.
    // For simplicity, we aggressively deactivate sender's guilds so they can't exploit.
    store.activatedGuilds = store.activatedGuilds.filter(g => g.activatedBy !== fromId);

    saveStore();
    return { success: true, expires: store.users[toId].expires };
}
