const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'welcome.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
} catch (e) {
    store = {};
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function getGuildData(guildId) {
    if (!store[guildId]) {
        store[guildId] = {
            welcome: { enabled: false, channel: null, message: null, embed: null, card: false },
            leave: { enabled: false, channel: null, message: null, embed: null },
            joindm: { enabled: false, message: null },
            boost: { enabled: false, channel: null, message: null }
        };
        saveStore();
    }
    return store[guildId];
}

function updateGuildData(guildId, section, key, value) {
    const data = getGuildData(guildId);
    if (data[section]) {
        if (key === null) {
            // Replace entire object if needed, but usually key updates
            // If key is null, we assume value is the new object (rare)
        } else {
            data[section][key] = value;
        }
        saveStore();
        return true;
    }
    return false;
}

function setWelcome(guildId, changes) {
    const data = getGuildData(guildId);
    data.welcome = { ...data.welcome, ...changes };
    saveStore();
}

function setLeave(guildId, changes) {
    const data = getGuildData(guildId);
    data.leave = { ...data.leave, ...changes };
    saveStore();
}

function setJoinDm(guildId, changes) {
    const data = getGuildData(guildId);
    data.joindm = { ...data.joindm, ...changes };
    saveStore();
}

function setBoost(guildId, changes) {
    const data = getGuildData(guildId);
    data.boost = { ...data.boost, ...changes };
    saveStore();
}

module.exports = {
    getGuildData,
    updateGuildData,
    setWelcome,
    setLeave,
    setJoinDm,
    setBoost
};
