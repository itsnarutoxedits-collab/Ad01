const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'permits.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
} catch (e) {
    store = {};
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function getGuildData(guildId) {
    if (!store[guildId]) {
        store[guildId] = {
            extraOwners: [],
            trusted: [],
            ignore_bypass: [],
            ignore_command: [],
            ignore_role: [],
            ignore_channel: [],
            ignore_user: [],
            topcheck: false
        };
        saveStore();
    }
    return store[guildId];
}

function setFlag(guildId, flagName, value) {
    const data = getGuildData(guildId);
    data[flagName] = value;
    saveStore();
}

function getFlag(guildId, flagName) {
    return getGuildData(guildId)[flagName] || false;
}

function addEntry(guildId, listName, userId) {
    const data = getGuildData(guildId);
    if (!data[listName]) data[listName] = [];
    if (!data[listName].includes(userId)) {
        data[listName].push(userId);
        saveStore();
        return true;
    }
    return false;
}

function removeEntry(guildId, listName, userId) {
    const data = getGuildData(guildId);
    if (data[listName] && data[listName].includes(userId)) {
        data[listName] = data[listName].filter(id => id !== userId);
        saveStore();
        return true;
    }
    return false;
}

function resetList(guildId, listName) {
    const data = getGuildData(guildId);
    data[listName] = [];
    saveStore();
}

function getEntries(guildId, listName) {
    return getGuildData(guildId)[listName] || [];
}

function isUserInList(guildId, listName, userId) {
    return getEntries(guildId, listName).includes(userId);
}

module.exports = {
    // Legacy wrappers (optional, but good for backward compatibility if I didn't update extraowner.js yet)
    addExtraOwner: (gid, uid) => addEntry(gid, 'extraOwners', uid),
    removeExtraOwner: (gid, uid) => removeEntry(gid, 'extraOwners', uid),
    resetExtraOwners: (gid) => resetList(gid, 'extraOwners'),
    getExtraOwners: (gid) => getEntries(gid, 'extraOwners'),
    isExtraOwner: (gid, uid) => isUserInList(gid, 'extraOwners', uid),

    // Generic variants
    addEntry,
    removeEntry,
    resetList,
    getEntries,
    isUserInList,
    setFlag,
    getFlag
};
