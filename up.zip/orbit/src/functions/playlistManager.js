const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/playlists.json');

function getData() {
    if (!fs.existsSync(dataPath)) {
        fs.mkdirSync(path.dirname(dataPath), { recursive: true });
        fs.writeFileSync(dataPath, JSON.stringify({ users: {} }, null, 4));
        return { users: {} };
    }
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
}

function getUserPlaylists(userId) {
    const data = getData();
    return data.users[userId] ? data.users[userId].playlists : {};
}

function createPlaylist(userId, name) {
    const data = getData();
    if (!data.users[userId]) data.users[userId] = { playlists: {} };

    if (data.users[userId].playlists[name]) return false; // Already exists

    data.users[userId].playlists[name] = [];
    setData(data);
    return true;
}

function deletePlaylist(userId, name) {
    const data = getData();
    if (!data.users[userId] || !data.users[userId].playlists[name]) return false;

    delete data.users[userId].playlists[name];
    setData(data);
    return true;
}

function addSong(userId, name, song) {
    const data = getData();
    if (!data.users[userId]) data.users[userId] = { playlists: {} };
    if (!data.users[userId].playlists[name]) {
        // Auto-create if not exists (useful for 'Liked Songs')
        data.users[userId].playlists[name] = [];
    }

    // Song object: { name, url, duration, etc. }
    data.users[userId].playlists[name].push({
        name: song.name,
        url: song.url,
        duration: song.formattedDuration || song.duration,
        thumbnail: song.thumbnail
    });
    setData(data);
    return true;
}

function removeSong(userId, name, index) {
    const data = getData();
    if (!data.users[userId] || !data.users[userId].playlists[name]) return false;
    if (index < 0 || index >= data.users[userId].playlists[name].length) return false;

    data.users[userId].playlists[name].splice(index, 1);
    setData(data);
    return true;
}

function getPlaylist(userId, name) {
    const data = getData();
    if (!data.users[userId] || !data.users[userId].playlists[name]) return null;
    return data.users[userId].playlists[name];
}

function renamePlaylist(userId, oldName, newName) {
    const data = getData();
    if (!data.users[userId] || !data.users[userId].playlists[oldName]) return false;
    if (data.users[userId].playlists[newName]) return false; // Target already exists

    data.users[userId].playlists[newName] = data.users[userId].playlists[oldName];
    delete data.users[userId].playlists[oldName];
    setData(data);
    return true;
}

module.exports = {
    getUserPlaylists,
    createPlaylist,
    deletePlaylist,
    addSong,
    removeSong,
    getPlaylist,
    renamePlaylist
};
