const fs = require('fs');
const path = require('path');
const { PermissionFlagsBits } = require('discord.js');

const dataPath = path.join(__dirname, '../../data/customrole.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

function ensureGuildData(data, guildId) {
    if (!data[guildId]) {
        data[guildId] = {
            reqroles: [],
            static: {
                staff: null,
                vip: null,
                guest: null,
                friend: null,
                girl: null
            },
            dynamic: []
        };
    }
    // Migration checks
    if (!data[guildId].static) {
        data[guildId].static = { staff: null, vip: null, guest: null, friend: null, girl: null };
    }
    if (!Array.isArray(data[guildId].reqroles)) {
        const old = data[guildId].reqrole;
        data[guildId].reqroles = old ? [old] : [];
        delete data[guildId].reqrole;
    }
    if (!Array.isArray(data[guildId].dynamic)) {
        if (data[guildId].names && data[guildId].roles) {
            data[guildId].dynamic = data[guildId].names.map((n, i) => ({ name: n, role: data[guildId].roles[i] }));
            delete data[guildId].names;
            delete data[guildId].roles;
        } else {
            data[guildId].dynamic = [];
        }
    }
    return data;
}

function getGuildConfig(guildId) {
    let data = getData();
    data = ensureGuildData(data, guildId);
    return data[guildId]; // Returns reference, but be careful with writes
}

function saveGuildConfig(guildId, config) {
    let data = getData();
    data = ensureGuildData(data, guildId);
    data[guildId] = config;
    setData(data);
}

function checkPermission(member, guildId) {
    // 1. Manage Roles
    if (member.permissions.has(PermissionFlagsBits.ManageRoles)) return true;

    // 2. Reqroles
    const config = getGuildConfig(guildId);
    if (config.reqroles.length > 0) {
        // If user has ANY of the req roles
        if (member.roles.cache.some(r => config.reqroles.includes(r.id))) return true;
    } else {
        // If no req roles set, usually defaults to Admin/ManageRoles only for setup, 
        // but for *using* static commands (like !staff), Bitzxier often allows public if reqrole is set? 
        // Actually, typically !staff !vip etc are admin/mod commands.
        // If reqrole is empty, stick to ManageRoles check above.
    }
    return false;
}

module.exports = {
    getData,
    setData,
    ensureGuildData,
    getGuildConfig,
    saveGuildConfig,
    checkPermission
};
