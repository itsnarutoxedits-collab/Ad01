const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'stats.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

// In-memory cache to reduce disk I/O
let stats = {};
try {
    stats = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
} catch (e) {
    stats = {};
}

// Save interval (every 1 minute)
setInterval(() => {
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(stats, null, 2));
    } catch (e) {
        console.error('Failed to save stats.json', e);
    }
}, 60 * 1000);

function getGuildStats(guildId) {
    if (!stats[guildId]) {
        stats[guildId] = {
            messages: {}, // userId: { total: 0, daily: 0, lastUpdated: timestamp }
            voice: {}     // userId: { total: 0, daily: 0, joinTime: null, lastUpdated: timestamp }
        };
    }
    return stats[guildId];
}

/* --- MESSAGES --- */

function addMessage(guildId, userId) {
    const gStats = getGuildStats(guildId);
    if (!gStats.messages[userId]) {
        gStats.messages[userId] = { total: 0, daily: 0, lastUpdated: Date.now() };
    }

    const userStats = gStats.messages[userId];
    checkDailyReset(userStats);

    userStats.total++;
    userStats.daily++;
    userStats.lastUpdated = Date.now();

    // Auto-save on every message? No, use Interval.
}

/* --- VOICE --- */

function voiceJoin(guildId, userId) {
    const gStats = getGuildStats(guildId);
    if (!gStats.voice[userId]) {
        gStats.voice[userId] = { total: 0, daily: 0, joinTime: null, lastUpdated: Date.now() };
    }
    const userStats = gStats.voice[userId];
    userStats.joinTime = Date.now();
}

function voiceLeave(guildId, userId) {
    const gStats = getGuildStats(guildId);
    const userStats = gStats.voice[userId];

    if (!userStats || !userStats.joinTime) return; // user wasn't tracked or somehow lost state

    const now = Date.now();
    const duration = now - userStats.joinTime;

    checkDailyReset(userStats);

    userStats.total += duration;
    userStats.daily += duration;
    userStats.joinTime = null;
    userStats.lastUpdated = now;
}

// Handling server restarts: If bot restarts while user is in VC, `joinTime` is lost from memory if we didn't save it. 
// But we save to JSON. However, 'joinTime' in JSON might be stale if bot crashed long ago.
// Bitzxier likely handles this by checking current voice states on boot. 
// We will simply rely on voiceStateUpdate for now.

function checkDailyReset(userstat) {
    const last = new Date(userstat.lastUpdated);
    const now = new Date();
    // Simple check: if day is different
    if (last.getDate() !== now.getDate() || last.getMonth() !== now.getMonth() || last.getFullYear() !== now.getFullYear()) {
        userstat.daily = 0;
    }
}

/* --- LEADERBOARD RETRIEVAL --- */

function getTopUsers(guildId, type, limit = 10) {
    // type: messages, dailymessages, voice, dailyvoice
    const gStats = getGuildStats(guildId);
    let items = [];

    if (type === 'messages') {
        items = Object.entries(gStats.messages).map(([id, data]) => ({ id, value: data.total }));
    } else if (type === 'dailymessages') {
        items = Object.entries(gStats.messages).map(([id, data]) => {
            checkDailyReset(data); // ensure fresh
            return { id, value: data.daily };
        });
    } else if (type === 'voice') {
        items = Object.entries(gStats.voice).map(([id, data]) => ({ id, value: data.total }));
    } else if (type === 'dailyvoice') {
        items = Object.entries(gStats.voice).map(([id, data]) => {
            checkDailyReset(data);
            return { id, value: data.daily };
        });
    }

    return items
        .sort((a, b) => b.value - a.value)
        .slice(0, limit);
}

function getUserStats(guildId, userId) {
    const gStats = getGuildStats(guildId);
    return gStats.messages[userId] || { total: 0, daily: 0 };
}

function setUserMessages(guildId, userId, amount) {
    const gStats = getGuildStats(guildId);
    if (!gStats.messages[userId]) {
        gStats.messages[userId] = { total: 0, daily: 0, lastUpdated: Date.now() };
    }
    gStats.messages[userId].total = amount;
    // We don't touch daily? Or set it to amount if < amount?
    // For manual set, we usually mean Total.
    saveStats(); // Immediate save for manual commands
}

function saveStats() {
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(stats, null, 2));
    } catch (e) {
        console.error('Failed to save stats.json manually', e);
    }
}

module.exports = {
    addMessage,
    voiceJoin,
    voiceLeave,
    getTopUsers,
    getUserStats,
    setUserMessages
};
