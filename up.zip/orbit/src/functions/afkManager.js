const fs = require('fs');
const path = require('path');

const afkDataPath = path.join(__dirname, '../data/afk.json');

function getAFKData() {
    if (!fs.existsSync(afkDataPath)) {
        fs.writeFileSync(afkDataPath, JSON.stringify({}));
        return {};
    }
    return JSON.parse(fs.readFileSync(afkDataPath, 'utf8'));
}

function setAFKData(data) {
    fs.writeFileSync(afkDataPath, JSON.stringify(data, null, 2));
}

function setAFK(userId, reason, timestamp) {
    const data = getAFKData();
    data[userId] = { reason, timestamp };
    setAFKData(data);
}

function removeAFK(userId) {
    const data = getAFKData();
    if (data[userId]) {
        delete data[userId];
        setAFKData(data);
        return true;
    }
    return false;
}

function getAFK(userId) {
    const data = getAFKData();
    return data[userId] || null;
}

module.exports = { setAFK, removeAFK, getAFK };
