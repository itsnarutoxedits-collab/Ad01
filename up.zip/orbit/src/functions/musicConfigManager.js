const fs = require('fs');
const path = require('path');
const { PermissionFlagsBits } = require('discord.js');

const dataPath = path.join(__dirname, '../../data/music.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

function getGuildConfig(guildId) {
    let data = getData();
    if (!data[guildId]) {
        data[guildId] = {
            djRoles: [],
            alwaysOn: { enabled: false, channelId: null },
            sources: [], // empty = all allowed
            djMix: false // not sure what this does yet, placeholder
        };
    }
    return data[guildId];
}

function saveGuildConfig(guildId, config) {
    let data = getData();
    data[guildId] = config;
    setData(data);
}

function checkDjPermission(member) {
    if (member.permissions.has(PermissionFlagsBits.ManageChannels)) return true;
    const config = getGuildConfig(member.guild.id);
    if (config.djRoles.length > 0) {
        if (member.roles.cache.some(r => config.djRoles.includes(r.id))) return true;
    } else {
        // If no DJ roles set, maybe allow everyone? Or just ManageChannels?
        // Usually music bots allow everyone to play, but 'force' commands need DJ.
        // Let's assume this check is for DJ-only commands.
    }
    return false;
}

module.exports = {
    getGuildConfig,
    saveGuildConfig,
    checkDjPermission
};
