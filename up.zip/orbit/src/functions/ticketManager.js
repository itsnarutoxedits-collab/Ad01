const fs = require('fs');
const path = require('path');
const { ChannelType, PermissionFlagsBits, EmbedBuilder, AttachmentBuilder } = require('discord.js');

const DATA_PATH = path.join(__dirname, '..', 'data', 'tickets.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
} catch (e) {
    store = {};
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function getGuildData(guildId) {
    if (!store[guildId]) {
        store[guildId] = {
            panels: [],
            tickets: [],
            settings: {
                transcriptChannel: null,
                maxTickets: 1
            }
        };
        saveStore();
    }
    // Ensure structure integrity for existing data
    if (!store[guildId].panels) store[guildId].panels = [];
    if (!store[guildId].tickets) store[guildId].tickets = [];
    if (!store[guildId].settings) {
        store[guildId].settings = {
            transcriptChannel: null,
            loggingChannel: null,
            maxTickets: 1,
            supportRoles: [],
            greetMessage: 'Welcome {user}! Support will be with you shortly.',
            autoTranscript: true
        };
    }
    // Ensure all keys exist
    const s = store[guildId].settings;
    if (s.loggingChannel === undefined) s.loggingChannel = null;
    if (s.supportRoles === undefined) s.supportRoles = [];
    if (s.greetMessage === undefined) s.greetMessage = 'Welcome {user}! Support will be with you shortly.';
    if (s.autoTranscript === undefined) s.autoTranscript = true;

    return store[guildId];
}

/* --- Panel Management --- */

function createPanel(guildId, panelData) {
    const data = getGuildData(guildId);
    const id = (data.panels.length + 1).toString();
    const newPanel = {
        id,
        name: panelData.name,
        channelId: panelData.channelId, // Where the panel message is sent
        categoryId: panelData.categoryId, // Where tickets are created
        messageId: panelData.messageId,
        supportRoles: panelData.supportRoles || [],
        logChannelId: panelData.logChannelId || null,
        enabled: true,
        buttonLabel: panelData.buttonLabel || 'Open Ticket',
        buttonEmoji: panelData.buttonEmoji || '🎫',
        buttonStyle: panelData.buttonStyle || 'Primary',
        messageTitle: panelData.messageTitle || 'Support Tickets',
        messageDesc: panelData.messageDesc || 'Click the button below to open a ticket.'
    };
    data.panels.push(newPanel);
    saveStore();
    return newPanel;
}

function getPanel(guildId, panelId) {
    const data = getGuildData(guildId);
    return data.panels.find(p => p.id === panelId);
}

function deletePanel(guildId, panelId) {
    const data = getGuildData(guildId);
    const idx = data.panels.findIndex(p => p.id === panelId);
    if (idx > -1) {
        data.panels.splice(idx, 1);
        saveStore();
        return true;
    }
    return false;
}

function getAllPanels(guildId) {
    return getGuildData(guildId).panels;
}

/* --- Ticket Management --- */

async function createTicket(guild, user, panelId) {
    const data = getGuildData(guild.id);
    const panel = data.panels.find(p => p.id === panelId);

    if (!panel || !panel.enabled) return { success: false, message: 'Panel unavailable.' };

    // Check limits
    const existing = data.tickets.filter(t => t.userId === user.id && t.status === 'open');
    if (existing.length >= (data.settings.maxTickets || 1)) {
        return { success: false, message: `You reach the limit of ${data.settings.maxTickets} open ticket(s).` };
    }

    // Permission Overwrites
    const overwrites = [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: guild.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageChannels] }
    ];

    if (panel.supportRoles) {
        panel.supportRoles.forEach(rId => {
            overwrites.push({
                id: rId,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
            });
        });
    }

    try {
        const channel = await guild.channels.create({
            name: `ticket-${user.username}`,
            type: ChannelType.GuildText,
            parent: panel.categoryId,
            permissionOverwrites: overwrites,
            topic: `Ticket for ${user.tag} | Panel: ${panel.name}`
        });

        const ticket = {
            channelId: channel.id,
            userId: user.id,
            panelId: panel.id,
            status: 'open',
            createdAt: Date.now()
        };
        data.tickets.push(ticket);
        saveStore();

        return { success: true, channel, ticket, panel };
    } catch (err) {
        console.error('Create Ticket Error:', err);
        return { success: false, message: 'Failed to create channel. Check permissions.' };
    }
}

function getTicket(guildId, channelId) {
    const data = getGuildData(guildId);
    return data.tickets.find(t => t.channelId === channelId);
}

async function closeTicket(guild, channelId, closedBy, reason) {
    const data = getGuildData(guild.id);
    const ticketIdx = data.tickets.findIndex(t => t.channelId === channelId);
    if (ticketIdx === -1) return { success: false, message: 'Ticket not found.' };

    const ticket = data.tickets[ticketIdx];

    // Remove from active list
    data.tickets.splice(ticketIdx, 1);
    saveStore();

    return { success: true, ticket };
}

async function reopenTicket(guild, channelId) {
    const data = getGuildData(guild.id);
    const ticket = data.tickets.find(t => t.channelId === channelId);
    if (!ticket) return { success: false, message: 'Ticket not found.' };

    ticket.status = 'open';
    saveStore();
    return { success: true, ticket };
}

function updateSetting(guildId, key, value) {
    const data = getGuildData(guildId);
    if (data.settings[key] !== undefined) {
        data.settings[key] = value;
        saveStore();
        return true;
    }
    return false;
}

function addSupportRole(guildId, roleId) {
    const data = getGuildData(guildId);
    if (!data.settings.supportRoles.includes(roleId)) {
        data.settings.supportRoles.push(roleId);
        saveStore();
        return true;
    }
    return false;
}

function removeSupportRole(guildId, roleId) {
    const data = getGuildData(guildId);
    const idx = data.settings.supportRoles.indexOf(roleId);
    if (idx > -1) {
        data.settings.supportRoles.splice(idx, 1);
        saveStore();
        return true;
    }
    return false;
}

/* --- Utilities --- */

async function generateTranscript(channel, ticket, closedBy, reason) {
    let fetched = [];
    try {
        let lastId;
        while (true) {
            const options = { limit: 100 };
            if (lastId) options.before = lastId;
            const messages = await channel.messages.fetch(options);
            fetched.push(...messages.values());
            if (messages.size < 100) break;
            lastId = messages.last().id;
        }
        fetched = fetched.reverse(); // Chronological order
    } catch (err) { return null; }

    const lines = [
        `Server: ${channel.guild.name}`,
        `Ticket: ${channel.name}`,
        `Owner: ${ticket.userId}`,
        `Closed By: ${closedBy.tag}`,
        `Reason: ${reason}`,
        `----------------------------------------`
    ];

    fetched.forEach(m => {
        const time = new Date(m.createdTimestamp).toLocaleString();
        const content = m.cleanContent.replace(/\n/g, '\n\t');
        lines.push(`[${time}] ${m.author.tag}: ${content}`);
        if (m.attachments.size > 0) {
            lines.push(`\t[Attachments]: ${m.attachments.map(a => a.url).join(', ')}`);
        }
    });

    return Buffer.from(lines.join('\n'), 'utf8');
}

module.exports = {
    getGuildData,
    createPanel,
    getPanel,
    deletePanel,
    getAllPanels,
    createTicket,
    getTicket,
    closeTicket,
    generateTranscript,
    saveStore,
    reopenTicket,
    updateSetting,
    addSupportRole,
    removeSupportRole
};
