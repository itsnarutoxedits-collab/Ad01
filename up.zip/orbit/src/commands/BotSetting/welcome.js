const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const welcomeManager = require('../../functions/welcomeManager');
const embedHelper = require('../../functions/embedHelper');

const sharedExecute = async (interaction, type, managerFunc, sectionName) => {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [embedHelper.error('❌ Manage Guild permission required.')], ephemeral: true });
    }

    if (sub === 'channel') {
        const ch = interaction.options.getChannel('channel');
        managerFunc(guildId, { channel: ch.id, enabled: true });
        return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} channel set to ${ch}.`)] });
    }
    if (sub === 'message') {
        const msg = interaction.options.getString('content');
        managerFunc(guildId, { message: msg });
        return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} message updated.`)] });
    }
    if (sub === 'disable') {
        managerFunc(guildId, { enabled: false });
        return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} disabled.`)] });
    }
    if (sub === 'enable') {
        managerFunc(guildId, { enabled: true });
        return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} enabled.`)] });
    }
    if (sub === 'test') {
        const data = welcomeManager.getGuildData(guildId)[type];
        if (!data.enabled) return interaction.reply({ embeds: [embedHelper.warning(`${sectionName} is disabled.`)] });
        return interaction.reply({ embeds: [embedHelper.info(`**Test Configuration**\nChannel: <#${data.channel}>\nMessage: ${data.message || 'Default'}\nEmbed: ${data.embed ? 'Custom' : 'None'}`)] });
    }

    if (sub.startsWith('embed-')) {
        const key = sub.replace('embed-', '');
        const val = interaction.options.getString('value');
        const data = welcomeManager.getGuildData(guildId)[type];
        const currentEmbed = data.embed || {};

        if (key === 'clear') {
            managerFunc(guildId, { embed: null });
            return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} embed cleared.`)] });
        }

        currentEmbed[key] = val;
        managerFunc(guildId, { embed: currentEmbed });
        return interaction.reply({ embeds: [embedHelper.success(`✅ ${sectionName} embed ${key} updated.`)] });
    }

    if (sub === 'card') {
        const state = interaction.options.getBoolean('enable');
        managerFunc(guildId, { card: state });
        return interaction.reply({ embeds: [embedHelper.success(`✅ Welcome Card: **${state ? 'On' : 'Off'}**`)] });
    }
};

const sharedExecuteMessage = async (message, args, type, managerFunc, sectionName) => {
    const sub = args[0] ? args[0].toLowerCase() : 'help';
    const guildId = message.guild.id;

    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return message.reply({ embeds: [embedHelper.error('❌ Manage Guild permission required.')] });
    }

    if (sub === 'help') {
        const isEmbed = type === 'welcome' || type === 'leave';
        const isCard = type === 'welcome';
        const isChannel = type !== 'joindm';

        let desc = `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n`;
        if (isChannel) desc += `» **channel <#channel>**\n› Set channel.\n\n`;
        desc += `» **message <text>**\n› Set message.\n\n`;
        desc += `» **enable/disable**\n› Toggle system.\n\n`;
        if (type !== 'joindm') desc += `» **test**\n› Test configuration.\n\n`;

        if (isEmbed) {
            desc += `» **embed-desc <text>**\n› Set Embed Description.\n\n`;
            if (type === 'welcome') {
                desc += `» **embed-title <text>**\n› Set Embed Title.\n\n`;
                desc += `» **embed-image <url>**\n› Set Embed Image.\n\n`;
                desc += `» **embed-thumbnail <url>**\n› Set Thumbnail.\n\n`;
                desc += `» **embed-color <hex>**\n› Set Color.\n\n`;
                desc += `» **embed-clear**\n› Clear Embed.\n\n`;
            }
        }
        if (isCard) desc += `» **card <on/off>**\n› Toggle Welcome Card.\n\n`;

        const embed = new EmbedBuilder().setTitle(`${sectionName} Configuration`)
            .setDescription(desc)
            .setColor('#2b2d31')
            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
        return message.reply({ embeds: [embed] });
    }

    if (sub === 'channel') {
        if (type === 'joindm') return;
        const ch = message.mentions.channels.first();
        if (!ch) return message.reply({ embeds: [embedHelper.error('Please mention a channel.')] });
        managerFunc(guildId, { channel: ch.id, enabled: true });
        return message.reply({ embeds: [embedHelper.success(`✅ ${sectionName} channel set to ${ch}.`)] });
    }

    if (sub === 'message') {
        const msg = args.slice(1).join(' ');
        if (!msg) return message.reply({ embeds: [embedHelper.error('Please provide a message.')] });
        managerFunc(guildId, { message: msg });
        return message.reply({ embeds: [embedHelper.success(`✅ ${sectionName} message updated.`)] });
    }

    if (sub === 'enable' || sub === 'disable') {
        managerFunc(guildId, { enabled: sub === 'enable' });
        return message.reply({ embeds: [embedHelper.success(`✅ ${sectionName} ${sub}d.`)] });
    }

    if (sub === 'test') {
        if (type === 'joindm') return;
        const data = welcomeManager.getGuildData(guildId)[type];
        if (!data.enabled) return message.reply({ embeds: [embedHelper.warning(`${sectionName} is disabled.`)] });
        return message.reply({ embeds: [embedHelper.info(`**Test Configuration**\nChannel: <#${data.channel}>\nMessage: ${data.message || 'Default'}\nEmbed: ${data.embed ? 'Custom' : 'None'}`)] });
    }

    if (sub.startsWith('embed-')) {
        if (type !== 'welcome' && type !== 'leave') return;
        const key = sub.replace('embed-', '');

        if (key === 'clear') {
            managerFunc(guildId, { embed: null });
            return message.reply({ embeds: [embedHelper.success(`✅ ${sectionName} embed cleared.`)] });
        }

        const val = args.slice(1).join(' ');
        if (!val) return message.reply({ embeds: [embedHelper.error(`Please provide text/url for ${key}.`)] });

        const data = welcomeManager.getGuildData(guildId)[type];
        const currentEmbed = data.embed || {};
        currentEmbed[key] = val;
        managerFunc(guildId, { embed: currentEmbed });
        return message.reply({ embeds: [embedHelper.success(`✅ ${sectionName} embed ${key} updated.`)] });
    }

    if (sub === 'card') {
        if (type !== 'welcome') return;
        const state = args[1] === 'on' || args[1] === 'true' || args[1] === 'enable';
        managerFunc(guildId, { card: state });
        return message.reply({ embeds: [embedHelper.success(`✅ Welcome Card: **${state ? 'On' : 'Off'}**`)] });
    }
};

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('welcome')
            .setDescription('Manage welcome system')
            .addSubcommand(s => s.setName('channel').setDescription('Set welcome channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true).addChannelTypes(ChannelType.GuildText)))
            .addSubcommand(s => s.setName('message').setDescription('Set message (Variables: {user}, {server}, {count})').addStringOption(o => o.setName('content').setDescription('Message').setRequired(true)))
            .addSubcommand(s => s.setName('card').setDescription('Enable/Disable welcome card image').addBooleanOption(o => o.setName('enable').setDescription('Enable?').setRequired(true)))
            .addSubcommand(s => s.setName('disable').setDescription('Disable welcome'))
            .addSubcommand(s => s.setName('enable').setDescription('Enable welcome'))
            .addSubcommand(s => s.setName('test').setDescription('Test configuration'))
            .addSubcommand(s => s.setName('embed-title').setDescription('Set Embed Title').addStringOption(o => o.setName('value').setDescription('Text').setRequired(true)))
            .addSubcommand(s => s.setName('embed-desc').setDescription('Set Embed Description').addStringOption(o => o.setName('value').setDescription('Text').setRequired(true)))
            .addSubcommand(s => s.setName('embed-color').setDescription('Set Embed Color (Hex)').addStringOption(o => o.setName('value').setDescription('Hex Code').setRequired(true)))
            .addSubcommand(s => s.setName('embed-image').setDescription('Set Embed Image URL').addStringOption(o => o.setName('value').setDescription('URL').setRequired(true)))
            .addSubcommand(s => s.setName('embed-thumbnail').setDescription('Set Embed Thumbnail URL').addStringOption(o => o.setName('value').setDescription('URL').setRequired(true)))
            .addSubcommand(s => s.setName('embed-clear').setDescription('Remove embed')),

        async execute(interaction) {
            await sharedExecute(interaction, 'welcome', welcomeManager.setWelcome, 'Welcome');
        },
        async executeMessage(message, args) {
            await sharedExecuteMessage(message, args, 'welcome', welcomeManager.setWelcome, 'Welcome');
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('leave')
            .setDescription('Manage leave system')
            .addSubcommand(s => s.setName('channel').setDescription('Set leave channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
            .addSubcommand(s => s.setName('message').setDescription('Set message').addStringOption(o => o.setName('content').setDescription('Message').setRequired(true)))
            .addSubcommand(s => s.setName('disable').setDescription('Disable leave logs'))
            .addSubcommand(s => s.setName('enable').setDescription('Enable leave logs'))
            .addSubcommand(s => s.setName('embed-desc').setDescription('Set Embed Description').addStringOption(o => o.setName('value').setDescription('Text').setRequired(true))),
        async execute(interaction) {
            await sharedExecute(interaction, 'leave', welcomeManager.setLeave, 'Leave');
        },
        async executeMessage(message, args) {
            await sharedExecuteMessage(message, args, 'leave', welcomeManager.setLeave, 'Leave');
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('boost')
            .setDescription('Manage boost greet system')
            .addSubcommand(s => s.setName('channel').setDescription('Set boost channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
            .addSubcommand(s => s.setName('message').setDescription('Set message').addStringOption(o => o.setName('content').setDescription('Message').setRequired(true)))
            .addSubcommand(s => s.setName('disable').setDescription('Disable boost greet'))
            .addSubcommand(s => s.setName('enable').setDescription('Enable boost greet')),
        async execute(interaction) {
            await sharedExecute(interaction, 'boost', welcomeManager.setBoost, 'Boost');
        },
        async executeMessage(message, args) {
            await sharedExecuteMessage(message, args, 'boost', welcomeManager.setBoost, 'Boost');
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('joindm')
            .setDescription('Manage join DM system')
            .addSubcommand(s => s.setName('message').setDescription('Set DM message').addStringOption(o => o.setName('content').setDescription('Message').setRequired(true)))
            .addSubcommand(s => s.setName('enable').setDescription('Enable Join DM'))
            .addSubcommand(s => s.setName('disable').setDescription('Disable Join DM')),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            const guildId = interaction.guild.id;
            if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content: '❌ No Access', ephemeral: true });

            if (sub === 'message') {
                welcomeManager.setJoinDm(guildId, { message: interaction.options.getString('content') });
                return interaction.reply({ embeds: [embedHelper.success('✅ Join DM message updated.')] });
            }
            if (sub === 'enable' || sub === 'disable') {
                welcomeManager.setJoinDm(guildId, { enabled: sub === 'enable' });
                return interaction.reply({ embeds: [embedHelper.success(`✅ Join DM ${sub}d.`)] });
            }
        },
        async executeMessage(message, args) {
            await sharedExecuteMessage(message, args, 'joindm', welcomeManager.setJoinDm, 'Join DM');
        }
    }
];
