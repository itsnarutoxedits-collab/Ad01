const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const permissionChecker = require('../../functions/permissionChecker');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('prefix')
        .setDescription('Manage the bot prefix for this server')
        .addSubcommand(sub => sub.setName('show').setDescription('Show current server prefix'))
        .addSubcommand(sub => sub.setName('add').setDescription('Add a custom prefix').addStringOption(opt => opt.setName('prefix').setDescription('The new prefix').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a custom prefix').addStringOption(opt => opt.setName('prefix').setDescription('The prefix to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset to default prefix')),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageGuild')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Prefix Management').setDescription(`Executed prefix subcommand: **${sub}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **prefix show**\n› Show the current server prefix.\n\n` +
                `» **prefix add**\n› Add a custom prefix.\n\n` +
                `» **prefix remove**\n› Remove a custom prefix.\n\n` +
                `» **prefix reset**\n› Reset to the default prefix.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['show', 'add', 'remove', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/prefix.json');
        
        // Ensure data directory exists
        const dataDir = path.dirname(dataPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        const defaultPrefix = process.env.PREFIX || '!';
        if (!data[guildId]) data[guildId] = { prefixes: [defaultPrefix] };

        if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
            return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can manage prefixes.')] });
        }

        if (subcommand === 'show') {
            const defaultPrefix = process.env.PREFIX || '!';
            const prefixes = data[guildId].prefixes || [defaultPrefix];
            return message.reply({ embeds: [embedHelper.default(`**Server Prefixes**: ${prefixes.map(p => `\`${p}\``).join(', ')}`)] });
        }

        if (subcommand === 'add') {
            const newPrefix = args[1];
            if (!newPrefix) return message.reply({ embeds: [embedHelper.error('❌ Usage: `?prefix add <prefix>`')] });
            if (data[guildId].prefixes.includes(newPrefix)) return message.reply('⚠️ This prefix is already added.');
            data[guildId].prefixes.push(newPrefix);
            try {
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added prefix: \`${newPrefix}\`\n**Current prefixes**: ${data[guildId].prefixes.map(p => `\`${p}\``).join(', ')}`)] });
            } catch (error) {
                console.error('Error saving prefix:', error);
                return message.reply({ embeds: [embedHelper.error('❌ Failed to save prefix. Check bot permissions.')] });
            }
        }

        if (subcommand === 'remove') {
            const toRemove = args[1];
            if (!toRemove) return message.reply({ embeds: [embedHelper.error('❌ Usage: `?prefix remove <prefix>`')] });
            if (!data[guildId].prefixes.includes(toRemove)) return message.reply('⚠️ This prefix is not in the list.');
            if (data[guildId].prefixes.length === 1) return message.reply('❌ Cannot remove the last prefix!');
            data[guildId].prefixes = data[guildId].prefixes.filter(p => p !== toRemove);
            try {
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Removed prefix: \`${toRemove}\`\n**Current prefixes**: ${data[guildId].prefixes.map(p => `\`${p}\``).join(', ')}`)] });
            } catch (error) {
                console.error('Error saving prefix:', error);
                return message.reply({ embeds: [embedHelper.error('❌ Failed to save prefix. Check bot permissions.')] });
            }
        }

        if (subcommand === 'reset') {
            const defaultPrefix = process.env.PREFIX || '!';
            data[guildId] = { prefixes: [defaultPrefix] };
            try {
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Prefix has been reset to default: \`${defaultPrefix}\``)] });
            } catch (error) {
                console.error('Error saving prefix:', error);
                return message.reply({ embeds: [embedHelper.error('❌ Failed to reset prefix. Check bot permissions.')] });
            }
        }

        return message.reply({ embeds: [embedHelper.info(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/prefix ${subcommand}\``)] });
    }
};
