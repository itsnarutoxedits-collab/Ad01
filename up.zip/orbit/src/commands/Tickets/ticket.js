const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    MessageFlags
} = require('discord.js');
const ticketManager = require('../../functions/ticketManager');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Advanced Multi-Panel Ticket System')
        // Management
        .addSubcommand(sub => sub.setName('logging').setDescription('Set logging channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('greetmsg').setDescription('Set ticket greeting message').addStringOption(o => o.setName('text').setDescription('Message ({user} for mention)').setRequired(true)))
        .addSubcommand(sub => sub.setName('autotranscript').setDescription('Toggle auto-transcript').addBooleanOption(o => o.setName('enable').setDescription('Enable?').setRequired(true)))
        .addSubcommand(sub => sub.setName('maxtickets').setDescription('Max open tickets per user').addIntegerOption(o => o.setName('limit').setDescription('Limit').setRequired(true)))
        // Support Roles
        .addSubcommandGroup(g => g.setName('support').setDescription('Manage support roles')
            .addSubcommand(s => s.setName('add').setDescription('Add support role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(s => s.setName('remove').setDescription('Remove support role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(s => s.setName('list').setDescription('List support roles'))
        )
        // Ticket Operations
        .addSubcommand(sub => sub.setName('close').setDescription('Close/Archive current ticket').addStringOption(o => o.setName('reason').setDescription('Reason')))
        .addSubcommand(sub => sub.setName('reopen').setDescription('Reopen a closed ticket'))
        .addSubcommand(sub => sub.setName('delete').setDescription('Force delete ticket'))
        .addSubcommand(sub => sub.setName('add').setDescription('Add user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand(sub => sub.setName('transcript').setDescription('Generate transcript'))
        // Types (Panels)
        .addSubcommandGroup(g => g.setName('type').setDescription('Manage Ticket Types (Panels)')
            .addSubcommand(s => s.setName('create').setDescription('Create new ticket type'))
            .addSubcommand(s => s.setName('delete').setDescription('Delete ticket type').addStringOption(o => o.setName('id').setDescription('ID').setRequired(true)))
            .addSubcommand(s => s.setName('list').setDescription('List ticket types'))
        ),

    async execute(interaction) {
        await this.handle(interaction, interaction.options);
    },

    async executeMessage(message, args) {
        const sub = args[0] ? args[0].toLowerCase() : 'help';
        const options = {
            getSubcommand: () => {
                if (['logging', 'greetmsg', 'autotranscript', 'maxtickets', 'close', 'reopen', 'delete', 'add', 'remove', 'transcript'].includes(sub)) return sub;
                if (sub === 'type') return args[1] || 'list';
                if (sub === 'support') return args[1] || 'list';
                return null;
            },
            getSubcommandGroup: () => (sub === 'type' ? 'type' : sub === 'support' ? 'support' : null),
            getChannel: () => message.mentions.channels.first(),
            getString: (n) => {
                if (n === 'text' || n === 'reason') return args.slice(1).join(' ');
                if (n === 'id') return args[2]; // type delete <id>
                return args[1];
            },
            getBoolean: () => args[1] === 'on' || args[1] === 'true',
            getInteger: () => parseInt(args[1]),
            getRole: () => message.mentions.roles.first(),
            getUser: () => message.mentions.users.first()
        };
        // Argument shift for groups
        if (sub === 'type' || sub === 'support') {
            options.getString = (n) => {
                if (n === 'text') return args.slice(2).join(' ');
                if (n === 'id') return args[2];
                return args[2];
            };
        }

        await this.handle(message, options, true);
    },

    async handle(ctx, options, isPrefix = false) {
        const reply = (c) => isPrefix ? ctx.reply(c) : ctx.reply(c);
        const sub = options.getSubcommand();
        const group = options.getSubcommandGroup();
        const guildId = ctx.guild.id;
        const member = isPrefix ? ctx.member : ctx.member;
        const user = isPrefix ? ctx.author : ctx.user;

        const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);

        if (!sub || sub === 'help') {
            const pages = [
                new EmbedBuilder()
                    .setTitle('🎫 Ticket System (1/3): Operations')
                    .setDescription(
                        `» **ticket type create**\n› Create a new ticket panel (Wizard).\n\n` +
                        `» **ticket type list**\n› List all ticket panels.\n\n` +
                        `» **ticket close [reason]**\n› Close the current ticket.\n\n` +
                        `» **ticket reopen**\n› Reopen a closed ticket.\n\n` +
                        `» **ticket transcript**\n› Generate transcript.\n\n` +
                        `» **ticket add <user>**\n› Add user to ticket.\n\n` +
                        `» **ticket remove <user>**\n› Remove user from ticket.`
                    )
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page 1/3 | Requested by ${user.username}`, iconURL: user.displayAvatarURL() }),

                new EmbedBuilder()
                    .setTitle('🎫 Ticket System (2/3): Admin Config')
                    .setDescription(
                        `» **ticket logging <#channel>**\n› Set channel for transcripts.\n\n` +
                        `» **ticket greetmsg <text>**\n› Set welcome message ({user} for mention).\n\n` +
                        `» **ticket autotranscript <on/off>**\n› Toggle auto transcript on close.\n\n` +
                        `» **ticket maxtickets <number>**\n› Set max open tickets per user.`
                    )
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page 2/3 | Requested by ${user.username}`, iconURL: user.displayAvatarURL() }),

                new EmbedBuilder()
                    .setTitle('🎫 Ticket System (3/3): Support & Advanced')
                    .setDescription(
                        `» **ticket support add <role>**\n› Add role to support staff.\n\n` +
                        `» **ticket support remove <role>**\n› Remove role from support.\n\n` +
                        `» **ticket support list**\n› List support roles.\n\n` +
                        `» **ticket type delete <id>**\n› Delete a ticket panel.`
                    )
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page 3/3 | Requested by ${user.username}`, iconURL: user.displayAvatarURL() })
            ];

            const getRow = (p) => new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('prev').setLabel('◀').setStyle(ButtonStyle.Primary).setDisabled(p === 0),
                new ButtonBuilder().setCustomId('next').setLabel('▶').setStyle(ButtonStyle.Primary).setDisabled(p === pages.length - 1)
            );

            let page = 0;
            const msg = await reply({ embeds: [pages[0]], components: [getRow(0)] });
            const messageObj = isPrefix ? msg : await ctx.fetchReply();

            const collector = messageObj.createMessageComponentCollector({
                filter: i => i.user.id === user.id,
                time: 60000
            });

            collector.on('collect', async i => {
                if (i.customId === 'prev') page = page > 0 ? page - 1 : 0;
                if (i.customId === 'next') page = page < pages.length - 1 ? page + 1 : pages.length - 1;
                await i.update({ embeds: [pages[page]], components: [getRow(page)] });
            });

            collector.on('end', () => {
                if (!messageObj.editable) return;
                const disabledRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('prev').setLabel('◀').setStyle(ButtonStyle.Primary).setDisabled(true),
                    new ButtonBuilder().setCustomId('next').setLabel('▶').setStyle(ButtonStyle.Primary).setDisabled(true)
                );
                messageObj.edit({ components: [disabledRow] }).catch(() => { });
            });
            return;
        }

        // --- Configuration ---
        if (sub === 'logging') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });
            const channel = options.getChannel('channel');
            ticketManager.updateSetting(guildId, 'loggingChannel', channel.id);
            return reply({ embeds: [embedHelper.success(`✅ Logging set to ${channel}.`)] });
        }
        if (sub === 'greetmsg') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });
            const text = options.getString('text');
            ticketManager.updateSetting(guildId, 'greetMessage', text);
            return reply({ embeds: [embedHelper.success('✅ Greet message updated.')] });
        }
        if (sub === 'maxtickets') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });
            const limit = options.getInteger('limit');
            ticketManager.updateSetting(guildId, 'maxTickets', limit);
            return reply({ embeds: [embedHelper.success(`✅ Max tickets set to ${limit}.`)] });
        }
        if (sub === 'autotranscript') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });
            const enable = options.getBoolean('enable');
            ticketManager.updateSetting(guildId, 'autoTranscript', enable);
            return reply({ embeds: [embedHelper.success(`✅ Auto Transcript: ${enable ? 'On' : 'Off'}.`)] });
        }

        // --- Support Roles ---
        if (group === 'support') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });
            if (sub === 'add') {
                const role = options.getRole('role');
                ticketManager.addSupportRole(guildId, role.id);
                return reply({ embeds: [embedHelper.success(`✅ Added ${role} to support.`)] });
            }
            if (sub === 'remove') {
                const role = options.getRole('role');
                ticketManager.removeSupportRole(guildId, role.id);
                return reply({ embeds: [embedHelper.success(`✅ Removed ${role} from support.`)] });
            }
            if (sub === 'list') {
                const data = ticketManager.getGuildData(guildId);
                const roles = data.settings.supportRoles.map(r => `<@&${r}>`).join(', ') || 'None';
                return reply({ embeds: [embedHelper.info(`**Support Roles**\n${roles}`)] });
            }
        }

        // --- Ticket Types (Panels) ---
        if (group === 'type') {
            if (!isAdmin) return reply({ embeds: [embedHelper.error('❌ Admin only.')] });

            if (sub === 'list') {
                const panels = ticketManager.getAllPanels(guildId) || [];
                if (panels.length === 0) return reply({ embeds: [embedHelper.error('No types found.')] });
                const embed = new EmbedBuilder().setTitle('Ticket Types').setColor('#2b2d31');
                panels.forEach(p => embed.addFields({ name: `ID: ${p.id} | ${p.name}`, value: `<#${p.channelId}>` }));
                return reply({ embeds: [embed] });
            }
            if (sub === 'delete') {
                const id = options.getString('id');
                if (ticketManager.deletePanel(guildId, id)) return reply({ embeds: [embedHelper.success(`✅ Deleted type ${id}`)] });
                return reply({ embeds: [embedHelper.error('❌ ID not found.')] });
            }
            if (sub === 'create') {
                // Interactive Wizard
                if (isPrefix) {
                    return reply({ embeds: [embedHelper.info('Run `/ticket type create` to verify setup in a nice UI, or wait for next update.')] });
                }
                const modal = new ModalBuilder().setCustomId('ticket_panel_wizard').setTitle('Create Ticket Type');
                modal.addComponents(
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_name').setLabel('Type Name (e.g. Support)').setStyle(TextInputStyle.Short).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_title').setLabel('Title').setStyle(TextInputStyle.Short).setValue('Support').setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_desc').setLabel('Description').setStyle(TextInputStyle.Paragraph).setValue('Open a ticket').setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_btn').setLabel('Button Label').setStyle(TextInputStyle.Short).setValue('Open').setRequired(true))
                );
                await ctx.showModal(modal);
                return;
            }
        }

        // --- Ticket Actions ---
        const ticket = ticketManager.getTicket(guildId, ctx.channel.id);

        if (sub === 'close') {
            if (!ticket) return reply({ embeds: [embedHelper.error('❌ Not a ticket.')] });
            const reason = options.getString('reason') || 'No reason';

            // "Soft Close": Edit Permissions
            await ctx.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: false, SendMessages: false });
            // await ctx.channel.setName(`closed-${ticket.userId}`); // Optional

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_force_delete').setLabel('Delete').setStyle(ButtonStyle.Danger).setEmoji('🗑'),
                new ButtonBuilder().setCustomId('ticket_action_reopen').setLabel('Reopen').setStyle(ButtonStyle.Success).setEmoji('🔓'),
                new ButtonBuilder().setCustomId('ticket_action_transcript').setLabel('Transcript').setStyle(ButtonStyle.Secondary).setEmoji('📄')
            );

            // Generate Log
            const data = ticketManager.getGuildData(guildId);
            if (data.settings.loggingChannel) {
                const logCh = ctx.guild.channels.cache.get(data.settings.loggingChannel);
                if (logCh) logCh.send({ embeds: [embedHelper.warning(`Ticket **${ctx.channel.name}** closed by ${ctx.user} (${reason})`)] });
            }

            return reply({
                embeds: [embedHelper.warning(`🔒 Ticket closed by ${ctx.user}.\nReason: ${reason}`)],
                components: [row]
            });
        }

        if (sub === 'reopen') {
            if (!ticket) return reply({ embeds: [embedHelper.error('❌ Not a ticket.')] });
            await ctx.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: true, SendMessages: true });
            return reply({ embeds: [embedHelper.success('🔓 Ticket reopened.')] });
        }

        if (sub === 'delete') {
            // Force delete
            if (!ticket) return reply({ embeds: [embedHelper.error('❌ Not a ticket.')] });
            return reply({ embeds: [embedHelper.error('🗑 Deleting in 5 seconds...')] }).then(() => {
                setTimeout(() => {
                    ctx.channel.delete().catch(() => { });
                    ticketManager.closeTicket(ctx.guild, ctx.channel.id, ctx.user, 'Force Delete');
                }, 5000);
            });
        }

        if (sub === 'add' || sub === 'remove') {
            if (!ticket) return reply({ embeds: [embedHelper.error('❌ Not a ticket.')] });
            const target = options.getUser('user');
            if (sub === 'add') {
                await ctx.channel.permissionOverwrites.edit(target, { ViewChannel: true, SendMessages: true });
                return reply({ embeds: [embedHelper.success(`✅ Added ${target}`)] });
            } else {
                await ctx.channel.permissionOverwrites.delete(target);
                return reply({ embeds: [embedHelper.success(`✅ Removed ${target}`)] });
            }
        }

        if (sub === 'transcript') {
            if (!ticket) return reply({ embeds: [embedHelper.error('❌ Not a ticket.')] });
            if (!isPrefix) await ctx.deferReply();
            const buffer = await ticketManager.generateTranscript(ctx.channel, ticket, ctx.user, 'Manual');
            if (buffer) {
                const file = { attachment: buffer, name: `transcript-${ctx.channel.name}.txt` };
                if (!isPrefix) ctx.editReply({ files: [file] });
                else ctx.channel.send({ files: [file] });
            } else {
                reply('❌ Failed to generate.');
            }
        }
    },

    async handleModal(interaction) {
        if (interaction.customId === 'ticket_panel_wizard') {
            const name = interaction.fields.getTextInputValue('p_name');
            const title = interaction.fields.getTextInputValue('p_title');
            const desc = interaction.fields.getTextInputValue('p_desc');
            const btn = interaction.fields.getTextInputValue('p_btn');

            interaction.client.ticketWizard = interaction.client.ticketWizard || {};
            interaction.client.ticketWizard[`${interaction.user.id}_${interaction.guild.id}`] = { name, title, desc, btn };

            const channelSelect = new StringSelectMenuBuilder()
                .setCustomId('ticket_wizard_channel')
                .setPlaceholder('Select Ticket Category')
                .addOptions(interaction.guild.channels.cache
                    .filter(c => c.type === ChannelType.GuildCategory)
                    .first(25)
                    .map(c => new StringSelectMenuOptionBuilder().setLabel(c.name).setValue(c.id))
                );

            await interaction.reply({
                content: 'Select Category:',
                components: [new ActionRowBuilder().addComponents(channelSelect)],
                ephemeral: true
            });
        }

        if (interaction.customId === 'ticket_close_reason_modal') {
            // Handle modal from close button if we add one
        }
    },

    async handleComponent(interaction) {
        // Wizard
        if (interaction.customId === 'ticket_wizard_channel') {
            const cache = interaction.client.ticketWizard?.[`${interaction.user.id}_${interaction.guild.id}`];
            if (!cache) return interaction.update({ content: '❌ Expired.', components: [] });
            cache.categoryId = interaction.values[0];

            const btn = new ButtonBuilder().setCustomId('ticket_wizard_finish').setLabel('Create Here').setStyle(ButtonStyle.Success);
            await interaction.update({ content: 'Click below to create.', components: [new ActionRowBuilder().addComponents(btn)] });
        }

        if (interaction.customId === 'ticket_wizard_finish') {
            const cache = interaction.client.ticketWizard?.[`${interaction.user.id}_${interaction.guild.id}`];
            if (!cache) return interaction.update({ content: '❌ Expired.', components: [] });

            const panel = ticketManager.createPanel(interaction.guild.id, {
                name: cache.name, categoryId: cache.categoryId, channelId: interaction.channel.id,
                messageTitle: cache.title, messageDesc: cache.desc, buttonLabel: cache.btn
            });

            const embed = new EmbedBuilder().setTitle(panel.messageTitle).setDescription(panel.messageDesc).setColor('Green');
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ticket_open_${panel.id}`).setLabel(panel.buttonLabel).setStyle(ButtonStyle.Primary).setEmoji('🎫'));

            await interaction.channel.send({ embeds: [embed], components: [row] });
            await interaction.update({ content: '✅ Created!', components: [] });
        }

        // Open Ticket
        if (interaction.customId.startsWith('ticket_open_')) {
            const panelId = interaction.customId.split('_')[2];
            await interaction.deferReply({ ephemeral: true });
            const res = await ticketManager.createTicket(interaction.guild, interaction.user, panelId);

            if (!res.success) return interaction.editReply(res.message);

            // Gretting
            const data = ticketManager.getGuildData(interaction.guild.id);
            const text = data.settings.greetMessage.replace('{user}', interaction.user);

            const embed = new EmbedBuilder().setDescription(text).setColor('Green');
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_action_close_init').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                new ButtonBuilder().setCustomId('ticket_action_claim').setLabel('Claim').setStyle(ButtonStyle.Secondary).setEmoji('🙋‍♂️')
            );

            const ch = interaction.guild.channels.cache.get(res.channel.id);
            await ch.send({ content: `${interaction.user}`, embeds: [embed], components: [row] });
            interaction.editReply(`✅ Ticket: ${ch}`);
        }

        // Actions
        if (interaction.customId === 'ticket_action_close_init') {
            // Prompt internal logic same as command
            const ticket = ticketManager.getTicket(interaction.guild.id, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: 'Error', ephemeral: true });

            await interaction.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: false, SendMessages: false });

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_force_delete').setLabel('Delete').setStyle(ButtonStyle.Danger).setEmoji('🗑'),
                new ButtonBuilder().setCustomId('ticket_action_reopen').setLabel('Reopen').setStyle(ButtonStyle.Success).setEmoji('🔓'),
                new ButtonBuilder().setCustomId('ticket_action_transcript').setLabel('Transcript').setStyle(ButtonStyle.Secondary).setEmoji('📄')
            );
            await interaction.reply({ embeds: [embedHelper.warning('🔒 Ticket closed.')], components: [row] });
        }

        if (interaction.customId === 'ticket_action_reopen') {
            const ticket = ticketManager.getTicket(interaction.guild.id, interaction.channel.id);
            await interaction.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: true, SendMessages: true });
            await interaction.update({ content: '🔓 Reopened', components: [] }); // Remove buttons
        }

        if (interaction.customId === 'ticket_force_delete') {
            await interaction.reply('🗑 Deleting...');
            const ticket = ticketManager.getTicket(interaction.guild.id, interaction.channel.id);
            // Auto Transcript
            const data = ticketManager.getGuildData(interaction.guild.id);
            if (data.settings.autoTranscript) {
                const buffer = await ticketManager.generateTranscript(interaction.channel, ticket, interaction.user, 'Auto');
                if (data.settings.loggingChannel) {
                    const log = interaction.guild.channels.cache.get(data.settings.loggingChannel);
                    if (log) log.send({ content: `Ticket ${interaction.channel.name} deleted.`, files: [{ attachment: buffer, name: 'transcript.txt' }] });
                }
                // DM
                try { const u = await interaction.guild.members.fetch(ticket.userId); u.send({ files: [{ attachment: buffer, name: 'transcript.txt' }] }); } catch { }
            }

            setTimeout(() => interaction.channel.delete().catch(() => { }), 2000);
            ticketManager.closeTicket(interaction.guild, interaction.channel.id, interaction.user, 'Delete');
        }

        if (interaction.customId === 'ticket_action_transcript') {
            await interaction.deferReply();
            const ticket = ticketManager.getTicket(interaction.guild.id, interaction.channel.id);
            const buffer = await ticketManager.generateTranscript(interaction.channel, ticket, interaction.user, 'Button');
            interaction.editReply({ files: [{ attachment: buffer, name: 'transcript.txt' }] });
        }

        if (interaction.customId === 'ticket_action_claim') {
            await interaction.reply({ embeds: [embedHelper.success(`Ticket claimed by ${interaction.user}`)] });
        }
    }
};
