const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const permissionChecker = require('../../functions/permissionChecker');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('boycott')
        .setDescription('Manage the server boycott system')
        .addSubcommand(sub => sub.setName('setup').setDescription('Setup boycott system'))
        .addSubcommand(sub => sub.setName('list').setDescription('List/Show boycotted users'))
        .addSubcommand(sub => sub.setName('logging').setDescription('Set boycott logging channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('config').setDescription('Show boycott configuration'))
        .addSubcommand(sub => sub.setName('ban').setDescription('Add a user to boycott').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('unban').setDescription('Remove a user from boycott').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset boycott system')),
    async execute(interaction) {        if (!interaction.member.permissions.has('ManageGuild')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        const sub = interaction.options.getSubcommand();
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Boycott System').setDescription(`Executed boycott subcommand: **${sub}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
            return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **boycott setup**\n› Setup boycott system.\n\n` +
                `» **boycott list**\n› List boycotted users.\n\n` +
                `» **boycott logging #channel**\n› Set boycott logging channel.\n\n` +
                `» **boycott config**\n› Show configuration.\n\n` +
                `» **boycott ban @user**\n› Add a user to boycott.\n\n` +
                `» **boycott unban @user**\n› Remove user from boycott.\n\n` +
                `» **boycott reset**\n› Reset boycott system.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['setup', 'list', 'logging', 'config', 'ban', 'unban', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/boycott.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { boycotted: [], loggingChannel: null, enabled: false };

        if (subcommand === 'list') {
            const boycotted = data[guildId].boycotted || [];
            if (!boycotted.length) return message.reply({ embeds: [embedHelper.info('No users are boycotted.')] });
            const listEmbed = new EmbedBuilder()
                .setTitle('🚫 Boycotted Users')
                .setDescription(boycotted.map(id => `<@${id}>`).join('\n'))
                .setColor('#FF0000');
            return message.reply({ embeds: [listEmbed] });
        }

        if (subcommand === 'setup') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Boycott system has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'config') {
            const cfg = data[guildId];
            const configEmbed = new EmbedBuilder()
                .setTitle('🚫 Boycott Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Boycotted Users', value: cfg.boycotted.length.toString(), inline: true },
                    { name: 'Logging Channel', value: cfg.loggingChannel ? `<#${cfg.loggingChannel}>` : 'Not set', inline: true }
                )
                .setColor('#5865F2');
            return message.reply({ embeds: [configEmbed] });
        }

        if (subcommand === 'reset') {
            data[guildId] = { boycotted: [], loggingChannel: null, enabled: false };
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Boycott system has been reset.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'ban') {
            const target = message.mentions.users.first();
            if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!boycott ban @user`')] });
            if (data[guildId].boycotted.includes(target.id)) {
                return message.reply('User is already boycotted.');
            }
            data[guildId].boycotted.push(target.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Added ${target} to boycott list.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'unban') {
            const target = message.mentions.users.first();
            if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!boycott unban @user`')] });
            data[guildId].boycotted = data[guildId].boycotted.filter(id => id !== target.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Removed ${target} from boycott list.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'logging') {
            const channel = message.mentions.channels.first();
            if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!boycott logging #channel`')] });
            data[guildId].loggingChannel = channel.id;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Set boycott logging channel to ${channel}.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply({ embeds: [embedHelper.info(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/boycott ${subcommand}\``)] });
    }
};
