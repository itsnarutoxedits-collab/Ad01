const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const permit = require('../../functions/permitManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ignore')
        .setDescription('Permit: Manage ignore settings')
        // Bypass
        .addSubcommandGroup(group => group.setName('bypass').setDescription('Manage bypass ignores')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a user to bypass').addUserOption(opt => opt.setName('user').setDescription('The user to add').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a user from bypass').addUserOption(opt => opt.setName('user').setDescription('The user to remove').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset bypass list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show bypass list')))
        // Command
        .addSubcommandGroup(group => group.setName('command').setDescription('Manage command ignores')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a command to ignore').addStringOption(opt => opt.setName('command').setDescription('The command name').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a command from ignore').addStringOption(opt => opt.setName('command').setDescription('The command name').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset command list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show command list')))
        // Role
        .addSubcommandGroup(group => group.setName('role').setDescription('Manage role ignores')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role to ignore').addRoleOption(opt => opt.setName('role').setDescription('The role to add').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role from ignore').addRoleOption(opt => opt.setName('role').setDescription('The role to remove').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset role list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show role list')))
        // Channel
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage channel ignores')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to ignore').addChannelOption(opt => opt.setName('channel').setDescription('The channel to add').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from ignore').addChannelOption(opt => opt.setName('channel').setDescription('The channel to remove').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset channel list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show channel list')))
        // User
        .addSubcommandGroup(group => group.setName('user').setDescription('Manage user ignores')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a user to ignore').addUserOption(opt => opt.setName('user').setDescription('The user to add').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a user from ignore').addUserOption(opt => opt.setName('user').setDescription('The user to remove').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset user list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show user list'))),

    async execute(interaction) {
        const guildId = interaction.guild.id;
        const group = interaction.options.getSubcommandGroup();
        const subcommand = interaction.options.getSubcommand();

        // Permission check: Owner or ExtraOwner
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: 'Only the server owner or extra owners can use this command.', flags: MessageFlags.Ephemeral });
        }

        const listName = `ignore_${group}`;

        if (subcommand === 'add') {
            let targetId, targetTag;
            if (group === 'command') {
                targetId = interaction.options.getString('command').toLowerCase();
                targetTag = targetId;
            } else if (group === 'role') {
                const role = interaction.options.getRole('role');
                targetId = role.id;
                targetTag = role.name;
            } else if (group === 'channel') {
                const channel = interaction.options.getChannel('channel');
                targetId = channel.id;
                targetTag = channel.name;
            } else {
                const user = interaction.options.getUser('user');
                targetId = user.id;
                targetTag = user.tag;
            }

            const added = permit.addEntry(guildId, listName, targetId);
            return interaction.reply({ content: added ? `Successfully added **${targetTag}** to ${group} ignores.` : `**${targetTag}** is already in ${group} ignores.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'remove') {
            let targetId, targetTag;
            if (group === 'command') {
                targetId = interaction.options.getString('command').toLowerCase();
                targetTag = targetId;
            } else if (group === 'role') {
                const role = interaction.options.getRole('role');
                targetId = role.id;
                targetTag = role.name;
            } else if (group === 'channel') {
                const channel = interaction.options.getChannel('channel');
                targetId = channel.id;
                targetTag = channel.name;
            } else {
                const user = interaction.options.getUser('user');
                targetId = user.id;
                targetTag = user.tag;
            }

            const removed = permit.removeEntry(guildId, listName, targetId);
            return interaction.reply({ content: removed ? `Successfully removed **${targetTag}** from ${group} ignores.` : `**${targetTag}** is not in ${group} ignores.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'reset') {
            permit.resetList(guildId, listName);
            return interaction.reply({ content: `Successfully reset all ${group} ignores.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'show') {
            const entries = permit.getEntries(guildId, listName);
            if (entries.length === 0) return interaction.reply({ content: `No entries in ${group} ignores.`, flags: MessageFlags.Ephemeral });

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(entries.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = entries.slice(start, end);

                let content;
                if (group === 'role') content = current.map(id => `<@&${id}> (${id})`).join('\n');
                else if (group === 'channel') content = current.map(id => `<#${id}> (${id})`).join('\n');
                else if (group === 'command') content = current.map(c => `\`${c}\``).join('\n');
                else content = current.map(id => `<@${id}> (${id})`).join('\n');

                return new EmbedBuilder()
                    .setTitle(`Ignore List: ${group.charAt(0).toUpperCase() + group.slice(1)}`)
                    .setDescription(content)
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1}/${totalPages} | Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('prev').setEmoji('⬅️').setStyle(ButtonStyle.Secondary).setDisabled(p === 0),
                    new ButtonBuilder().setCustomId('next').setEmoji('➡️').setStyle(ButtonStyle.Secondary).setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const response = await interaction.reply({ embeds: [getEmbed(page)], components: getButtons(page), flags: MessageFlags.Ephemeral });
            if (totalPages > 1) {
                const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
                collector.on('collect', async i => {
                    if (i.customId === 'prev') page--;
                    else page++;
                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });
                collector.on('end', () => interaction.editReply({ components: [] }).catch(() => { }));
            }
        }
    },

    async executeMessage(message, args) {
        const group = args[0] ? args[0].toLowerCase() : 'help';
        const subcommand = args[1] ? args[1].toLowerCase() : 'help';
        const guildId = message.guild.id;

        const mainHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **ignore bypass**\n› Manage users that can bypass the ignore list for this server.\n\n` +
                `» **ignore channel**\n› Manage ignored channels for this server.\n\n` +
                `» **ignore command**\n› Manage ignored commands for this server.\n\n` +
                `» **ignore role**\n› Manage ignored roles for this server.\n\n` +
                `» **ignore user**\n› Manage ignored users for this server.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const groups = ['bypass', 'command', 'role', 'channel', 'user'];
        if (group === 'help' || !groups.includes(group)) {
            return message.reply({ embeds: [mainHelp] });
        }

        const subcommands = ['add', 'remove', 'reset', 'show'];
        if (subcommand === 'help' || !subcommands.includes(subcommand)) {
            const groupHelp = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **ignore ${group} add**\n› Add an ${group} for this server.\n\n` +
                    `» **ignore ${group} remove**\n› Remove an ${group} from this server.\n\n` +
                    `» **ignore ${group} reset**\n› Removes all ${group} ignores from this server.\n\n` +
                    `» **ignore ${group} show**\n› Show all ${group} ignores for this server.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            return message.reply({ embeds: [groupHelp] });
        }

        // Permission check: Owner or ExtraOwner
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply({ content: 'Only the server owner or extra owners can use this command.' });
        }

        const listName = `ignore_${group}`;

        if (subcommand === 'add') {
            let targetId, targetTag;
            if (group === 'command') {
                targetId = args[2] ? args[2].toLowerCase() : null;
                targetTag = targetId;
                if (!targetId) return message.reply('Please provide a command name.');
            } else if (group === 'role') {
                const roleId = message.mentions.roles.first()?.id || args[2];
                if (!roleId) return message.reply('Please mention a role or provide a valid ID.');
                const role = message.guild.roles.cache.get(roleId);
                targetId = roleId;
                targetTag = role ? role.name : roleId;
            } else if (group === 'channel') {
                const channelId = message.mentions.channels.first()?.id || args[2];
                if (!channelId) return message.reply('Please mention a channel or provide a valid ID.');
                const channel = message.guild.channels.cache.get(channelId);
                targetId = channelId;
                targetTag = channel ? channel.name : channelId;
            } else {
                const userId = message.mentions.users.first()?.id || args[2];
                if (!userId) return message.reply('Please mention a user or provide a valid ID.');
                const user = message.client.users.cache.get(userId);
                targetId = userId;
                targetTag = user ? user.tag : userId;
            }

            const added = permit.addEntry(guildId, listName, targetId);
            return message.reply(added ? `Successfully added **${targetTag}** to ${group} ignores.` : `Entry is already in ${group} ignores.`);
        }

        if (subcommand === 'remove') {
            let targetId, targetTag;
            if (group === 'command') {
                targetId = args[2] ? args[2].toLowerCase() : null;
                targetTag = targetId;
                if (!targetId) return message.reply('Please provide a command name.');
            } else if (group === 'role') {
                const roleId = message.mentions.roles.first()?.id || args[2];
                if (!roleId) return message.reply('Please mention a role or provide a valid ID.');
                const role = message.guild.roles.cache.get(roleId);
                targetId = roleId;
                targetTag = role ? role.name : roleId;
            } else if (group === 'channel') {
                const channelId = message.mentions.channels.first()?.id || args[2];
                if (!channelId) return message.reply('Please mention a channel or provide a valid ID.');
                const channel = message.guild.channels.cache.get(channelId);
                targetId = channelId;
                targetTag = channel ? channel.name : channelId;
            } else {
                const userId = message.mentions.users.first()?.id || args[2];
                if (!userId) return message.reply('Please mention a user or provide a valid ID.');
                const user = message.client.users.cache.get(userId);
                targetId = userId;
                targetTag = user ? user.tag : userId;
            }

            const removed = permit.removeEntry(guildId, listName, targetId);
            return message.reply(removed ? `Successfully removed **${targetTag}** from ${group} ignores.` : `Entry is not in ${group} ignores.`);
        }

        if (subcommand === 'reset') {
            permit.resetList(guildId, listName);
            return message.reply(`Successfully reset all ${group} ignores.`);
        }

        if (subcommand === 'show') {
            const entries = permit.getEntries(guildId, listName);
            if (entries.length === 0) return message.reply(`No entries in ${group} ignores.`);

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(entries.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = entries.slice(start, end);

                let content;
                if (group === 'role') content = current.map(id => `<@&${id}> (${id})`).join('\n');
                else if (group === 'channel') content = current.map(id => `<#${id}> (${id})`).join('\n');
                else if (group === 'command') content = current.map(c => `\`${c}\``).join('\n');
                else content = current.map(id => `<@${id}> (${id})`).join('\n');

                return new EmbedBuilder()
                    .setTitle(`Ignore List: ${group.charAt(0).toUpperCase() + group.slice(1)}`)
                    .setDescription(content)
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1}/${totalPages} | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('prev').setEmoji('⬅️').setStyle(ButtonStyle.Secondary).setDisabled(p === 0),
                    new ButtonBuilder().setCustomId('next').setEmoji('➡️').setStyle(ButtonStyle.Secondary).setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const msg = await message.reply({ embeds: [getEmbed(page)], components: getButtons(page) });
            if (totalPages > 1) {
                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 30000 });
                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) return i.reply({ content: "This button is not for you.", flags: MessageFlags.Ephemeral });
                    if (i.customId === 'prev') page--;
                    else page++;
                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });
                collector.on('end', () => msg.edit({ components: [] }).catch(() => { }));
            }
        }
    }
};
