const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const permit = require('../../functions/permitManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('extraowner')
        .setDescription('Permit: Manage extra owners for the bot')
        .addSubcommand(sub => sub.setName('add').setDescription('Add an extra owner').addUserOption(opt => opt.setName('user').setDescription('The user to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove an extra owner').addUserOption(opt => opt.setName('user').setDescription('The user to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all extra owners'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all extra owners')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // Permission check: Only Server Owner
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: 'Only the server owner can use this command.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'add') {
            const user = interaction.options.getUser('user');
            const added = permit.addExtraOwner(guildId, user.id);
            if (added) {
                return interaction.reply({ content: `Successfully added **${user.tag}** as an extra owner.`, flags: MessageFlags.Ephemeral });
            } else {
                return interaction.reply({ content: `**${user.tag}** is already an extra owner.`, flags: MessageFlags.Ephemeral });
            }
        }

        if (subcommand === 'remove') {
            const user = interaction.options.getUser('user');
            const removed = permit.removeExtraOwner(guildId, user.id);
            if (removed) {
                return interaction.reply({ content: `Successfully removed **${user.tag}** from extra owners.`, flags: MessageFlags.Ephemeral });
            } else {
                return interaction.reply({ content: `**${user.tag}** is not an extra owner.`, flags: MessageFlags.Ephemeral });
            }
        }

        if (subcommand === 'reset') {
            permit.resetExtraOwners(guildId);
            return interaction.reply({ content: 'Successfully reset all extra owners.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'show') {
            const extraOwners = permit.getExtraOwners(guildId);
            if (extraOwners.length === 0) {
                return interaction.reply({ content: 'There are no extra owners configured for this server.', flags: MessageFlags.Ephemeral });
            }

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(extraOwners.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = extraOwners.slice(start, end);

                return new EmbedBuilder()
                    .setTitle('Extra Owners')
                    .setDescription(current.map(id => `<@${id}> (${id})`).join('\n'))
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1} of ${totalPages} | Orbit™ Permit System`, iconURL: interaction.client.user.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(p === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const response = await interaction.reply({ embeds: [getEmbed(page)], components: getButtons(page), flags: MessageFlags.Ephemeral });

            if (totalPages > 1) {
                const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

                collector.on('collect', async i => {
                    if (i.customId === 'prev') page--;
                    else if (i.customId === 'next') page++;

                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });

                collector.on('end', () => {
                    interaction.editReply({ components: [] }).catch(() => { });
                });
            }
            return;
        }
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const guildId = message.guild.id;

        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **extraowner add**\n› Add an extra owner for this server.\n\n` +
                `» **extraowner remove**\n› Remove an extra owner from this server.\n\n` +
                `» **extraowner reset**\n› Removes all extra owners from this server.\n\n` +
                `» **extraowner show**\n› Show all extra owners for this server.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'reset', 'show'].includes(subcommand)) {
            console.log(`[Extraowner] Showing help for subcommand: ${subcommand}`);
            return message.reply({ embeds: [helpEmbed] });
        }

        // Permission check for actual subcommands: Only Server Owner
        if (message.author.id !== message.guild.ownerId) {
            console.log(`[Extraowner] Permission denied for ${message.author.id}`);
            return message.reply({ content: 'Only the server owner can use this command.' });
        }

        if (subcommand === 'add') {
            const user = message.mentions.users.first() || (args[1] ? { id: args[1], tag: args[1] } : null);
            if (!user) return message.reply('Please mention a user or provide a valid ID.');
            const added = permit.addExtraOwner(guildId, user.id);
            return message.reply(added ? `Successfully added **${user.tag || user.id}** as an extra owner.` : `User is already an extra owner.`);
        }

        if (subcommand === 'remove') {
            const user = message.mentions.users.first() || (args[1] ? { id: args[1], tag: args[1] } : null);
            if (!user) return message.reply('Please mention a user or provide a valid ID.');
            const removed = permit.removeExtraOwner(guildId, user.id);
            return message.reply(removed ? `Successfully removed **${user.tag || user.id}** from extra owners.` : `User is not an extra owner.`);
        }

        if (subcommand === 'reset') {
            permit.resetExtraOwners(guildId);
            return message.reply('Successfully reset all extra owners.');
        }

        if (subcommand === 'show') {
            const extraOwners = permit.getExtraOwners(guildId);
            if (extraOwners.length === 0) return message.reply('There are no extra owners configured.');

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(extraOwners.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = extraOwners.slice(start, end);

                return new EmbedBuilder()
                    .setTitle('Extra Owners')
                    .setDescription(current.map(id => `<@${id}> (${id})`).join('\n'))
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1} of ${totalPages} | Orbit™ Permit System`, iconURL: message.client.user.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(p === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const msg = await message.reply({ embeds: [getEmbed(page)], components: getButtons(page) });

            if (totalPages > 1) {
                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) return i.reply({ content: "This is not for you.", flags: MessageFlags.Ephemeral });
                    if (i.customId === 'prev') page--;
                    else if (i.customId === 'next') page++;

                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });

                collector.on('end', () => {
                    msg.edit({ components: [] }).catch(() => { });
                });
            }
            return;
        }
    }
};
