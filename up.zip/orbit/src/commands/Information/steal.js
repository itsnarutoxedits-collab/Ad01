const { SlashCommandBuilder, PermissionFlagsBits, parseEmoji } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('steal')
        .setDescription('Steal an emoji or sticker and add it to this server')
        .addStringOption(opt => opt.setName('emoji').setDescription('The emoji to steal (or sticker url)').setRequired(true))
        .addStringOption(opt => opt.setName('name').setDescription('Name for the new emoji')),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
            return interaction.reply({ embeds: [embedHelper.error('❌ Manage Emojis permission required.')] });
        }

        const input = interaction.options.getString('emoji');
        const name = interaction.options.getString('name');
        await handleSteal(interaction, input, name);
    },
    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
            return message.reply({ embeds: [embedHelper.error('❌ Manage Emojis permission required.')] });
        }
        if (!args[0]) return message.reply('Usage: `!steal <emoji> [name]`');
        await handleSteal(message, args[0], args[1]);
    }
};

async function handleSteal(context, input, nameOverride) {
    const guild = context.guild;
    const parsed = parseEmoji(input);

    let url;
    let name;

    if (parsed && parsed.id) {
        // It's a custom emoji
        url = `https://cdn.discordapp.com/emojis/${parsed.id}.${parsed.animated ? 'gif' : 'png'}`;
        name = nameOverride || parsed.name;
    } else {
        // Maybe it's a URL (Sticker or direct image)?
        if (input.startsWith('http')) {
            url = input;
            name = nameOverride || 'stolen_emoji';
        } else {
            // Default unicode
            return context.reply ? context.reply({ embeds: [embedHelper.error('Cannot steal default emojis.')] }) : null;
        }
    }

    try {
        const emoji = await guild.emojis.create({ attachment: url, name: name });
        const msg = { embeds: [embedHelper.success(`✅ Added emoji: ${emoji}`)] };
        if (context.reply) await context.reply(msg);
    } catch (e) {
        console.error(e);
        const msg = { embeds: [embedHelper.error('Failed to add emoji. Limit reached or invalid file?')] };
        if (context.reply) await context.reply(msg);
    }
}
