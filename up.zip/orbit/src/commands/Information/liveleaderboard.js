const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const liveLeaderboardManager = require('../../functions/liveLeaderboardManager');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('liveleaderboard')
        .setDescription('Manage the Live Leaderboard')
        .addSubcommand(sub =>
            sub.setName('setup')
                .setDescription('Setup a live leaderboard')
                .addStringOption(opt =>
                    opt.setName('type')
                        .setDescription('Type of leaderboard')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Messages (All Time)', value: 'messages' },
                            { name: 'Messages (Daily)', value: 'dailymessages' },
                            { name: 'Voice (All Time)', value: 'voice' },
                            { name: 'Voice (Daily)', value: 'dailyvoice' }
                        )
                )
                .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send leaderboard in (defaults to current)'))
        )
        .addSubcommand(sub =>
            sub.setName('reset')
                .setDescription('Reset/Delete a leaderboard')
                .addStringOption(opt =>
                    opt.setName('type')
                        .setDescription('Type to reset (or all)')
                        .setRequired(true)
                        .addChoices(
                            { name: 'All', value: 'all' },
                            { name: 'Messages', value: 'messages' },
                            { name: 'Daily Messages', value: 'dailymessages' },
                            { name: 'Voice', value: 'voice' },
                            { name: 'Daily Voice', value: 'dailyvoice' }
                        )
                )
        )
        .addSubcommand(sub => sub.setName('config').setDescription('Show current configuration')),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Administrator only.', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === 'setup') {
            const type = interaction.options.getString('type');
            const channel = interaction.options.getChannel('channel') || interaction.channel;

            // Check if exists
            const existing = liveLeaderboardManager.getLeaderboards(guildId).find(c => c.type === type);
            if (existing) {
                return interaction.reply({ content: `❌ Leaderboard for **${type}** already exists in <#${existing.channelId}>.`, flags: MessageFlags.Ephemeral });
            }

            // Send placeholder
            const embed = new EmbedBuilder()
                .setTitle(`Live Leaderboard: ${type}`)
                .setDescription('Initializing...')
                .setColor('Blue')
                .setFooter({ text: 'The leaderboard updates every minute.' });

            const msg = await channel.send({ embeds: [embed] });

            liveLeaderboardManager.createLeaderboard(guildId, channel.id, msg.id, type);
            // Trigger update immediately
            liveLeaderboardManager.startLoop(interaction.client);

            return interaction.reply({ content: `✅ Setup **${type}** leaderboard in ${channel}`, flags: MessageFlags.Ephemeral });
        }

        if (sub === 'reset') {
            const type = interaction.options.getString('type');
            const success = liveLeaderboardManager.deleteLeaderboard(guildId, type);

            if (success) {
                return interaction.reply({ content: `✅ Reset leaderboard(s) for **${type}**. (Messages will stop updating).` });
            } else {
                return interaction.reply({ content: '❌ No matching leaderboard found.', flags: MessageFlags.Ephemeral });
            }
        }

        if (sub === 'config') {
            const configs = liveLeaderboardManager.getLeaderboards(guildId);
            if (configs.length === 0) return interaction.reply({ content: 'No leaderboards configured.', flags: MessageFlags.Ephemeral });

            const desc = configs.map(c => `• **${c.type}**: <#${c.channelId}>`).join('\n');
            const embed = new EmbedBuilder().setTitle('Leaderboard Config').setDescription(desc).setColor('#2b2d31');
            return interaction.reply({ embeds: [embed] });
        }
    },

    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({ content: '❌ Administrator only.' });
        }

        const client = message.client;

        const sub = args[0] ? args[0].toLowerCase() : null;
        const guildId = message.guild.id;

        if (sub === 'setup') {
            const type = args[1] ? args[1].toLowerCase() : null;
            if (!type || !['messages', 'dailymessages', 'voice', 'dailyvoice'].includes(type)) {
                return message.reply('❌ Invalid type. Use: `messages`, `dailymessages`, `voice`, `dailyvoice`.');
            }

            const channel = message.mentions.channels.first() || message.channel;

            const existing = liveLeaderboardManager.getLeaderboards(guildId).find(c => c.type === type);
            if (existing) {
                return message.reply(`❌ Leaderboard for **${type}** already exists in <#${existing.channelId}>.\nIf this channel is deleted, run \`liveleaderboard reset ${type}\` to clear it.`);
            }

            const embed = new EmbedBuilder()
                .setTitle(`Live Leaderboard: ${type}`)
                .setDescription('Initializing...')
                .setColor('Blue')
                .setFooter({ text: 'The leaderboard updates every minute.' });

            const msg = await channel.send({ embeds: [embed] });

            liveLeaderboardManager.createLeaderboard(guildId, channel.id, msg.id, type);
            liveLeaderboardManager.startLoop(client);

            return message.reply(`✅ Setup **${type}** leaderboard in ${channel}`);
        }

        if (sub === 'reset') {
            const type = args[1] ? args[1].toLowerCase() : null;
            if (!type || !['all', 'messages', 'dailymessages', 'voice', 'dailyvoice'].includes(type)) {
                return message.reply('❌ Invalid type. Use: `all`, `messages`, `dailymessages`, `voice`, `dailyvoice`.');
            }

            const success = liveLeaderboardManager.deleteLeaderboard(guildId, type);

            if (success) {
                return message.reply(`✅ Reset leaderboard(s) for **${type}**. (Messages will stop updating).`);
            } else {
                return message.reply('❌ No matching leaderboard found.');
            }
        }

        if (sub === 'config') {
            const configs = liveLeaderboardManager.getLeaderboards(guildId);
            if (configs.length === 0) return message.reply('No leaderboards configured.');

            const desc = configs.map(c => `• **${c.type}**: <#${c.channelId}>`).join('\n');
            const embed = new EmbedBuilder().setTitle('Leaderboard Config').setDescription(desc).setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }

        // Help / Default
        // Help / Default
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **liveleaderboard setup <type> [channel]**\n› Setup a live leaderboard.\n` +
                `Types: \`messages\`, \`dailymessages\`, \`voice\`, \`dailyvoice\`\n\n` +
                `» **liveleaderboard reset <type|all>**\n› Reset/Delete a leaderboard.\n\n` +
                `» **liveleaderboard config**\n› Show current configuration.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
        return message.reply({ embeds: [embed] });
    }
};

