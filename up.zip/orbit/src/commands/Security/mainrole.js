const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mainrole')
        .setDescription('Security: Configure main roles for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all main roles'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all main roles')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);

        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand(false);

        if (!subcommand) {
            const embed = new EmbedBuilder()
                .setTitle('Orbit™ mainrole [4]')
                .setDescription('`<..> <required> | [..] [optional]`\n\n' +
                    '⟫ `mainrole add <role>`\n' +
                    '⟩ Add a main role.\n\n' +
                    '⟫ `mainrole remove <role>`\n' +
                    '⟩ Remove a main role.\n\n' +
                    '⟫ `mainrole show`\n' +
                    '⟩ Show all main roles.\n\n' +
                    '⟫ `mainrole reset`\n' +
                    '⟩ Reset all main roles.')
                .setColor('#2b2d31')
                .setFooter({
                    text: `Page 1/1 | Requested by ${interaction.user.username}`,
                    iconURL: interaction.user.displayAvatarURL()
                });

            return await interaction.reply({ embeds: [embed] });
        }

        const embed = new EmbedBuilder()
            .setTitle(`Mainrole: ${subcommand}`)
            .setDescription(`You have triggered the **${subcommand}** module of Mainrole.`)
            .setColor('#2b2d31')
            .setFooter({ text: `Orbit™ Security System`, iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed] });
    },
    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);

        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embed.error('❌ No access - Only server owner or extra owners can use this command')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **mainrole add <role>**\n› Add a main role (Name/ID/Mention).\n\n` +
                `» **mainrole remove <role>**\n› Remove a main role.\n\n` +
                `» **mainrole show/list**\n› Show all main roles.\n\n` +
                `» **mainrole reset**\n› Reset all main roles.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'list', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed] });
        }

        const antinuke = require('../../functions/antinukeManager');
        const guildId = message.guild.id;
        const config = antinuke.getConfig(guildId);
        const mainRoles = config.mainRoles || [];

        if (subcommand === 'show' || subcommand === 'list') {
            if (!mainRoles.length) return message.reply({ embeds: [embed.info('No main roles configured.')] });
            return message.reply({ embeds: [embed.info(`Main roles: ${mainRoles.map(id => `<@&${id}>`).join(', ')}`)] });
        }

        if (subcommand === 'reset') {
            antinuke.setConfig(guildId, { mainRoles: [] });
            return message.reply({ embeds: [embed.success('All main roles have been reset.')] });
        }

        const findRole = (query) => {
            if (!query) return null;
            const clean = query.replace(/[<@&>]/g, '');
            // ID check
            if (message.guild.roles.cache.has(clean)) return message.guild.roles.cache.get(clean);
            // Name check
            const lower = query.toLowerCase();
            return message.guild.roles.cache.find(r => r.name.toLowerCase() === lower) ||
                message.guild.roles.cache.find(r => r.name.toLowerCase().startsWith(lower)) ||
                message.guild.roles.cache.find(r => r.name.toLowerCase().includes(lower));
        };

        if (subcommand === 'add') {
            const query = args.slice(1).join(' ');
            const role = findRole(query);

            if (!role) return message.reply({ embeds: [embed.error('Role not found. Please provide a valid Name, ID, or Mention.')] });
            if (role.managed) return message.reply({ embeds: [embed.error('Cannot add managed roles (bot roles).')] });
            if (mainRoles.includes(role.id)) return message.reply({ embeds: [embed.info('This role is already a main role.')] });
            if (mainRoles.length >= 5) return message.reply({ embeds: [embed.error('Maximum 5 main roles allowed.')] });

            mainRoles.push(role.id);
            antinuke.setConfig(guildId, { mainRoles });
            return message.reply({ embeds: [embed.success(`Added ${role} as a main role.`)] });
        }

        if (subcommand === 'remove') {
            const query = args.slice(1).join(' ');
            const role = findRole(query);

            if (!role) {
                // Try removing by ID if role is deleted but still in config
                if (mainRoles.includes(query)) {
                    const updated = mainRoles.filter(id => id !== query);
                    antinuke.setConfig(guildId, { mainRoles: updated });
                    return message.reply({ embeds: [embed.success(`Removed role ID \`${query}\` from main roles.`)] });
                }
                return message.reply({ embeds: [embed.error('Role not found.')] });
            }

            if (!mainRoles.includes(role.id)) return message.reply({ embeds: [embed.error('This role is not a main role.')] });

            const updated = mainRoles.filter(id => id !== role.id);
            antinuke.setConfig(guildId, { mainRoles: updated });
            return message.reply({ embeds: [embed.success(`Removed ${role} from main roles.`)] });
        }
    }
};
