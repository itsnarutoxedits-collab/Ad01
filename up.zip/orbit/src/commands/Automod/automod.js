const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const automod = require('../../functions/automodManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('automod')
        .setDescription('Automod: Configure server automation filters')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable automod'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable automod'))
        .addSubcommand(sub => sub.setName('config').setDescription('Show automod configuration'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset automod settings'))
        .addSubcommandGroup(group =>
            group.setName('heat')
                .setDescription('Configure anti-spam (heat) settings')
                .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-spam'))
                .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-spam'))
                .addSubcommand(sub => sub.setName('set').setDescription('Set heat limit').addIntegerOption(opt => opt.setName('limit').setDescription('Max messages before trigger').setRequired(true)))
        )
        .addSubcommandGroup(group =>
            group.setName('automute')
                .setDescription('Configure automute settings')
                .addSubcommand(sub => sub.setName('enable').setDescription('Enable automute'))
                .addSubcommand(sub => sub.setName('disable').setDescription('Disable automute'))
                .addSubcommand(sub => sub.setName('set').setDescription('Set automute threshold').addIntegerOption(opt => opt.setName('threshold').setDescription('Max alerts before mute').setRequired(true)))
        )
        .addSubcommandGroup(group =>
            group.setName('ignore')
                .setDescription('Configure ignored targets')
                .addSubcommand(sub => sub.setName('add_user').setDescription('Ignore a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
                .addSubcommand(sub => sub.setName('add_role').setDescription('Ignore a role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
                .addSubcommand(sub => sub.setName('add_channel').setDescription('Ignore a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove_user').setDescription('Unignore a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove_role').setDescription('Unignore a role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove_channel').setDescription('Unignore a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('show').setDescription('Show ignored targets'))
                .addSubcommand(sub => sub.setName('reset').setDescription('Reset ignored targets'))
        )
        .addSubcommand(sub => sub.setName('logging').setDescription('Configure logging channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('punishment').setDescription('Configure punishment').addStringOption(opt => opt.setName('type').setDescription('The type').addChoices({ name: 'Ban', value: 'ban' }, { name: 'Mute', value: 'mute' }, { name: 'Kick', value: 'kick' }).setRequired(true)))
        .addSubcommandGroup(group => group.setName('links').setDescription('Configure anti-link')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-link'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-link')))
        .addSubcommandGroup(group => group.setName('invites').setDescription('Configure anti-invite')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-invite'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-invite')))
        .addSubcommandGroup(group => group.setName('mentions').setDescription('Configure anti-mention')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-mention'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-mention'))
            .addSubcommand(sub => sub.setName('set').setDescription('Set mention limit').addIntegerOption(opt => opt.setName('limit').setDescription('Max mentions').setRequired(true))))
        .addSubcommandGroup(group => group.setName('caps').setDescription('Configure anti-caps')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-caps'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-caps'))
            .addSubcommand(sub => sub.setName('set').setDescription('Set caps percentage').addIntegerOption(opt => opt.setName('percent').setDescription('Max uppercase percentage (1-100)').setRequired(true))))
        .addSubcommandGroup(group => group.setName('spoilers').setDescription('Configure anti-spoiler')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-spoiler'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-spoiler'))
            .addSubcommand(sub => sub.setName('set').setDescription('Set spoiler limit').addIntegerOption(opt => opt.setName('limit').setDescription('Max spoilers').setRequired(true))))
        .addSubcommandGroup(group => group.setName('newlines').setDescription('Configure anti-newlines')
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-newlines'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-newlines'))
            .addSubcommand(sub => sub.setName('set').setDescription('Set newline limit').addIntegerOption(opt => opt.setName('limit').setDescription('Max newlines').setRequired(true)))),

    async execute(interaction) {
        const guildId = interaction.guild.id;
        const group = interaction.options.getSubcommandGroup(false);
        const subcommand = interaction.options.getSubcommand();

        // Permission check: Owner or ExtraOwner (from permitManager if applicable, here we use generic check)
        // For simplicity and to avoid circular deps if any, we'll use a direct permit check if we can
        const permit = require('../../functions/permitManager');
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'enable') {
            automod.setConfig(guildId, { enabled: true });
            return interaction.reply({ content: 'Successfully enabled automod.', flags: MessageFlags.Ephemeral });
        }
        if (subcommand === 'disable') {
            automod.setConfig(guildId, { enabled: false });
            return interaction.reply({ content: 'Successfully disabled automod.', flags: MessageFlags.Ephemeral });
        }
        if (subcommand === 'reset') {
            // Need a reset function in manager or manually set defaults
            // For now, overwrite with fresh data
            automod.setConfig(guildId, {
                enabled: false,
                punishment: 'mute',
                logging: null,
                filters: {
                    heat: { enabled: false, threshold: 5, decay: 2 },
                    automute: { enabled: false, threshold: 10 }
                },
                ignore: { channels: [], roles: [], users: [] }
            });
            return interaction.reply({ content: 'Successfully reset automod settings.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'config') {
            const data = automod.getGuildData(guildId);
            const embed = new EmbedBuilder()
                .setTitle('Automod Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Status', value: data.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Punishment', value: data.punishment.charAt(0).toUpperCase() + data.punishment.slice(1), inline: true },
                    { name: 'Logging', value: data.logging ? `<#${data.logging}>` : 'None', inline: true },
                    { name: 'Heat Limit', value: `${data.filters.heat.enabled ? '✅' : '❌'} ${data.filters.heat.threshold}`, inline: true },
                    { name: 'Automute', value: `${data.filters.automute.enabled ? '✅' : '❌'} ${data.filters.automute.threshold}`, inline: true }
                )
                .setFooter({ text: 'Orbit™ Automod System', iconURL: interaction.client.user.displayAvatarURL() });
            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'logging') {
            const channel = interaction.options.getChannel('channel');
            automod.setConfig(guildId, { logging: channel.id });
            return interaction.reply({ content: `Successfully set logging channel to ${channel}.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'punishment') {
            const type = interaction.options.getString('type');
            automod.setConfig(guildId, { punishment: type });
            return interaction.reply({ content: `Successfully set punishment to **${type}**.`, flags: MessageFlags.Ephemeral });
        }

        if (group === 'heat') {
            if (subcommand === 'enable') {
                automod.setFilter(guildId, 'heat', { enabled: true });
                return interaction.reply({ content: 'Successfully enabled heat protection.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'disable') {
                automod.setFilter(guildId, 'heat', { enabled: false });
                return interaction.reply({ content: 'Successfully disabled heat protection.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'set') {
                const limit = interaction.options.getInteger('limit');
                automod.setFilter(guildId, 'heat', { threshold: limit });
                return interaction.reply({ content: `Successfully set heat limit to **${limit}**.`, flags: MessageFlags.Ephemeral });
            }
        }

        if (group === 'automute') {
            if (subcommand === 'enable') {
                automod.setFilter(guildId, 'automute', { enabled: true });
                return interaction.reply({ content: 'Successfully enabled automute.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'disable') {
                automod.setFilter(guildId, 'automute', { enabled: false });
                return interaction.reply({ content: 'Successfully disabled automute.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'set') {
                const threshold = interaction.options.getInteger('threshold');
                automod.setFilter(guildId, 'automute', { threshold });
                return interaction.reply({ content: `Successfully set automute threshold to **${threshold}**.`, flags: MessageFlags.Ephemeral });
            }
        }

        if (group === 'ignore') {
            const data = automod.getGuildData(guildId);
            if (subcommand.startsWith('add_')) {
                const type = subcommand.split('_')[1];
                const entity = interaction.options.get('user')?.value || interaction.options.get('role')?.value || interaction.options.get('channel')?.value;
                if (!data.ignore[`${type}s`].includes(entity)) {
                    data.ignore[`${type}s`].push(entity);
                    automod.setConfig(guildId, { ignore: data.ignore });
                    return interaction.reply({ content: `Added to ignored ${type}s.`, flags: MessageFlags.Ephemeral });
                }
                return interaction.reply({ content: `Already in ignored ${type}s.`, ephemeral: true });
            }
            if (subcommand.startsWith('remove_')) {
                const type = subcommand.split('_')[1];
                const entity = interaction.options.get('user')?.value || interaction.options.get('role')?.value || interaction.options.get('channel')?.value;
                if (data.ignore[`${type}s`].includes(entity)) {
                    data.ignore[`${type}s`] = data.ignore[`${type}s`].filter(id => id !== entity);
                    automod.setConfig(guildId, { ignore: data.ignore });
                    return interaction.reply({ content: `Removed from ignored ${type}s.`, flags: MessageFlags.Ephemeral });
                }
                return interaction.reply({ content: `Not in ignored ${type}s.`, ephemeral: true });
            }
            if (subcommand === 'reset') {
                automod.setConfig(guildId, { ignore: { channels: [], roles: [], users: [] } });
                return interaction.reply({ content: 'Successfully reset ignored targets.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'show') {
                const embed = new EmbedBuilder()
                    .setTitle('Automod Ignore Lists')
                    .setColor('#2b2d31')
                    .addFields(
                        { name: 'Users', value: data.ignore.users.length > 0 ? data.ignore.users.map(id => `<@${id}>`).join(', ') : 'None' },
                        { name: 'Roles', value: data.ignore.roles.length > 0 ? data.ignore.roles.map(id => `<@&${id}>`).join(', ') : 'None' },
                        { name: 'Channels', value: data.ignore.channels.length > 0 ? data.ignore.channels.map(id => `<#${id}>`).join(', ') : 'None' }
                    );
                return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
            }
        }

        // New Filters Logic
        const simpleFilters = ['links', 'invites'];
        if (simpleFilters.includes(group)) {
            if (subcommand === 'enable') {
                automod.setFilter(guildId, group, { enabled: true });
                return interaction.reply({ content: `Successfully enabled **${group}** filter.`, flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'disable') {
                automod.setFilter(guildId, group, { enabled: false });
                return interaction.reply({ content: `Successfully disabled **${group}** filter.`, flags: MessageFlags.Ephemeral });
            }
        }

        const advancedFilters = ['mentions', 'caps', 'spoilers', 'newlines'];
        if (advancedFilters.includes(group)) {
            if (subcommand === 'enable') {
                automod.setFilter(guildId, group, { enabled: true });
                return interaction.reply({ content: `Successfully enabled **${group}** filter.`, flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'disable') {
                automod.setFilter(guildId, group, { enabled: false });
                return interaction.reply({ content: `Successfully disabled **${group}** filter.`, flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'set') {
                const limit = interaction.options.getInteger('limit') || interaction.options.getInteger('percent');
                automod.setFilter(guildId, group, { threshold: limit });
                return interaction.reply({ content: `Successfully set **${group}** threshold to **${limit}**.`, flags: MessageFlags.Ephemeral });
            }
        }
    },

    async executeMessage(message, args) {
        const guildId = message.guild.id;
        const page = args[0] === '2' ? 2 : 1;

        const helpEmbed1 = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **automod automute**\n› Configure automute threshold.\n\n` +
                `» **automod config**\n› View current automod settings.\n\n` +
                `» **automod disable**\n› Disable all automod features.\n\n` +
                `» **automod enable**\n› Enable all automod features.\n\n` +
                `» **automod heat**\n› Configure anti-spam heat limit.\n\n` +
                `» **automod ignore**\n› Manage ignored targets (users/roles/channels).\n\n` +
                `» **automod logging**\n› Configure automod log channel.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/2 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const helpEmbed2 = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **automod punishment**\n› Configure default punishment type.\n\n` +
                `» **automod reset**\n› Reset all automod settings to default.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 2/2 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const getButtons = (p) => {
            return new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('first').setLabel('«').setStyle(ButtonStyle.Secondary).setDisabled(p === 1),
                new ButtonBuilder().setCustomId('prev').setLabel('‹').setStyle(ButtonStyle.Secondary).setDisabled(p === 1),
                new ButtonBuilder().setCustomId('next').setLabel('›').setStyle(ButtonStyle.Secondary).setDisabled(p === 2),
                new ButtonBuilder().setCustomId('last').setLabel('»').setStyle(ButtonStyle.Secondary).setDisabled(p === 2),
                new ButtonBuilder().setCustomId('delete').setEmoji('🗑️').setStyle(ButtonStyle.Danger)
            );
        };

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const validSubcommands = ['enable', 'disable', 'config', 'reset', 'logging', 'punishment', 'heat', 'automute', 'ignore'];

        if (subcommand === 'help' || !validSubcommands.includes(subcommand)) {
            const msg = await message.reply({ embeds: [page === 1 ? helpEmbed1 : helpEmbed2], components: [getButtons(page)] });
            const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
            let currentPage = page;

            collector.on('collect', async i => {
                if (i.user.id !== message.author.id) return i.reply({ content: "This is not for you.", flags: MessageFlags.Ephemeral });
                if (i.customId === 'delete') return await msg.delete().catch(() => { });

                if (i.customId === 'first' || i.customId === 'prev') currentPage = 1;
                else if (i.customId === 'next' || i.customId === 'last') currentPage = 2;

                await i.update({ embeds: [currentPage === 1 ? helpEmbed1 : helpEmbed2], components: [getButtons(currentPage)] });
            });
            return;
        }

        // Implementation of subcommands for prefix (repetitive logic, usually handled by a helper or subcommand system)
        const permit = require('../../functions/permitManager');
        const automod = require('../../functions/automodManager');
        if (message.author.id !== message.guild.ownerId && !permit.isExtraOwner(guildId, message.author.id)) {
            return message.reply('❌ No access');
        }

        if (subcommand === 'enable') {
            automod.setConfig(guildId, { enabled: true });
            const reply = await message.reply('✅ Successfully enabled automod.');
            setTimeout(() => reply.delete().catch(() => { }), 3000);
            return;
        }
        if (subcommand === 'disable') {
            automod.setConfig(guildId, { enabled: false });
            const reply = await message.reply('✅ Successfully disabled automod.');
            setTimeout(() => reply.delete().catch(() => { }), 3000);
            return;
        }
        if (subcommand === 'reset') {
            automod.setConfig(guildId, {
                enabled: false,
                punishment: 'mute',
                logging: null,
                filters: {
                    heat: { enabled: false, threshold: 5, decay: 2 },
                    automute: { enabled: false, threshold: 10 }
                },
                ignore: { channels: [], roles: [], users: [] }
            });
            const reply = await message.reply('✅ Successfully reset automod settings to default.');
            setTimeout(() => reply.delete().catch(() => { }), 3000);
            return;
        }
        if (subcommand === 'config') {
            const data = automod.getGuildData(guildId);
            const embed = new EmbedBuilder()
                .setTitle('Automod Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Status', value: data.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Punishment', value: data.punishment.charAt(0).toUpperCase() + data.punishment.slice(1), inline: true },
                    { name: 'Logging', value: data.logging ? `<#${data.logging}>` : 'None', inline: true },
                    { name: 'Heat Limit', value: `${data.filters.heat.enabled ? '✅' : '❌'} ${data.filters.heat.threshold}`, inline: true },
                    { name: 'Automute', value: `${data.filters.automute.enabled ? '✅' : '❌'} ${data.filters.automute.threshold}`, inline: true }
                )
                .setFooter({ text: 'Orbit™ Automod System', iconURL: message.client.user.displayAvatarURL() });
            return message.reply({ embeds: [embed] });
        }
        if (subcommand === 'logging') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply('Please mention a channel. Usage: `!automod logging #channel`');
            }
            const channel = message.guild.channels.cache.get(channelId);
            if (!channel) {
                return message.reply('Invalid channel provided.');
            }
            automod.setConfig(guildId, { logging: channelId });
            const reply = await message.reply(`✅ Successfully set logging channel to ${channel}.`);
            setTimeout(() => reply.delete().catch(() => { }), 3000);
            return;
        }
        if (subcommand === 'punishment') {
            const type = args[1] ? args[1].toLowerCase() : null;
            if (!type || !['ban', 'kick', 'mute'].includes(type)) {
                return message.reply('Please provide a valid punishment type: `ban`, `kick`, or `mute`. Usage: `!automod punishment <type>`');
            }
            automod.setConfig(guildId, { punishment: type });
            const reply = await message.reply(`✅ Set punishment to: **${type}**`);
            setTimeout(() => reply.delete().catch(() => { }), 3000);
            return;
        }
        if (subcommand === 'heat') {
            const action = args[1] ? args[1].toLowerCase() : null;
            const data = automod.getGuildData(guildId);
            if (action === 'enable') {
                data.filters.heat.enabled = true;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply('✅ Enabled anti-spam heat filter.');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else if (action === 'disable') {
                data.filters.heat.enabled = false;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply('✅ Disabled anti-spam heat filter.');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else if (action === 'set') {
                const limit = parseInt(args[2]);
                if (isNaN(limit) || limit < 1) {
                    return message.reply('Please provide a valid number. Usage: `!automod heat set <number>`');
                }
                data.filters.heat.threshold = limit;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply(`✅ Set heat limit to: **${limit}**`);
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else {
                return message.reply('Usage: `!automod heat <enable/disable/set>`');
            }
            return;
        }
        if (subcommand === 'automute') {
            const action = args[1] ? args[1].toLowerCase() : null;
            const data = automod.getGuildData(guildId);
            if (action === 'enable') {
                data.filters.automute.enabled = true;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply('✅ Enabled automute.');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else if (action === 'disable') {
                data.filters.automute.enabled = false;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply('✅ Disabled automute.');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else if (action === 'set') {
                const threshold = parseInt(args[2]);
                if (isNaN(threshold) || threshold < 1) {
                    return message.reply('Please provide a valid number. Usage: `!automod automute set <number>`');
                }
                data.filters.automute.threshold = threshold;
                automod.setConfig(guildId, { filters: data.filters });
                const reply = await message.reply(`✅ Set automute threshold to: **${threshold}**`);
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else {
                return message.reply('Usage: `!automod automute <enable/disable/set>`');
            }
            return;
        }
        if (subcommand === 'ignore') {
            const action = args[1] ? args[1].toLowerCase() : null;
            const data = automod.getGuildData(guildId);

            if (action === 'show') {
                const embed = new EmbedBuilder()
                    .setTitle('Automod Ignore Lists')
                    .setColor('#2b2d31')
                    .addFields(
                        { name: 'Users', value: data.ignore.users.length > 0 ? data.ignore.users.map(id => `<@${id}>`).join(', ') : 'None' },
                        { name: 'Roles', value: data.ignore.roles.length > 0 ? data.ignore.roles.map(id => `<@&${id}>`).join(', ') : 'None' },
                        { name: 'Channels', value: data.ignore.channels.length > 0 ? data.ignore.channels.map(id => `<#${id}>`).join(', ') : 'None' }
                    );
                return message.reply({ embeds: [embed] });
            } else if (action === 'reset') {
                automod.setConfig(guildId, { ignore: { channels: [], roles: [], users: [] } });
                const reply = await message.reply('✅ Successfully reset ignored targets.');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } else {
                return message.reply('Usage: `!automod ignore <show/reset>` or use slash command for add/remove operations: `/automod ignore`');
            }
            return;
        }
        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now.`);
    }
};
