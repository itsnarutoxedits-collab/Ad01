const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');
const playlistMgr = require('../../functions/playlistManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('playlist')
        .setDescription('Manage your personal playlists')
        .addSubcommand(sub => sub.setName('create').setDescription('Create a new playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)))
        .addSubcommand(sub => sub.setName('delete').setDescription('Delete a playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List your playlists'))
        .addSubcommand(sub => sub.setName('view').setDescription('View songs in a playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)))
        .addSubcommand(sub => sub.setName('play').setDescription('Play a saved playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)))
        .addSubcommand(sub => sub.setName('add').setDescription('Add a song to playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)).addStringOption(o => o.setName('query').setDescription('Song URL/Name').setRequired(true)))
        .addSubcommand(sub => sub.setName('addcurrent').setDescription('Add currently playing song to queue').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove song from playlist').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true)).addIntegerOption(o => o.setName('index').setDescription('Song index').setRequired(true)))
        .addSubcommand(sub => sub.setName('rename').setDescription('Rename a playlist').addStringOption(o => o.setName('old').setDescription('Old name').setRequired(true)).addStringOption(o => o.setName('new').setDescription('New name').setRequired(true)))
        .addSubcommand(sub => sub.setName('import').setDescription('Import external playlist').addStringOption(o => o.setName('name').setDescription('Target playlist').setRequired(true)).addStringOption(o => o.setName('url').setDescription('Playlist URL').setRequired(true)))
        .addSubcommand(sub => sub.setName('export').setDescription('Export playlist to DMs').addStringOption(o => o.setName('name').setDescription('Playlist name').setRequired(true))),

    async execute(interaction) {
        await this.handle(interaction, interaction.options.getSubcommand(), interaction.options);
    },

    async executeMessage(message, args) {
        const sub = args[0] ? args[0].toLowerCase() : 'list';
        // Mock options for consistency
        const options = {
            getString: (name) => {
                if (name === 'name') return args[1];
                if (name === 'query' || name === 'url' || name === 'old') return args[2] || args.slice(2).join(' '); // query can be multi-word
                if (name === 'new') return args[2];
                return null;
            },
            getInteger: (name) => parseInt(args[2]),
            getUser: () => message.author
        };
        // For add command, args might be: add <name> <query...>
        // For rename: rename <old> <new>
        // Adjust options logic slightly for prefix
        if (sub === 'add') {
            options.getString = (name) => {
                if (name === 'name') return args[1];
                if (name === 'query') return args.slice(2).join(' ');
                return null;
            };
        }
        if (sub === 'rename') {
            options.getString = (name) => {
                if (name === 'old') return args[1];
                if (name === 'new') return args[2];
                return null;
            };
        }

        await this.handle(message, sub, options, true);
    },

    async handle(ctx, sub, options, isPrefix = false) {
        const user = isPrefix ? ctx.author : ctx.user;
        const reply = (content) => isPrefix ? ctx.reply(content) : ctx.reply(content);
        // Helper for deferring if needed (slash only usually, but prefix might need delay handling)

        if (sub === 'create') {
            const name = options.getString('name');
            if (!name) return reply({ embeds: [embed.error('Usage: `playlist create <name>`')] });
            if (playlistMgr.createPlaylist(user.id, name)) {
                return reply({ embeds: [embed.success(`✅ Created playlist **${name}**.`)] });
            } else {
                return reply({ embeds: [embed.error(`❌ Playlist **${name}** already exists.`)] });
            }
        }

        else if (sub === 'delete') {
            const name = options.getString('name');
            if (playlistMgr.deletePlaylist(user.id, name)) {
                return reply({ embeds: [embed.success(`🗑 Deleted playlist **${name}**.`)] });
            } else {
                return reply({ embeds: [embed.error(`❌ Playlist **${name}** not found.`)] });
            }
        }

        else if (sub === 'list') {
            const playlists = playlistMgr.getUserPlaylists(user.id);
            const names = Object.keys(playlists);
            if (names.length === 0) return reply({ embeds: [embed.info('You have no playlists.')] });
            return reply({ embeds: [embed.info(`**Your Playlists**\n${names.map(n => `• ${n} (${playlists[n].length} songs)`).join('\n')}`)] });
        }

        else if (sub === 'view') {
            const name = options.getString('name');
            const playlist = playlistMgr.getPlaylist(user.id, name);
            if (!playlist) return reply({ embeds: [embed.error(`❌ Playlist **${name}** not found.`)] });

            const list = playlist.map((s, i) => `${i + 1}. [${s.name}](${s.url}) \`${s.duration}\``).join('\n');
            const chunks = list.match(/[\s\S]{1,1900}/g) || ['Empty'];

            return reply({ embeds: [embed.info(`**Playlist: ${name}**\n${chunks[0]}`)] });
        }

        else if (sub === 'add') {
            const name = options.getString('name');
            const query = options.getString('query');
            if (!query) return reply({ embeds: [embed.error('Usage: `playlist add <name> <url/query>`')] });

            // Need to resolve the song first
            // We can use client.distube.search or just play logic?
            // Distube search returns array.
            // Let's use spotify helper or distube handler
            const client = ctx.client;

            let songData = null;
            try {
                // We fake a search? Or simply verify it exists?
                // Simplest is to assume it's a search string and store it, OR resolve it now.
                // Resolving now is better for "duration" etc.
                if (isPrefix) await ctx.react('🔎');

                // Hack: Use DisTube to resolve?
                // We'll trust the input is valid or basic search. 
                // Getting full metadata without playing is tricky with just 'distube'.
                // 'distube.search(query)' 
                const results = await client.distube.search(query, { limit: 1 });
                if (results && results.length > 0) {
                    songData = results[0];
                } else {
                    return reply({ embeds: [embed.error('❌ Could not find that song.')] });
                }
            } catch (e) {
                return reply({ embeds: [embed.error(`❌ Error finding song: ${e.message}`)] });
            }

            if (songData) {
                playlistMgr.addSong(user.id, name, songData);
                return reply({ embeds: [embed.success(`✅ Added **${songData.name}** to **${name}**.`)] });
            }
        }

        else if (sub === 'addcurrent') {
            const name = options.getString('name');
            const client = ctx.client;
            const queue = client.distube.getQueue(ctx.guildId);
            if (!queue || !queue.songs[0]) return reply({ embeds: [embed.error('❌ Nothing playing.')] });

            playlistMgr.addSong(user.id, name, queue.songs[0]);
            return reply({ embeds: [embed.success(`✅ Added **${queue.songs[0].name}** to **${name}**.`)] });
        }

        else if (sub === 'remove') {
            const name = options.getString('name');
            const index = options.getInteger('index');
            if (playlistMgr.removeSong(user.id, name, index - 1)) {
                return reply({ embeds: [embed.success(`✅ Removed song at index ${index} from **${name}**.`)] });
            } else {
                return reply({ embeds: [embed.error('❌ Invalid playlist or index.')] });
            }
        }

        else if (sub === 'rename') {
            const oldName = options.getString('old');
            const newName = options.getString('new');
            if (playlistMgr.renamePlaylist(user.id, oldName, newName)) {
                return reply({ embeds: [embed.success(`✅ Renamed **${oldName}** to **${newName}**.`)] });
            } else {
                return reply({ embeds: [embed.error('❌ Playlist not found or new name taken.')] });
            }
        }

        else if (sub === 'play') {
            const name = options.getString('name');
            const playlist = playlistMgr.getPlaylist(user.id, name);
            if (!playlist || playlist.length === 0) return reply({ embeds: [embed.error(`❌ Playlist **${name}** empty or not found.`)] });

            const member = isPrefix ? ctx.member : ctx.member;
            const channel = member.voice.channel;
            if (!channel) return reply({ embeds: [embed.error('You must be in a voice channel.')] });

            const client = ctx.client;

            // Play first song, then add rest?
            // Or create a custom Playlist structure?
            // Distube.play accepts array of urls? No.
            // We loop. But verify concurrency.
            // Better: client.distube.createCustomPlaylist(songs, { member, properties: { name: name } })

            try {
                // If DisTube has createCustomPlaylist
                if (client.distube.createCustomPlaylist) {
                    const customPL = await client.distube.createCustomPlaylist(playlist.map(s => s.url), {
                        member: member,
                        properties: { name: name, source: 'orbit' },
                        parallel: true
                    });
                    await client.distube.play(channel, customPL, { member: member, textChannel: ctx.channel });
                } else {
                    // Fallback loop
                    await reply({ embeds: [embed.info(`Starting playlist **${name}** (${playlist.length} songs)...`)] });
                    for (const s of playlist) {
                        try {
                            await client.distube.play(channel, s.url, { member: member, textChannel: ctx.channel });
                        } catch (e) { console.error('Failed to load ' + s.url); }
                    }
                    return;
                }

                return reply({ embeds: [embed.success(`🎶 Loaded playlist **${name}**.`)] });
            } catch (e) {
                return reply({ embeds: [embed.error(`❌ Error playing: ${e.message}`)] });
            }
        }

        else if (sub === 'import') {
            const name = options.getString('name');
            const url = options.getString('url');
            // Resolve external playlist
            const client = ctx.client;
            try {
                if (isPrefix) await ctx.react('⏳');
                // Create empty if not exists
                playlistMgr.createPlaylist(user.id, name);

                // We can use the plugin or handler to get items?
                // Not trivial to inspect playlist without playing.
                // We'll try to Play it in a fake way? No.
                // distube.handler.resolvePlaylist(url) is not always public.
                // But wait, YtDlpPlugin?
                // Let's assume user wants to play it later.
                // If we support 'import', we really want to extracting songs.
                // 'await client.distube.handler.resolve(url)' might work.

                // For now, placeholders since it's complex to extract without playing.
                return reply({ embeds: [embed.info('❌ Import from URL is under construction. Please add songs one by one or Play the URL directly.')] });
            } catch (e) {
                return reply({ embeds: [embed.error(e.message)] });
            }
        }

        else if (sub === 'export') {
            const name = options.getString('name');
            const playlist = playlistMgr.getPlaylist(user.id, name);
            if (!playlist) return reply({ embeds: [embed.error(`❌ Playlist **${name}** not found.`)] });

            const linkList = playlist.map(s => s.url).join('\n');
            try {
                await user.send({ content: `**Playlist: ${name}**\n${linkList}` });
                return reply({ embeds: [embed.success('📩 Exported to DMs.')] });
            } catch {
                return reply({ embeds: [embed.error('❌ Can\'t DM.')] });
            }
        }
    }
};
