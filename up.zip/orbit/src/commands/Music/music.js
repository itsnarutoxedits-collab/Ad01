const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const embed = require('../../functions/embedHelper');
const spotify = require('../../functions/spotifyHelper');
const configManager = require('../../functions/musicConfigManager');

const controlCommands = [
    { name: 'play', desc: 'Play a song', stringOption: 'query' },
    { name: 'tts', desc: 'Play TTS message', stringOption: 'text' },
    { name: 'nowplaying', desc: 'Show current song' },
    { name: 'queue', desc: 'Show music queue' },
    { name: 'history', desc: 'Show history' },
    { name: 'search', desc: 'Search for songs', stringOption: 'query' },
    { name: 'grab', desc: 'Save current song to DMs' },
    { name: 'stop', desc: 'Stop music' },
    { name: 'autoplay', desc: 'Toggle autoplay' },
    { name: 'join', desc: 'Join voice' },
    { name: 'leave', desc: 'Leave voice' },
    { name: 'forcefix', desc: 'Force fix connection' },
    { name: 'pause', desc: 'Pause song' },
    { name: 'resume', desc: 'Resume song' },
    { name: 'replay', desc: 'Replay song' },
    { name: 'shuffle', desc: 'Shuffle queue' },
    { name: 'clearqueue', desc: 'Clear queue' },
    { name: 'volume', desc: 'Adjust volume', intOption: 'amount' }
];

const adjustCommands = [
    { name: 'skip', desc: 'Skip current song' },
    { name: 'skipinto', desc: 'Skip into position', intOption: 'position' },
    { name: 'seek', desc: 'Seek to time', stringOption: 'time' },
    { name: 'remove', desc: 'Remove from queue', intOption: 'index' },
    { name: 'move', desc: 'Move in queue', intOption: 'from', intOption2: 'to' },
    { name: 'loop', desc: 'Loop song' },
    { name: 'loopqueue', desc: 'Loop queue' }
];

const configGroups = [
    { name: 'filter', desc: 'Manage filters', subs: [{ name: 'toggle', opt: 'filter' }, { name: 'reset' }, { name: 'show' }] },
    { name: 'djrole', desc: 'Manage DJ roles', subs: [{ name: 'show' }, { name: 'clear' }, { name: 'set', role: true }] },
    { name: 'source', desc: 'Manage sources', subs: [{ name: 'show' }, { name: 'set', opt: 'source' }] },
    { name: '247', desc: 'Manage 24/7', subs: [{ name: 'enable' }, { name: 'disable' }, { name: 'channel', channel: true }] },
    { name: 'djmix', desc: 'Manage DJ mix', subs: [{ name: 'show' }, { name: 'enable' }, { name: 'disable' }] }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('music')
        .setDescription('Music system controls')
        .addSubcommandGroup(group => {
            group.setName('control').setDescription('General music controls');
            controlCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    return sub;
                });
            });
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('edit').setDescription('Adjust current queue/playback');
            adjustCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    if (cmd.intOption2) sub.addIntegerOption(o => o.setName(cmd.intOption2).setDescription('Target').setRequired(true));
                    return sub;
                });
            });
            return group;
        }),
    async execute(interaction) {
        const client = interaction.client;
        const channel = interaction.member.voice.channel;
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();

        if (!channel) return interaction.reply({ embeds: [embed.error('❌ You must be in a voice channel.')], ephemeral: true });

        // Helper for queue
        const queue = client.distube.getQueue(interaction.guildId);

        if (group === 'control') {
            if (sub === 'play') {
                const query = interaction.options.getString('query');
                await interaction.deferReply();
                let finalQuery = query;
                const spotifyUrl = await spotify.searchTrack(query);
                if (spotifyUrl) {
                    finalQuery = spotifyUrl;
                    console.log(`[SpotifySearch] Resolved "${query}" to ${spotifyUrl}`);
                }
                try {
                    await client.distube.play(channel, finalQuery, {
                        member: interaction.member,
                        textChannel: interaction.channel
                    });
                    await interaction.editReply({ embeds: [embed.info('🔎 Request received...')] });
                    setTimeout(() => interaction.deleteReply().catch(() => { }), 3000);
                } catch (e) {
                    await interaction.editReply({ embeds: [embed.error(`❌ Error: ${e.message}`)] });
                }
            } else if (sub === 'stop') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.stop();
                return interaction.reply({ embeds: [embed.success('⏹ Stopped music and left.')] });
            } else if (sub === 'pause') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.pause();
                return interaction.reply({ embeds: [embed.success('⏸ Paused.')] });
            } else if (sub === 'resume') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.resume();
                return interaction.reply({ embeds: [embed.success('▶ Resumed.')] });
            } else if (sub === 'queue') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const q = queue.songs.map((song, i) => `${i === 0 ? 'Playing:' : `${i}.`} ${song.name} - \`${song.formattedDuration}\``).join('\n');
                const trimmed = q.length > 1900 ? q.slice(0, 1900) + '...' : q;
                return interaction.reply({ embeds: [embed.info(`**Queue**\n${trimmed}`)] });
            } else if (sub === 'join') {
                try {
                    await client.distube.voices.join(channel);
                    return interaction.reply({ embeds: [embed.success('👋 Joined voice channel.')] });
                } catch (e) {
                    return interaction.reply({ embeds: [embed.error(`❌ Error: ${e.message}`)] });
                }
            } else if (sub === 'leave') {
                client.distube.voices.leave(interaction.guildId);
                return interaction.reply({ embeds: [embed.success('👋 Left voice channel.')] });
            } else if (sub === 'replay') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                await queue.seek(0);
                return interaction.reply({ embeds: [embed.success('⏮ Replaying track.')] });
            } else if (sub === 'shuffle') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                await queue.shuffle();
                return interaction.reply({ embeds: [embed.success('🔀 Queue shuffled.')] });
            } else if (sub === 'clearqueue') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.songs.splice(1);
                return interaction.reply({ embeds: [embed.success('🗑 Queue cleared.')] });
            } else if (sub === 'autoplay') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const mode = queue.toggleAutoplay();
                return interaction.reply({ embeds: [embed.success(`♾ Autoplay: **${mode ? 'On' : 'Off'}**`)] });
            } else if (sub === 'history') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing/No history.')], ephemeral: true });
                const history = queue.previousSongs.map((s, i) => `${i + 1}. ${s.name}`).slice(-10).reverse().join('\n');
                return interaction.reply({ embeds: [embed.info(`**History (Last 10)**\n${history || 'None'}`)] });
            } else if (sub === 'grab') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const song = queue.songs[0];
                try {
                    await interaction.user.send({ embeds: [embed.info(`**Song Saved** 💾\n[${song.name}](${song.url})`)] });
                    return interaction.reply({ embeds: [embed.success('📩 Sent to DMs.')], ephemeral: true });
                } catch {
                    return interaction.reply({ embeds: [embed.error('❌ Could not DM you.')], ephemeral: true });
                }
            } else if (sub === 'tts') {
                const text = interaction.options.getString('text');
                const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=${encodeURIComponent(text)}&tl=en`;
                await client.distube.play(channel, url, { member: interaction.member, textChannel: interaction.channel });
                return interaction.reply({ embeds: [embed.success('🗣 Playing TTS.')] });
            }
            else if (sub === 'volume') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const vol = interaction.options.getInteger('amount');
                queue.setVolume(vol);
                return interaction.reply({ embeds: [embed.success(`🔊 Volume set to \`${vol}%\``)] });
            } else if (sub === 'forcefix') {
                try {
                    const voice = client.distube.voices.get(interaction.guildId);
                    if (voice) {
                        voice.leave();
                        setTimeout(() => client.distube.voices.join(channel), 1000);
                        return interaction.reply({ embeds: [embed.success('🔧 Attempting to fix connection...')] });
                    }
                    return interaction.reply({ embeds: [embed.error('❌ No connection to fix.')] });
                } catch (e) {
                    return interaction.reply({ embeds: [embed.error(`❌ Error: ${e.message}`)] });
                }
            } else if (sub === 'nowplaying') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const song = queue.songs[0];
                return interaction.reply({ embeds: [embed.info(`🎶 Now Playing: **${song.name}**\nDuration: \`${song.formattedDuration}\``)] });
            }
        } else if (group === 'edit') {
            if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });

            if (sub === 'skip') {
                try {
                    await queue.skip();
                    return interaction.reply({ embeds: [embed.success('⏭ Skipped.')] });
                } catch (e) {
                    if (queue.songs.length === 1 && !queue.autoplay) {
                        queue.stop();
                        return interaction.reply({ embeds: [embed.success('⏹ Queue finished (no next song).')] });
                    }
                    return interaction.reply({ embeds: [embed.error('❌ No more songs to skip to (or error).')] });
                }
            } else if (sub === 'loop') {
                const mode = queue.repeatMode === 1 ? 0 : 1;
                queue.setRepeatMode(mode);
                return interaction.reply({ embeds: [embed.success(mode === 1 ? '🔁 Loop enabled for song.' : '➡ Loop disabled.')] });
            } else if (sub === 'loopqueue') {
                const mode = queue.repeatMode === 2 ? 0 : 2;
                queue.setRepeatMode(mode);
                return interaction.reply({ embeds: [embed.success(mode === 2 ? '🔁 Loop enabled for queue.' : '➡ Loop disabled.')] });
            } else if (sub === 'remove') {
                const index = interaction.options.getInteger('index');
                if (index < 1 || index >= queue.songs.length) return interaction.reply({ embeds: [embed.error('❌ Invalid index.')], ephemeral: true });
                const song = queue.songs.splice(index, 1)[0];
                return interaction.reply({ embeds: [embed.success(`🗑 Removed **${song.name}** from queue.`)] });
            } else if (sub === 'move') {
                const from = interaction.options.getInteger('from');
                const to = interaction.options.getInteger('to');
                if (from < 1 || from >= queue.songs.length || to < 1 || to >= queue.songs.length) {
                    return interaction.reply({ embeds: [embed.error('❌ Invalid indexes.')], ephemeral: true });
                }
                const song = queue.songs.splice(from, 1)[0];
                queue.songs.splice(to, 0, song);
                return interaction.reply({ embeds: [embed.success(`➡ Moved **${song.name}** to position ${to}.`)] });
            } else if (sub === 'seek') {
                const timeStr = interaction.options.getString('time');
                const parts = timeStr.split(':').reverse();
                let seconds = 0;
                if (parts[0]) seconds += parseInt(parts[0]);
                if (parts[1]) seconds += parseInt(parts[1]) * 60;
                if (parts[2]) seconds += parseInt(parts[2]) * 3600;

                await queue.seek(seconds);
                return interaction.reply({ embeds: [embed.success(`⏩ Seeked to \`${timeStr}\``)] });
            } else if (sub === 'skipinto') {
                const pos = interaction.options.getInteger('position');
                if (pos < 1 || pos >= queue.songs.length) return interaction.reply({ embeds: [embed.error('❌ Invalid position.')], ephemeral: true });
                await queue.jump(pos);
                return interaction.reply({ embeds: [embed.success(`⏭ Skipped to position ${pos}.`)] });
            }
        } else {
            // Config logic (already correct in file, no need to duplicate in diff, but writing full file)
            const config = configManager.getGuildConfig(interaction.guildId);
            if (group === 'filter') {
                if (sub === 'toggle') {
                    if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                    const filter = interaction.options.getString('filter');
                    if (!client.distube.filters.names.includes(filter)) return interaction.reply({ embeds: [embed.error(`❌ Invalid filter. Available: \`${client.distube.filters.names.slice(0, 10).join(', ')}...\``)], ephemeral: true });
                    if (queue.filters.has(filter)) {
                        queue.filters.remove(filter);
                        return interaction.reply({ embeds: [embed.success(`📉 Disabled filter **${filter}**`)] });
                    } else {
                        queue.filters.add(filter);
                        return interaction.reply({ embeds: [embed.success(`📈 Enabled filter **${filter}**`)] });
                    }
                } else if (sub === 'reset') {
                    if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                    queue.filters.clear();
                    return interaction.reply({ embeds: [embed.success('📉 Cleared all filters.')] });
                } else if (sub === 'show') {
                    if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                    const active = queue.filters.names.join(', ') || 'None';
                    return interaction.reply({ embeds: [embed.info(`**Active Filters:**\n${active}`)] });
                }
            }
            else if (group === 'djrole') {
                if (sub === 'set') {
                    const role = interaction.options.getRole('role');
                    if (config.djRoles.includes(role.id)) return interaction.reply({ embeds: [embed.error('Role already accepted.')] });
                    config.djRoles.push(role.id);
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success(`✅ Added ${role} to DJ roles.`)] });
                } else if (sub === 'clear') {
                    config.djRoles = [];
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success('✅ Cleared DJ roles.')] });
                } else if (sub === 'show') {
                    const roles = config.djRoles.map(r => `<@&${r}>`).join(', ') || 'None';
                    return interaction.reply({ embeds: [embed.info(`**DJ Roles:**\n${roles}`)] });
                }
            }
            else if (group === '247') {
                if (sub === 'enable') {
                    config.alwaysOn.enabled = true;
                    if (channel) config.alwaysOn.channelId = channel.id;
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    if (channel) client.distube.voices.join(channel);
                    return interaction.reply({ embeds: [embed.success('✅ 24/7 Mode Enabled.')] });
                } else if (sub === 'disable') {
                    config.alwaysOn.enabled = false;
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success('❌ 24/7 Mode Disabled.')] });
                } else if (sub === 'channel') {
                    const ch = interaction.options.getChannel('channel');
                    config.alwaysOn.channelId = ch.id;
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success(`✅ 24/7 Channel set to ${ch}.`)] });
                }
            }
            else if (group === 'djmix') {
                if (sub === 'enable') {
                    config.djMix = true;
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success('✅ DJ Mix Enabled.')] });
                } else if (sub === 'disable') {
                    config.djMix = false;
                    configManager.saveGuildConfig(interaction.guild.id, config);
                    return interaction.reply({ embeds: [embed.success('❌ DJ Mix Disabled.')] });
                } else if (sub === 'show') {
                    return interaction.reply({ embeds: [embed.info(`**DJ Mix:** ${config.djMix ? 'Enabled' : 'Disabled'}`)] });
                }
            }
            else if (group === 'source') {
                if (sub === 'set') {
                    const src = interaction.options.getString('source');
                    return interaction.reply({ embeds: [embed.success(`✅ Source set preference to **${src}**.`)] });
                } else if (sub === 'show') {
                    return interaction.reply({ embeds: [embed.info(`**Sources:** All allowed (default)`)] });
                }
            }
        }
    },
    async executeMessage(message, args) {
        const client = message.client;
        const channel = message.member.voice.channel;
        if (!channel) return message.reply({ embeds: [embed.error('❌ You must be in a voice channel.')] });

        const sub = args[0] ? args[0].toLowerCase() : null;
        if (!sub) {
            // Fallback handled below
        }

        const queue = client.distube.getQueue(message.guildId);

        // --- Config Groups ---
        const configGroup = configGroups.find(g => g.name === sub);
        if (configGroup) {
            const subName = args[1] ? args[1].toLowerCase() : null;
            if (!subName) return message.reply({ embeds: [embed.info(`Usage: \`!music ${sub} <${configGroup.subs.map(s => s.name).join('/')}>\``)] });

            const config = configManager.getGuildConfig(message.guild.id);
            if (sub === 'filter') {
                if (!queue) return message.reply({ embeds: [embed.error('❌ Nothing playing.')] });
                if (subName === 'toggle') {
                    const filter = args[2];
                    if (!filter || !client.distube.filters.names.includes(filter)) return message.reply({ embeds: [embed.error(`❌ Invalid filter. Available: \`${client.distube.filters.names.slice(0, 10).join(', ')}...\``)] });
                    if (queue.filters.has(filter)) {
                        queue.filters.remove(filter);
                        return message.reply({ embeds: [embed.success(`📉 Disabled filter **${filter}**`)] });
                    } else {
                        queue.filters.add(filter);
                        return message.reply({ embeds: [embed.success(`📈 Enabled filter **${filter}**`)] });
                    }
                } else if (subName === 'reset') {
                    queue.filters.clear();
                    return message.reply({ embeds: [embed.success('📉 Cleared all filters.')] });
                } else if (subName === 'show') {
                    const active = queue.filters.names.join(', ') || 'None';
                    return message.reply({ embeds: [embed.info(`**Active Filters:**\n${active}`)] });
                }
            }
            else if (sub === 'djrole') {
                if (subName === 'set') {
                    const role = message.mentions.roles.first();
                    if (!role) return message.reply({ embeds: [embed.error('Mention a role.')] });
                    if (config.djRoles.includes(role.id)) return message.reply({ embeds: [embed.error('Role already accepted.')] });
                    config.djRoles.push(role.id);
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success(`✅ Added ${role} to DJ roles.`)] });
                } else if (subName === 'clear') {
                    config.djRoles = [];
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success('✅ Cleared DJ roles.')] });
                } else if (subName === 'show') {
                    const roles = config.djRoles.map(r => `<@&${r}>`).join(', ') || 'None';
                    return message.reply({ embeds: [embed.info(`**DJ Roles:**\n${roles}`)] });
                }
            }
            else if (sub === '247') {
                if (subName === 'enable') {
                    config.alwaysOn.enabled = true;
                    if (channel) config.alwaysOn.channelId = channel.id;
                    configManager.saveGuildConfig(message.guild.id, config);
                    client.distube.voices.join(channel);
                    return message.reply({ embeds: [embed.success('✅ 24/7 Mode Enabled.')] });
                } else if (subName === 'disable') {
                    config.alwaysOn.enabled = false;
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success('❌ 24/7 Mode Disabled.')] });
                } else if (subName === 'channel') {
                    const ch = message.mentions.channels.first() || channel;
                    config.alwaysOn.channelId = ch.id;
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success(`✅ 24/7 Channel set to ${ch}.`)] });
                }
            }
            else if (sub === 'djmix') {
                if (subName === 'enable') {
                    config.djMix = true;
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success('✅ DJ Mix Enabled.')] });
                } else if (subName === 'disable') {
                    config.djMix = false;
                    configManager.saveGuildConfig(message.guild.id, config);
                    return message.reply({ embeds: [embed.success('❌ DJ Mix Disabled.')] });
                } else if (subName === 'show') {
                    return message.reply({ embeds: [embed.info(`**DJ Mix:** ${config.djMix ? 'Enabled' : 'Disabled'}`)] });
                }
            }
            return;
        }

        // --- Commands ---

        if (sub === 'play') {
            const query = args.slice(1).join(' ');
            if (!query) return message.reply({ embeds: [embed.error('Usage: `!music play <url/name>`')] });
            let finalQuery = query;
            const spotifyUrl = await spotify.searchTrack(query);
            if (spotifyUrl) finalQuery = spotifyUrl;
            try {
                await client.distube.play(channel, finalQuery, { member: message.member, textChannel: message.channel });
                return message.react('🔎');
            } catch (e) { return message.reply({ embeds: [embed.error(`❌ Error: ${e.message}`)] }); }
        }
        else if (sub === 'stop' || sub === 'leave') {
            if (queue) queue.stop(); else client.distube.voices.leave(message.guildId);
            return message.react('⏹');
        }
        else if (sub === 'join') {
            try { await client.distube.voices.join(channel); return message.reply({ embeds: [embed.success('👋 Joined.')] }); } catch (e) { return message.reply({ embeds: [embed.error(e.message)] }); }
        }
        else if (sub === 'volume') {
            if (!queue) return message.reply({ embeds: [embed.error('Queue empty.')] });
            const vol = parseInt(args[1]);
            if (!vol || isNaN(vol)) return message.reply({ embeds: [embed.error('Usage: `!music volume <number>`')] });
            queue.setVolume(vol);
            return message.reply({ embeds: [embed.success(`🔊 Volume: \`${vol}%\``)] });
        }
        else if (sub === 'seek') {
            if (!queue) return message.reply({ embeds: [embed.error('Queue empty.')] });
            const timeStr = args[1];
            if (!timeStr) return message.reply({ embeds: [embed.error('Usage: `!music seek <mm:ss>`')] });
            const parts = timeStr.split(':').reverse();
            let seconds = 0;
            if (parts[0]) seconds += parseInt(parts[0]);
            if (parts[1]) seconds += parseInt(parts[1]) * 60;
            if (parts[2]) seconds += parseInt(parts[2]) * 3600;
            await queue.seek(seconds);
            return message.reply({ embeds: [embed.success(`⏩ Seeked.`)] });
        }
        else if (sub === 'queue') {
            if (!queue) return message.reply({ embeds: [embed.error('Queue empty.')] });
            const q = queue.songs.map((song, i) => `${i === 0 ? 'Playing:' : `${i}.`} ${song.name} - \`${song.formattedDuration}\``).join('\n');
            const trimmed = q.length > 1900 ? q.slice(0, 1900) + '...' : q;
            return message.reply({ embeds: [embed.info(`**Queue**\n${trimmed}`)] });
        }
        else if (sub === 'tts') {
            const text = args.slice(1).join(' ');
            if (!text) return message.reply({ embeds: [embed.error('Usage: `!music tts <text>`')] });
            const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=${encodeURIComponent(text)}&tl=en`;
            await client.distube.play(channel, url, { member: message.member, textChannel: message.channel });
            return message.react('🗣');
        }
        else if (sub === 'history') {
            if (!queue) return message.reply({ embeds: [embed.error('No history yet (playing first song or stopped).')] });
            const h = queue.previousSongs.map((s, i) => `${i + 1}. ${s.name}`).slice(-10).reverse().join('\n');
            return message.reply({ embeds: [embed.info(`**History**\n${h || 'None yet.'}`)] });
        }
        else if (sub === 'skip') {
            if (queue) {
                try {
                    await queue.skip();
                    return message.react('⏭');
                } catch (e) {
                    if (queue.songs.length <= 1 && !queue.autoplay) {
                        queue.stop();
                        return message.reply({ embeds: [embed.info('⏹ Queue finished.')] });
                    }
                    return message.reply({ embeds: [embed.error('❌ Error skipping: ' + e.message)] });
                }
            }
        }
        else if (['pause', 'resume', 'shuffle', 'autoplay', 'loop', 'loopqueue', 'clearqueue'].includes(sub)) {
            if (!queue) return message.reply({ embeds: [embed.error('Nothing playing.')] });
            if (sub === 'pause') { queue.pause(); return message.react('⏸'); }
            if (sub === 'resume') { queue.resume(); return message.react('▶'); }
            if (sub === 'shuffle') { await queue.shuffle(); return message.react('🔀'); }
            if (sub === 'autoplay') { const m = queue.toggleAutoplay(); return message.reply({ embeds: [embed.success(`Autoplay: ${m ? 'On' : 'Off'}`)] }); }
            if (sub === 'loop') { const m = queue.repeatMode === 1 ? 0 : 1; queue.setRepeatMode(m); return message.reply({ embeds: [embed.success(`Loop Song: ${m ? 'On' : 'Off'}`)] }); }
            if (sub === 'loopqueue') { const m = queue.repeatMode === 2 ? 0 : 2; queue.setRepeatMode(m); return message.reply({ embeds: [embed.success(`Loop Queue: ${m ? 'On' : 'Off'}`)] }); }
            if (sub === 'clearqueue') { queue.songs.splice(1); return message.reply({ embeds: [embed.success('Queue cleared.')] }); }
        }
        else if (sub === 'nowplaying') {
            if (!queue) return message.reply({ embeds: [embed.error('Nothing playing.')] });
            const s = queue.songs[0];
            return message.reply({ embeds: [embed.info(`🎶 **${s.name}** \`${s.formattedDuration}\``)] });
        }
        else if (sub === 'grab') {
            if (!queue) return message.reply({ embeds: [embed.error('Nothing playing.')] });
            const s = queue.songs[0];
            try { await message.author.send({ embeds: [embed.info(`**Saved**\n[${s.name}](${s.url})`)] }); return message.reply('📩'); } catch { return message.reply('❌ Can\'t DM.'); }
        }
        else {
            // Paginated Help Menu
            const allCmds = [];
            controlCommands.forEach(c => allCmds.push(`» **music ${c.name}** ${c.stringOption ? `<${c.stringOption}>` : ''} ${c.intOption ? `<${c.intOption}>` : ''}\n› ${c.desc}`));
            adjustCommands.forEach(c => allCmds.push(`» **music ${c.name}** ${c.stringOption ? `<${c.stringOption}>` : ''} ${c.intOption ? `<${c.intOption}>` : ''}\n› ${c.desc}`));
            configGroups.forEach(g => {
                g.subs.forEach(s => {
                    allCmds.push(`» **music ${g.name} ${s.name}** ${s.opt ? `<${s.opt}>` : ''}\n› ${s.name} ${g.name} settings.`);
                });
            });

            const itemsPerPage = 7;
            const totalPages = Math.ceil(allCmds.length / itemsPerPage);
            let currentPage = 0;

            const generateEmbed = (page) => {
                const start = page * itemsPerPage;
                const currentItems = allCmds.slice(start, start + itemsPerPage);
                return new EmbedBuilder()
                    .setTitle('🎵 Music Commands')
                    .setDescription(`\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n${currentItems.join('\n\n')}`)
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${page + 1}/${totalPages} | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            };

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('prev').setLabel('◀').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('next').setLabel('▶').setStyle(ButtonStyle.Secondary)
            );

            const msg = await message.reply({ embeds: [generateEmbed(0)], components: [row] });

            const collector = msg.createMessageComponentCollector({ time: 60000 });

            collector.on('collect', async i => {
                if (i.user.id !== message.author.id) return i.reply({ content: '❌ Not your menu.', ephemeral: true });

                if (i.customId === 'prev') {
                    currentPage = currentPage > 0 ? currentPage - 1 : totalPages - 1;
                } else if (i.customId === 'next') {
                    currentPage = currentPage < totalPages - 1 ? currentPage + 1 : 0;
                }

                await i.update({ embeds: [generateEmbed(currentPage)] });
            });

            collector.on('end', () => msg.edit({ components: [] }).catch(() => { }));
            return;
        }
    }
};

configGroups.forEach(g => {
    module.exports.data.addSubcommandGroup(group => {
        group.setName(g.name).setDescription(g.desc);
        g.subs.forEach(s => {
            group.addSubcommand(sub => {
                sub.setName(s.name).setDescription(s.name);
                if (s.opt) sub.addStringOption(o => o.setName(s.opt).setDescription('Value').setRequired(true));
                if (s.role) sub.addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true));
                if (s.channel) sub.addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true));
                return sub;
            });
        });
        return group;
    });
});
