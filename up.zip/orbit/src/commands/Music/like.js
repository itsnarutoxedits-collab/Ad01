const { SlashCommandBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');
const playlistMgr = require('../../functions/playlistManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('like')
        .setDescription('Add current song to Liked Songs'),

    async execute(interaction) {
        await this.handle(interaction, interaction.client);
    },

    async executeMessage(message) {
        await this.handle(message, message.client);
    },

    async handle(ctx, client) {
        const user = ctx.author || ctx.user;
        const reply = (c) => ctx.reply(c);

        const queue = client.distube.getQueue(ctx.guildId);
        if (!queue || !queue.songs[0]) return reply({ embeds: [embed.error('❌ Nothing playing.')] });

        const song = queue.songs[0];
        const playlistName = 'Liked Songs';

        playlistMgr.addSong(user.id, playlistName, song);
        return reply({ embeds: [embed.success(`❤️ Added **${song.name}** to **Liked Songs**.`)] });
    }
};
