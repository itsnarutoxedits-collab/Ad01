const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('roleicon')
        .setDescription('Set an icon for a role (Server Boost Level 2+ required)')
        .addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true))
        .addStringOption(opt => opt.setName('emoji').setDescription('The emoji/icon to set').setRequired(true)),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({ embeds: [embedHelper.error('❌ You need `Manage Roles` permission.')], ephemeral: true });
        }

        if (interaction.guild.premiumTier < 2) {
            return interaction.reply({ embeds: [embedHelper.error('❌ Server must be Boost Level 2 to use role icons.')], ephemeral: true });
        }

        const role = interaction.options.getRole('role');
        const emoji = interaction.options.getString('emoji');

        // Check Hierarchy
        if (role.position >= interaction.member.roles.highest.position && interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ embeds: [embedHelper.error('❌ You can only manage roles lower than your highest role.')], ephemeral: true });
        }

        await setRoleIcon(interaction, role, emoji);
    },

    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply({ embeds: [embedHelper.error('❌ You need `Manage Roles` permission.')] });
        }

        if (message.guild.premiumTier < 2) {
            return message.reply({ embeds: [embedHelper.error('❌ Server must be Boost Level 2 to use role icons.')] });
        }

        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
        const emoji = args[1];

        if (!role || !emoji) {
            return message.reply({ embeds: [embedHelper.info('Usage: `!roleicon <@role> <emoji>`')] });
        }

        if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
            return message.reply({ embeds: [embedHelper.error('❌ You can only manage roles lower than your highest role.')] });
        }

        await setRoleIcon(message, role, emoji);
    }
};

async function setRoleIcon(context, role, emojiInput) {
    try {
        // Regex for custom emojis <a:name:id> or <:name:id>
        const emojiRegex = /<?(a)?:?(\w{2,32}):(\d{17,19})>?/;
        const match = emojiInput.match(emojiRegex);

        if (match) {
            // It's a custom emoji
            const emojiId = match[3];
            const isAnimated = match[1] === 'a'; // D.js roles support animated? Yes logic says png/jp etc.
            // Actually Role Icons must be static mostly, but let's try link.
            const url = `https://cdn.discordapp.com/emojis/${emojiId}.png`; // Roles usually require png/jpg

            await role.setIcon(url);

            const success = embedHelper.success(`✅ Role icon for ${role} has been set!`);
            return context.reply ? context.reply({ embeds: [success] }) : context.channel.send({ embeds: [success] });

        } else {
            // Unicode emoji?
            // role.setIcon(emojiInput) works for unicode? Documentation says buffer or base64. 
            // Actually role.setUnicodeEmoji(emojiInput) exists for unicode emojis if separate.
            // But let's assume they mean custom icon mostly.
            // If strictly unicode, we use setUnicodeEmoji.

            // Basic detection
            if (/\p{Extended_Pictographic}/u.test(emojiInput)) {
                await role.setUnicodeEmoji(emojiInput);
                const success = embedHelper.success(`✅ Role unicode emoji for ${role} has been set!`);
                return context.reply ? context.reply({ embeds: [success] }) : context.channel.send({ embeds: [success] });
            }

            return context.reply
                ? context.reply({ embeds: [embedHelper.error('❌ Invalid emoji. Please use a custom emoji from this server or a standard unicode emoji.')], ephemeral: true })
                : context.channel.send({ embeds: [embedHelper.error('❌ Invalid emoji.')] });
        }

    } catch (e) {
        console.error(e);
        const errEmbed = embedHelper.error('❌ Failed to set role icon. Check my permissions or if the emoji is valid.');
        return context.reply ? context.reply({ embeds: [errEmbed], ephemeral: true }) : context.channel.send({ embeds: [errEmbed] });
    }
}
