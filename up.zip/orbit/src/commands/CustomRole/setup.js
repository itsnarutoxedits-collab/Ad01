const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const manager = require('../../functions/customRoleManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Advanced Custom Role Setup')
        .addSubcommandGroup(group =>
            group.setName('reqrole')
                .setDescription('Manage required roles to use custom commands')
                .addSubcommand(sub => sub.setName('show').setDescription('Show required roles'))
                .addSubcommand(sub => sub.setName('add').setDescription('Add a required role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove').setDescription('Remove a required role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
                .addSubcommand(sub => sub.setName('reset').setDescription('Clear all required roles'))
        )
        .addSubcommand(sub => sub.setName('staff').setDescription('Set Staff role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('vip').setDescription('Set VIP role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('guest').setDescription('Set Guest role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('friend').setDescription('Set Friend role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('girl').setDescription('Set Girl role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('create').setDescription('Create a dynamic custom role').addStringOption(opt => opt.setName('name').setDescription('Command name').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role to give').setRequired(true)))
        .addSubcommand(sub => sub.setName('delete').setDescription('Delete a dynamic custom role').addStringOption(opt => opt.setName('name').setDescription('Command name').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List all configuration'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset entire guild configuration')),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Administrator only.', flags: MessageFlags.Ephemeral });
        }

        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        const config = manager.getGuildConfig(guildId);

        // --- REQROLE GROUP ---
        if (group === 'reqrole') {
            if (sub === 'show') {
                const roles = config.reqroles;
                if (roles.length === 0) return interaction.reply({ embeds: [embedHelper.info('No required roles set (Everyone can use commands, or only Admins depending on command).')] });
                const desc = roles.map(r => `<@&${r}>`).join('\n');
                return interaction.reply({ embeds: [embedHelper.info(`**Required Roles:**\n${desc}`)] });
            }
            if (sub === 'add') {
                const role = interaction.options.getRole('role');
                if (config.reqroles.includes(role.id)) return interaction.reply({ embeds: [embedHelper.error('Role already in required list.')] });
                config.reqroles.push(role.id);
                manager.saveGuildConfig(guildId, config);
                return interaction.reply({ embeds: [embedHelper.success(`Added ${role} to required roles.`)] });
            }
            if (sub === 'remove') {
                const role = interaction.options.getRole('role');
                const idx = config.reqroles.indexOf(role.id);
                if (idx === -1) return interaction.reply({ embeds: [embedHelper.error('Role not found in required list.')] });
                config.reqroles.splice(idx, 1);
                manager.saveGuildConfig(guildId, config);
                return interaction.reply({ embeds: [embedHelper.success(`Removed ${role} from required roles.`)] });
            }
            if (sub === 'reset') {
                config.reqroles = [];
                manager.saveGuildConfig(guildId, config);
                return interaction.reply({ embeds: [embedHelper.success('Cleared all required roles.')] });
            }
        }

        // --- STATIC ROLES ---
        const staticTypes = ['staff', 'vip', 'guest', 'friend', 'girl'];
        if (staticTypes.includes(sub)) {
            const role = interaction.options.getRole('role');
            config.static[sub] = role.id;
            manager.saveGuildConfig(guildId, config);
            return interaction.reply({ embeds: [embedHelper.success(`Set **${sub}** role to ${role}.`)] });
        }

        // --- DYNAMIC ROLES ---
        if (sub === 'create') {
            const name = interaction.options.getString('name').toLowerCase();
            const role = interaction.options.getRole('role');

            // Check collisions
            if (config.dynamic.some(d => d.name === name)) return interaction.reply({ embeds: [embedHelper.error(`Command **${name}** already exists.`)] });
            if (staticTypes.includes(name)) return interaction.reply({ embeds: [embedHelper.error(`Name **${name}** is reserved for static roles.`)] });

            config.dynamic.push({ name, role: role.id });
            manager.saveGuildConfig(guildId, config);
            return interaction.reply({ embeds: [embedHelper.success(`Created custom command **${name}** for ${role}.`)] });
        }

        if (sub === 'delete') {
            const name = interaction.options.getString('name').toLowerCase();
            const idx = config.dynamic.findIndex(d => d.name === name);
            if (idx === -1) return interaction.reply({ embeds: [embedHelper.error(`Command **${name}** not found.`)] });

            config.dynamic.splice(idx, 1);
            manager.saveGuildConfig(guildId, config);
            return interaction.reply({ embeds: [embedHelper.success(`Deleted custom command **${name}**.`)] });
        }

        if (sub === 'list') {
            const staticList = Object.entries(config.static)
                .map(([k, v]) => `**${k}**: ${v ? `<@&${v}>` : 'Not set'}`)
                .join('\n');

            const dynamicList = config.dynamic.length > 0
                ? config.dynamic.map(d => `**${d.name}**: <@&${d.role}>`).join('\n')
                : 'None';

            const reqList = config.reqroles.length > 0
                ? config.reqroles.map(r => `<@&${r}>`).join(', ')
                : 'None';

            const embed = new EmbedBuilder()
                .setTitle('Setup Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Required Roles', value: reqList },
                    { name: 'Static Roles', value: staticList, inline: true },
                    { name: 'Dynamic Roles', value: dynamicList, inline: true }
                );
            return interaction.reply({ embeds: [embed] });
        }

        if (sub === 'reset') {
            // Full reset
            const empty = { reqroles: [], static: { staff: null, vip: null, guest: null, friend: null, girl: null }, dynamic: [] };
            manager.saveGuildConfig(guildId, empty);
            return interaction.reply({ embeds: [embedHelper.success('Configuration reset to default.')] });
        }
    },

    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({ embeds: [embedHelper.error('❌ Administrator only.')] });
        }

        const guildId = message.guild.id;
        const config = manager.getGuildConfig(guildId);
        const group = args[0] ? args[0].toLowerCase() : null;

        // Reqrole special handling for prefix: !setup reqrole add @role
        if (group === 'reqrole') {
            const action = args[1] ? args[1].toLowerCase() : 'show';

            if (action === 'show') {
                const roles = config.reqroles;
                if (roles.length === 0) return message.reply({ embeds: [embedHelper.info('No required roles set.')] });
                return message.reply({ embeds: [embedHelper.info(`**Required Roles:**\n${roles.map(r => `<@&${r}>`).join('\n')}`)] });
            }
            if (action === 'add') {
                const role = message.mentions.roles.first();
                if (!role) return message.reply({ embeds: [embedHelper.error('Usage: `!setup reqrole add @role`')] });
                if (config.reqroles.includes(role.id)) return message.reply({ embeds: [embedHelper.error('Role already added.')] });
                config.reqroles.push(role.id);
                manager.saveGuildConfig(guildId, config);
                return message.reply({ embeds: [embedHelper.success(`Added ${role} to reqroles.`)] });
            }
            if (action === 'remove') {
                const role = message.mentions.roles.first();
                if (!role) return message.reply({ embeds: [embedHelper.error('Usage: `!setup reqrole remove @role`')] });
                const idx = config.reqroles.indexOf(role.id);
                if (idx === -1) return message.reply({ embeds: [embedHelper.error('Role not in list.')] });
                config.reqroles.splice(idx, 1);
                manager.saveGuildConfig(guildId, config);
                return message.reply({ embeds: [embedHelper.success(`Removed ${role} from reqroles.`)] });
            }
            if (action === 'reset') {
                config.reqroles = [];
                manager.saveGuildConfig(guildId, config);
                return message.reply({ embeds: [embedHelper.success('Reset reqroles.')] });
            }
            return;
        }

        // Static Roles
        const staticTypes = ['staff', 'vip', 'guest', 'friend', 'girl'];
        if (staticTypes.includes(group)) {
            const role = message.mentions.roles.first();
            if (!role) return message.reply({ embeds: [embedHelper.error(`Usage: \`!setup ${group} @role\``)] });
            config.static[group] = role.id;
            manager.saveGuildConfig(guildId, config);
            return message.reply({ embeds: [embedHelper.success(`Set **${group}** role to ${role}.`)] });
        }

        // Dynamic
        if (group === 'create') {
            const name = args[1];
            const role = message.mentions.roles.first();
            if (!name || !role) return message.reply({ embeds: [embedHelper.error('Usage: `!setup create <name> @role`')] });

            const lowerName = name.toLowerCase();
            if (config.dynamic.some(d => d.name === lowerName)) return message.reply({ embeds: [embedHelper.error('Already exists.')] });
            if (staticTypes.includes(lowerName)) return message.reply({ embeds: [embedHelper.error('Reserved name.')] });

            config.dynamic.push({ name: lowerName, role: role.id });
            manager.saveGuildConfig(guildId, config);
            return message.reply({ embeds: [embedHelper.success(`Created **${lowerName}** for ${role}.`)] });
        }

        if (group === 'delete') {
            const name = args[1];
            if (!name) return message.reply({ embeds: [embedHelper.error('Usage: `!setup delete <name>`')] });
            const lowerName = name.toLowerCase();
            const idx = config.dynamic.findIndex(d => d.name === lowerName);
            if (idx === -1) return message.reply({ embeds: [embedHelper.error('Not found.')] });

            config.dynamic.splice(idx, 1);
            manager.saveGuildConfig(guildId, config);
            return message.reply({ embeds: [embedHelper.success(`Deleted **${lowerName}**.`)] });
        }

        if (group === 'list') {
            // Reuse list logic from slash
            const staticList = Object.entries(config.static)
                .map(([k, v]) => `**${k}**: ${v ? `<@&${v}>` : 'Not set'}`)
                .join('\n');
            const dynamicList = config.dynamic.length > 0
                ? config.dynamic.map(d => `**${d.name}**: <@&${d.role}>`).join('\n')
                : 'None';
            const reqList = config.reqroles.length > 0
                ? config.reqroles.map(r => `<@&${r}>`).join(', ')
                : 'None';

            const embed = new EmbedBuilder()
                .setTitle('Setup Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Required Roles', value: reqList },
                    { name: 'Static Roles', value: staticList, inline: true },
                    { name: 'Dynamic Roles', value: dynamicList, inline: true }
                );
            return message.reply({ embeds: [embed] });
        }

        if (group === 'reset') {
            const empty = { reqroles: [], static: { staff: null, vip: null, guest: null, friend: null, girl: null }, dynamic: [] };
            manager.saveGuildConfig(guildId, empty);
            return message.reply({ embeds: [embedHelper.success('Configuration reset.')] });
        }

        // Help
        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **setup reqrole <show|add|remove> [role]**\n› Manage require roles.\n\n` +
                `» **setup <staff|vip|guest|friend|girl> <role>**\n› Set static roles.\n\n` +
                `» **setup create <name> <role>**\n› Create dynamic alias.\n\n` +
                `» **setup delete <name>**\n› Delete dynamic alias.\n\n` +
                `» **setup list**\n› View config.\n\n` +
                `» **setup reset**\n› Reset all.`
            )
            .setColor('#2b2d31');
        return message.reply({ embeds: [helpEmbed] });
    }
};
