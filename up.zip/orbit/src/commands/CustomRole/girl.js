const { SlashCommandBuilder, MessageFlags, EmbedBuilder } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const manager = require('../../functions/customRoleManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('girl')
        .setDescription('Give/Remove Girl role to a user')
        .addUserOption(opt => opt.setName('user').setDescription('User').setRequired(true)),

    async execute(interaction) {
        const guildId = interaction.guild.id;
        if (!manager.checkPermission(interaction.member, guildId)) {
            return interaction.reply({ content: '❌ You need the Required Role or Manage Roles permission.', flags: MessageFlags.Ephemeral });
        }

        const config = manager.getGuildConfig(guildId);
        const roleId = config.static.girl;

        if (!roleId) return interaction.reply({ content: '❌ Girl role not configured. Use `/setup girl <role>`', flags: MessageFlags.Ephemeral });

        const member = interaction.options.getMember('user');
        const role = interaction.guild.roles.cache.get(roleId);

        if (!role) return interaction.reply({ content: '❌ Configured role not found in server.', flags: MessageFlags.Ephemeral });

        if (member.roles.cache.has(roleId)) {
            await member.roles.remove(role);
            return interaction.reply({ embeds: [embedHelper.success(`Removed ${role} from ${member}.`)] });
        } else {
            await member.roles.add(role);
            return interaction.reply({ embeds: [embedHelper.success(`Added ${role} to ${member}.`)] });
        }
    },

    async executeMessage(message, args) {
        const guildId = message.guild.id;
        if (!manager.checkPermission(message.member, guildId)) {
            return message.reply({ embeds: [embedHelper.error('❌ You need the Required Role or Manage Roles permission.')] });
        }

        const config = manager.getGuildConfig(guildId);
        const roleId = config.static.girl;

        if (!roleId) return message.reply({ embeds: [embedHelper.error('❌ Girl role not configured. Use `!setup girl @role`')] });

        const member = message.mentions.members.first();
        if (!member) return message.reply({ embeds: [embedHelper.error('Usage: `!girl @user`')] });

        const role = message.guild.roles.cache.get(roleId);
        if (!role) return message.reply({ embeds: [embedHelper.error('❌ Configured role not found.')] });

        if (member.roles.cache.has(roleId)) {
            await member.roles.remove(role);
            return message.reply({ embeds: [embedHelper.success(`Removed ${role} from ${member}.`)] });
        } else {
            await member.roles.add(role);
            return message.reply({ embeds: [embedHelper.success(`Added ${role} to ${member}.`)] });
        }
    }
};
