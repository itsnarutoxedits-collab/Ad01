require('dotenv').config();
const { Client, Collection, GatewayIntentBits, REST, Routes } = require('discord.js');
const fs = require('fs');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration
    ]
});
client.commands = new Collection();
client.commandArray = [];

const functionFolders = fs.readdirSync('./src/functions');
for (const file of functionFolders) {
    const mod = require(`./functions/${file}`);
    if (typeof mod === 'function') {
        try { mod(client); } catch (e) { console.error(`Error running initializer ./functions/${file}:`, e); }
    } else {
        // non-function exports (utilities) are loaded for use via require elsewhere
    }
}

client.handleEvents(fs.readdirSync('./src/events').filter(file => file.endsWith('.js')), './src/events');
client.handleCommands(fs.readdirSync('./src/commands'), './src/commands');

client.login(process.env.DISCORD_TOKEN).then(async () => {
    // Deploy commands
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    try {
        console.log('Started refreshing application (/) commands.');

        // This deploys global commands. For development, guild-specific is faster.
        // But for "Simple Bot" global is easier to understand (no guild ID needed).
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: client.commandArray },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error deploying commands:', JSON.stringify(error.rawError, null, 2));
    }
});
