const permit = require('./permitManager');

/**
 * Check if a member has permission to use owner/admin commands
 * @param {GuildMember} member - The member to check
 * @param {Guild} guild - The guild
 * @param {boolean} requireOwnerOnly - If true, only server owner and extra owners can use
 * @returns {boolean} - True if member has permission
 */
function hasPermission(member, guild, requireOwnerOnly = false) {
    // Server owner always has permission
    if (member.id === guild.ownerId) return true;

    // Extra owners always have permission
    const extraOwners = permit.getExtraOwners(guild.id);
    if (extraOwners.includes(member.id)) return true;

    // If owner-only command, stop here
    if (requireOwnerOnly) return false;

    // Administrator permission
    if (member.permissions.has('Administrator')) return true;

    // Check if user's highest role is above bot's highest role
    const botMember = guild.members.cache.get(guild.client.user.id);
    if (botMember && member.roles.highest.position > botMember.roles.highest.position) {
        return true;
    }

    return false;
}

/**
 * Check if a member can manage the bot (owner or extra owner only)
 * @param {GuildMember} member - The member to check
 * @param {Guild} guild - The guild
 * @returns {boolean} - True if member is owner or extra owner
 */
function isOwnerOrExtraOwner(member, guild) {
    if (member.id === guild.ownerId) return true;
    const extraOwners = permit.getExtraOwners(guild.id);
    return extraOwners.includes(member.id);
}

/**
 * Check if a member has admin-level permissions
 * @param {GuildMember} member - The member to check
 * @param {Guild} guild - The guild
 * @returns {boolean} - True if member has admin permissions
 */
function hasAdminPermission(member, guild) {
    // Server owner
    if (member.id === guild.ownerId) return true;

    // Extra owners
    const extraOwners = permit.getExtraOwners(guild.id);
    if (extraOwners.includes(member.id)) return true;

    // Administrator permission
    if (member.permissions.has('Administrator')) return true;

    return false;
}

module.exports = {
    hasPermission,
    isOwnerOrExtraOwner,
    hasAdminPermission
};
