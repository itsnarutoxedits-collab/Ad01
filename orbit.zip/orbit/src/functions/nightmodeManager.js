const fs = require('fs');
const path = require('path');
const { PermissionsBitField } = require('discord.js');

const DATA_PATH = path.join(__dirname, '..', 'data', 'nightmode.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
} catch (e) {
    store = {};
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

/**
 * Enable Nightmode for a guild
 * Removes "Administrator" permission from all roles that have it (except bots/managed if we want, but Bitzxier logic is "manageable roles")
 * @param {Object} guild Discord Guild Object
 * @param {Object} client Discord Client (optional, for checking my role position)
 */
async function enableNightmode(guild) {
    if (store[guild.id] && store[guild.id].active) {
        return { success: false, message: 'Nightmode is already active.' };
    }

    // Identify roles to manage
    let me = guild.members.me;
    if (!me) me = await guild.members.fetchMe().catch(() => null);
    if (!me) return { success: false, message: 'I cannot find myself in this server.' };

    const myHigh = me.roles.highest.position;

    // Find roles with Admin that I can manage
    const targetRoles = guild.roles.cache.filter(role =>
        role.permissions.has(PermissionsBitField.Flags.Administrator) &&
        role.position < myHigh &&
        !role.managed && // Don't touch bot integration roles
        role.id !== guild.id // @everyone usually doesn't have admin, but safe check
    );

    if (targetRoles.size === 0) {
        return { success: false, message: 'No manageable roles with Administrator permission found.' };
    }

    const backup = {};

    // Execute removal
    let modifiedCount = 0;
    for (const [id, role] of targetRoles) {
        try {
            // Backup
            backup[id] = role.permissions.bitfield.toString();

            // Remove Admin
            const newPerms = role.permissions.remove(PermissionsBitField.Flags.Administrator);
            await role.setPermissions(newPerms, 'Nightmode Enabled - Security Lockdown');
            modifiedCount++;
        } catch (e) {
            console.error(`Failed to modify role ${role.name}:`, e);
        }
    }

    // Save state
    store[guild.id] = {
        active: true,
        backup: backup,
        timestamp: Date.now()
    };
    saveStore();

    return { success: true, count: modifiedCount };
}

/**
 * Disable Nightmode and restore permissions
 * @param {Object} guild 
 */
async function disableNightmode(guild) {
    if (!store[guild.id] || !store[guild.id].active) {
        return { success: false, message: 'Nightmode is not active.' };
    }

    const backup = store[guild.id].backup;
    let restoredCount = 0;

    for (const roleId of Object.keys(backup)) {
        const role = guild.roles.cache.get(roleId);
        if (role) {
            try {
                // We only restore if we have the permission string. 
                // However, Bitzxier restores the *exact* old bitfield.
                // It's safer to just ADD Administrator back if it was there? 
                // Or set exactly? "setPermissions" sets exact. 
                // Let's set exact to be safe to original state.
                const oldPerms = BigInt(backup[roleId]);
                await role.setPermissions(oldPerms, 'Nightmode Disabled - Restoration');
                restoredCount++;
            } catch (e) {
                console.error(`Failed to restore role ${roleId}:`, e);
            }
        }
    }

    // clear state
    delete store[guild.id];
    saveStore();

    return { success: true, count: restoredCount };
}

function getStatus(guildId) {
    return store[guildId] ? store[guildId].active : false;
}

module.exports = {
    enableNightmode,
    disableNightmode,
    getStatus
};
