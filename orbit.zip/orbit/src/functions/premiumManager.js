const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'premium.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({ users: {}, activatedGuilds: [] }), 'utf8');
}

ensureDataFile();

let store = { users: {}, activatedGuilds: [] };
try {
    const raw = fs.readFileSync(DATA_PATH, 'utf8');
    const parsed = JSON.parse(raw);

    // Migration check: if 'users' is an array, convert to object
    if (Array.isArray(parsed.users)) {
        const newUsers = {};
        parsed.users.forEach(id => {
            newUsers[id] = {
                expires: Date.now() + (365 * 24 * 60 * 60 * 1000), // Default 1 year for legacy
                count: 5, // Default 5 keys for legacy
                maxKeys: 5
            };
        });
        store = { users: newUsers, activatedGuilds: parsed.guilds || [] };
        console.log('Migrated Premium JSON structure.');
        saveStore();
    } else {
        store = parsed;
    }
} catch (e) {
    store = { users: {}, activatedGuilds: [] };
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

/**
 * Add or extend premium for a user
 * @param {string} userId 
 * @param {number} durationDays 
 * @param {number} count Max server count (keys)
 */
function addPremiumUser(userId, durationDays, count) {
    const durationMs = durationDays * 24 * 60 * 60 * 1000;
    const now = Date.now();

    if (!store.users[userId]) {
        store.users[userId] = {
            expires: now + durationMs,
            count: 0, // Keys used
            maxKeys: count
        };
    } else {
        // Extend time if not expired, or set new if expired
        const currentExp = store.users[userId].expires;
        if (currentExp > now) {
            store.users[userId].expires = currentExp + durationMs;
        } else {
            store.users[userId].expires = now + durationMs;
        }
        // Update limits
        store.users[userId].maxKeys = count;
    }
    saveStore();
    return store.users[userId];
}

function removePremiumUser(userId) {
    if (store.users[userId]) {
        delete store.users[userId];

        // Deactivate all guilds activated by this user?
        // Logic: Bitzxier usually keeps them until expiry or manual remove.
        // For strictness, we should remove them.
        store.activatedGuilds = store.activatedGuilds.filter(g => g.activatedBy !== userId);

        saveStore();
        return true;
    }
    return false;
}

function getPremiumUser(userId) {
    if (!store.users[userId]) return null;
    const data = store.users[userId];
    if (Date.now() > data.expires) {
        // Expired
        removePremiumUser(userId);
        return null;
    }
    return data;
}

/**
 * Activate premium for a guild using a user's key
 * @param {string} guildId 
 * @param {string} userId 
 */
function activateGuild(guildId, userId) {
    const user = getPremiumUser(userId);
    if (!user) return { success: false, message: 'You do not have premium.' };

    if (user.count >= user.maxKeys) return { success: false, message: 'You have used all your premium keys.' };

    const existing = store.activatedGuilds.find(g => g.id === guildId);
    if (existing) return { success: false, message: 'This server is already premium.' };

    // Activate
    user.count++;
    store.activatedGuilds.push({
        id: guildId,
        activatedBy: userId,
        activatedAt: Date.now()
    });
    saveStore();
    return { success: true };
}

/**
 * Deactivate premium for a guild
 * @param {string} guildId 
 * @param {string} userId Requesting user (must be the activator or global owner)
 */
function deactivateGuild(guildId, userId) {
    const index = store.activatedGuilds.findIndex(g => g.id === guildId);
    if (index === -1) return { success: false, message: 'This server is not premium.' };

    const data = store.activatedGuilds[index];

    // Check ownership of key
    // If userId provided, verify match (unless forcefully by admin, handled outside)
    if (userId && data.activatedBy !== userId) return { success: false, message: 'You did not activate premium on this server.' };

    // Restore key to user
    const user = store.users[data.activatedBy]; // Don't check expiry here, just decrement count
    if (user) {
        user.count = Math.max(0, user.count - 1);
    }

    store.activatedGuilds.splice(index, 1);
    saveStore();
    return { success: true };
}

function isGuildPremium(guildId) {
    const data = store.activatedGuilds.find(g => g.id === guildId);
    if (!data) return false;

    // Check if activator is still valid
    const user = getPremiumUser(data.activatedBy);
    if (!user) {
        // Activator expired, remove guild
        deactivateGuild(guildId, null);
        return false;
    }
    return true;
}

function getStats() {
    const now = Date.now();
    // Prune expired on stat check (lazy)
    const activeUsers = Object.keys(store.users).filter(k => store.users[k].expires > now).length;
    return {
        users: activeUsers,
        guilds: store.activatedGuilds.length
    };
}

module.exports = {
    addPremiumUser,
    removePremiumUser,
    getPremiumUser,
    activateGuild,
    deactivateGuild,
    isGuildPremium,
    getStats
};
