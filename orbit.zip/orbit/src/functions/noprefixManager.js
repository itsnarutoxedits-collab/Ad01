const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/noprefix.json');

function loadRaw() {
    try {
        if (fs.existsSync(dataPath)) {
            const raw = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            return raw || {};
        }
    } catch (e) {
        console.error('Failed to load noprefix data:', e);
    }
    return {};
}

function saveRaw(data) {
    try {
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('Failed to save noprefix data:', e);
    }
}

function getGuildData(gid) {
    const raw = loadRaw();
    // Support legacy format { users: [] } stored at root by treating it as __global
    if (raw && Array.isArray(raw.users)) {
        // Return a view where __global applies to all guilds
        return { users: raw.users.slice(), enabled: true, _isGlobal: true };
    }

    if (!raw[gid]) return { users: [], enabled: true };
    return raw[gid];
}

function hasUser(gid, uid) {
    const gd = getGuildData(gid);
    return Array.isArray(gd.users) && gd.users.includes(uid);
}

function addUser(gid, uid) {
    const raw = loadRaw();
    if (raw && Array.isArray(raw.users)) {
        // Convert legacy global into explicit __global entry
        raw.__global = { users: raw.users.slice(), enabled: true };
        delete raw.users;
    }

    if (!raw[gid]) raw[gid] = { users: [], enabled: true };
    if (!raw[gid].users.includes(uid)) raw[gid].users.push(uid);
    saveRaw(raw);
}

function removeUser(gid, uid) {
    const raw = loadRaw();
    if (raw && Array.isArray(raw.users)) {
        raw.__global = { users: raw.users.slice(), enabled: true };
        delete raw.users;
    }
    if (!raw[gid] || !Array.isArray(raw[gid].users)) return;
    raw[gid].users = raw[gid].users.filter(id => id !== uid);
    saveRaw(raw);
}

function setEnabled(gid, enabled) {
    const raw = loadRaw();
    if (raw && Array.isArray(raw.users)) {
        raw.__global = { users: raw.users.slice(), enabled: true };
        delete raw.users;
    }
    if (!raw[gid]) raw[gid] = { users: [], enabled };
    else raw[gid].enabled = enabled;
    saveRaw(raw);
}

function resetGuild(gid) {
    const raw = loadRaw();
    if (raw && Array.isArray(raw.users)) {
        raw.__global = { users: raw.users.slice(), enabled: true };
        delete raw.users;
    }
    raw[gid] = { users: [], enabled: true };
    saveRaw(raw);
}

module.exports = {
    getGuildData,
    hasUser,
    addUser,
    removeUser,
    setEnabled,
    resetGuild,
};
