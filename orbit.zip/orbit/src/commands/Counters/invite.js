const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        name: 'invites',
        description: 'Check your or another user\'s invites (Prefix Only)',
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/invites.json');

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {} };

            const userInvites = data[guildId].users[target.id] || { invites: 0, fake: 0, left: 0 };
            return message.reply(`📨 **${target.username}** has **${userInvites.invites}** invites (${userInvites.fake} fake, ${userInvites.left} left).`);
        }
    },
    {
        name: 'inviter',
        description: 'Check who invited a user (Prefix Only)',
        async executeMessage(message, args) {
            const target = message.mentions.users.first();
            if (!target) return message.reply({ embeds: [embedHelper.info('Please mention a user. Usage: `!inviter @user`')] });

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/invites.json');

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].users[target.id] || !data[guildId].users[target.id].invitedBy) {
                return message.reply({ embeds: [embedHelper.default(`${target.username} was not invited by anyone (or data not available).`)] });
            }

            const inviterId = data[guildId].users[target.id].invitedBy;
            return message.reply({ embeds: [embedHelper.default(`${target.username} was invited by <@${inviterId}>.`)] });
        }
    },
    {
        name: 'invited',
        description: 'Check users invited by a user (Prefix Only)',
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/invites.json');

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = message.guild.id;
            if (!data[guildId]) return message.reply({ embeds: [embedHelper.default(`${target.username} has invited 0 users.`)] });

            const invited = Object.values(data[guildId].users || {}).filter(u => u.invitedBy === target.id);
            return message.reply(`👥 **${target.username}** has invited **${invited.length}** users.`);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('invite')
            .setDescription('Manage invite counting system')
            .addSubcommand(sub => sub.setName('check').setDescription('Check invites').addUserOption(opt => opt.setName('user').setDescription('The user')))
            .addSubcommand(sub => sub.setName('who').setDescription('Check inviter').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('list').setDescription('Check invited users').addUserOption(opt => opt.setName('user').setDescription('The user')))
            .addSubcommand(sub => sub.setName('rolereward').setDescription('Configure invite role rewards').addIntegerOption(opt => opt.setName('invites').setDescription('Invite count').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role to reward').setRequired(true)))
            .addSubcommand(sub => sub.setName('testlogs').setDescription('Test invite logs'))
            .addSubcommand(sub => sub.setName('config').setDescription('Show invite count configuration'))
            .addSubcommandGroup(group => group.setName('leavelogs').setDescription('Manage leave logs')
                .addSubcommand(sub => sub.setName('set').setDescription('Set leave logs channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('disable').setDescription('Disable leave logs')))
            .addSubcommand(sub => sub.setName('leaderboard').setDescription('Show overall invite leaderboard'))
            .addSubcommand(sub => sub.setName('fakethreshold').setDescription('Set fake invite threshold').addIntegerOption(opt => opt.setName('days').setDescription('Minimum account age in days').setRequired(true)))
            .addSubcommandGroup(group => group.setName('joinlogs').setDescription('Manage join logs')
                .addSubcommand(sub => sub.setName('set').setDescription('Set join logs channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('disable').setDescription('Disable join logs')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset invites for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('bonus').setDescription('Add bonus invites to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount').setRequired(true)))
            .addSubcommand(sub => sub.setName('rolereset').setDescription('Reset all invite role rewards'))
            .addSubcommand(sub => sub.setName('resetme').setDescription('Reset your own invites'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove invites from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount').setRequired(true))),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            const group = interaction.options.getSubcommandGroup();

            // Check/Who/List Logic
            if (!group && ['check', 'who', 'list'].includes(sub)) {
                const fs = require('fs');
                const path = require('path');
                const dataPath = path.join(__dirname, '../../data/invites.json');
                let data = {};
                try { if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8')); } catch (e) { }

                const guildId = interaction.guild.id;
                const target = interaction.options.getUser('user') || interaction.user;

                if (sub === 'check') {
                    if (!data[guildId]) data[guildId] = { users: {} };
                    const userInvites = data[guildId].users[target.id] || { invites: 0, fake: 0, left: 0 };
                    return interaction.reply({ embeds: [embedHelper.info(`📨 **${target.username}** has **${userInvites.invites}** invites (${userInvites.fake} fake, ${userInvites.left} left).`)] });
                }

                if (sub === 'who') {
                    if (!data[guildId] || !data[guildId].users[target.id] || !data[guildId].users[target.id].invitedBy) {
                        return interaction.reply({ embeds: [embedHelper.default(`${target.username} was not invited by anyone (or data not available).`)] });
                    }
                    const inviterId = data[guildId].users[target.id].invitedBy;
                    return interaction.reply({ embeds: [embedHelper.default(`${target.username} was invited by <@${inviterId}>.`)] });
                }

                if (sub === 'list') {
                    if (!data[guildId]) return interaction.reply({ embeds: [embedHelper.default(`${target.username} has invited 0 users.`)] });
                    const invited = Object.values(data[guildId].users || {}).filter(u => u.invitedBy === target.id);
                    return interaction.reply({ embeds: [embedHelper.default(`👥 **${target.username}** has invited **${invited.length}** users.`)] });
                }
            }

            if (!interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }

            const path = group ? `${group} ${sub}` : sub;
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Invite Counting').setDescription(`Executed invite command: **${path}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **invite config**\n› Show configuration.\n\n` +
                    `» **invite leaderboard**\n› Show leaderboard.\n\n` +
                    `» **invite rolereward <invites> @role**\n› Set role reward.\n\n` +
                    `» **invite rolereset**\n› Reset all role rewards.\n\n` +
                    `» **invite joinlogs/leavelogs set/disable**\n› Manage logs.\n\n` +
                    `» **invite bonus/remove/reset @user <amount>**\n› Manage invites.\n\n` +
                    `» **invite fakethreshold <days>**\n› Set fake threshold.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['config', 'leaderboard', 'rolereward', 'rolereset', 'leavelogs', 'joinlogs', 'bonus', 'remove', 'reset', 'fakethreshold', 'testlogs', 'resetme'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            // Config commands require ManageGuild, user commands don't
            const configCommands = ['rolereward', 'rolereset', 'leavelogs', 'joinlogs', 'bonus', 'remove', 'reset', 'fakethreshold', 'testlogs'];
            if (configCommands.includes(subcommand) && !message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/invites.json');

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, fakeThreshold: 7, joinLogs: null, leaveLogs: null };

            if (subcommand === 'config') {
                const cfg = data[guildId];
                const configEmbed = new EmbedBuilder()
                    .setTitle('📊 Invite Configuration')
                    .addFields(
                        { name: 'Fake Threshold', value: `${cfg.fakeThreshold} days`, inline: true },
                        { name: 'Role Rewards', value: `${Object.keys(cfg.roleRewards || {}).length}`, inline: true },
                        { name: 'Join Logs', value: cfg.joinLogs ? `<#${cfg.joinLogs}>` : 'Not set', inline: true },
                        { name: 'Leave Logs', value: cfg.leaveLogs ? `<#${cfg.leaveLogs}>` : 'Not set', inline: true }
                    )
                    .setColor('#5865F2');
                return message.reply({ embeds: [configEmbed] });
            }

            if (subcommand === 'leaderboard') {
                const users = data[guildId].users || {};
                const sorted = Object.entries(users).sort((a, b) => (b[1].invites || 0) - (a[1].invites || 0)).slice(0, 10);
                const leaderboard = sorted.map((entry, i) => `${i + 1}. <@${entry[0]}> - ${entry[1].invites || 0} invites`).join('\n') || 'No data yet';
                const lbEmbed = new EmbedBuilder()
                    .setTitle('🏆 Invite Leaderboard')
                    .setDescription(leaderboard)
                    .setColor('#FFD700');
                return message.reply({ embeds: [lbEmbed] });
            }

            if (subcommand === 'resetme') {
                if (!data[guildId].users[message.author.id]) return message.reply({ embeds: [embedHelper.info('You have no invites to reset.')] });
                data[guildId].users[message.author.id] = { invites: 0, fake: 0, left: 0 };
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ Your invites have been reset.')] });
            }

            if (subcommand === 'rolereward') {
                const invites = parseInt(args[1]);
                const role = message.mentions.roles.first();
                if (!invites || !role) return message.reply({ embeds: [embedHelper.info('Usage: `!invite rolereward <invites> @role`')] });
                if (!data[guildId].roleRewards) data[guildId].roleRewards = {};
                data[guildId].roleRewards[invites] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${role} will be rewarded at ${invites} invites.`)] });
            }

            if (subcommand === 'rolereset') {
                data[guildId].roleRewards = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ All invite role rewards have been reset.')] });
            }

            if (subcommand === 'fakethreshold') {
                const days = parseInt(args[1]);
                if (!days || days < 0) return message.reply({ embeds: [embedHelper.info('Usage: `!invite fakethreshold <days>`')] });
                data[guildId].fakeThreshold = days;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Fake invite threshold set to ${days} days.`)] });
            }

            if (subcommand === 'joinlogs') {
                const action = args[1]?.toLowerCase();
                if (action === 'set') {
                    const channel = message.mentions.channels.first();
                    if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!invite joinlogs set #channel`')] });
                    data[guildId].joinLogs = channel.id;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embedHelper.success(`✅ Join logs set to ${channel}.`)] });
                } else if (action === 'disable') {
                    data[guildId].joinLogs = null;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embedHelper.success('✅ Join logs disabled.')] });
                }
                return message.reply({ embeds: [embedHelper.info('Usage: `!invite joinlogs set #channel` or `!invite joinlogs disable`')] });
            }

            if (subcommand === 'leavelogs') {
                const action = args[1]?.toLowerCase();
                if (action === 'set') {
                    const channel = message.mentions.channels.first();
                    if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!invite leavelogs set #channel`')] });
                    data[guildId].leaveLogs = channel.id;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embedHelper.success(`✅ Leave logs set to ${channel}.`)] });
                } else if (action === 'disable') {
                    data[guildId].leaveLogs = null;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embedHelper.success('✅ Leave logs disabled.')] });
                }
                return message.reply({ embeds: [embedHelper.info('Usage: `!invite leavelogs set #channel` or `!invite leavelogs disable`')] });
            }

            if (subcommand === 'bonus') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!invite bonus @user <amount>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { invites: 0, fake: 0, left: 0 };
                data[guildId].users[target.id].invites += amount;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${amount} bonus invites to ${target}.`)] });
            }

            if (subcommand === 'remove') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!invite remove @user <amount>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { invites: 0, fake: 0, left: 0 };
                data[guildId].users[target.id].invites = Math.max(0, data[guildId].users[target.id].invites - amount);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Removed ${amount} invites from ${target}.`)] });
            }

            if (subcommand === 'reset') {
                const target = message.mentions.users.first();
                if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!invite reset @user`')] });
                if (data[guildId].users[target.id]) {
                    data[guildId].users[target.id] = { invites: 0, fake: 0, left: 0 };
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                }
                return message.reply({ embeds: [embedHelper.success(`✅ Reset invites for ${target}.`)] });
            }

            if (subcommand === 'testlogs') {
                return message.reply({ embeds: [embedHelper.info('Test log functionality is best used via slash command: `/invite testlogs`')] });
            }

            return message.reply({ embeds: [embed] });
        }
    }
];
