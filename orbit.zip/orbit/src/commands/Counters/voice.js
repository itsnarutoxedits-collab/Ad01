const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('vctime')
            .setDescription('Check your or another user\'s voice time')
            .addUserOption(opt => opt.setName('user').setDescription('The user to check')),
        async execute(interaction) {
            const user = interaction.options.getUser('user') || interaction.user;
            await interaction.reply(`${user.username} has 0 minutes of voice time.`);
        },
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/voicetime.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {} };
            
            const userMinutes = data[guildId].users[target.id]?.minutes || 0;
            const hours = Math.floor(userMinutes / 60);
            const mins = userMinutes % 60;
            return message.reply(`🎤 **${target.username}** has **${hours}h ${mins}m** of voice time.`);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('voicetime')
            .setDescription('Manage voice time counting system')
            .addSubcommand(sub => sub.setName('add').setDescription('Add voice time to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('minutes').setDescription('Minutes to add').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset voice time for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('unblchannel').setDescription('Unblacklist a channel from counting voice time').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('leaderboard').setDescription('Show overall voice time leaderboard'))
            .addSubcommand(sub => sub.setName('rolereward').setDescription('Configure voice time role rewards').addIntegerOption(opt => opt.setName('minutes').setDescription('Minutes').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role to reward').setRequired(true)))
            .addSubcommand(sub => sub.setName('config').setDescription('Show voice time configuration'))
            .addSubcommand(sub => sub.setName('blchannel').setDescription('Blacklist a channel from counting voice time').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('resetme').setDescription('Reset your own voice time'))
            .addSubcommand(sub => sub.setName('rolereset').setDescription('Reset all voice time role rewards'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove voice time from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('minutes').setDescription('Minutes to remove').setRequired(true)))
            .addSubcommand(sub => sub.setName('lbdaily').setDescription('Show daily voice time leaderboard'))
            .addSubcommand(sub => sub.setName('lbweekly').setDescription('Show weekly voice time leaderboard')),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(sub) && !interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Voice Time Counting').setDescription(`Executed voicetime subcommand: **${sub}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **voicetime config**\n› Show configuration.\n\n` +
                    `» **voicetime leaderboard/lbdaily/lbweekly**\n› Show leaderboards.\n\n` +
                    `» **voicetime rolereward <minutes> @role**\n› Set role reward.\n\n` +
                    `» **voicetime rolereset**\n› Reset role rewards.\n\n` +
                    `» **voicetime blchannel/unblchannel #channel**\n› Manage blacklist.\n\n` +
                    `» **voicetime add/remove/reset @user <minutes>**\n› Manage time.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['config', 'leaderboard', 'rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset', 'resetme', 'lbweekly', 'lbdaily'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(subcommand) && !message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/voicetime.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, blacklist: [] };

            if (subcommand === 'config') {
                const cfg = data[guildId];
                const configEmbed = new EmbedBuilder()
                    .setTitle('📊 Voice Time Configuration')
                    .addFields(
                        { name: 'Role Rewards', value: `${Object.keys(cfg.roleRewards || {}).length}`, inline: true },
                        { name: 'Blacklisted Channels', value: `${(cfg.blacklist || []).length}`, inline: true }
                    )
                    .setColor('#5865F2');
                return message.reply({ embeds: [configEmbed] });
            }

            if (['leaderboard', 'lbdaily', 'lbweekly'].includes(subcommand)) {
                const users = data[guildId].users || {};
                const sorted = Object.entries(users).sort((a, b) => (b[1].minutes || 0) - (a[1].minutes || 0)).slice(0, 10);
                const leaderboard = sorted.map((entry, i) => `${i + 1}. <@${entry[0]}> - ${entry[1].minutes || 0} minutes`).join('\n') || 'No data yet';
                const lbEmbed = new EmbedBuilder()
                    .setTitle(`🏆 Voice Time Leaderboard ${subcommand === 'lbdaily' ? '(Daily)' : subcommand === 'lbweekly' ? '(Weekly)' : ''}`)
                    .setDescription(leaderboard)
                    .setColor('#FFD700');
                return message.reply({ embeds: [lbEmbed] });
            }

            if (subcommand === 'resetme') {
                if (!data[guildId].users[message.author.id]) return message.reply({ embeds: [embedHelper.info('You have no voice time to reset.')] });
                data[guildId].users[message.author.id].minutes = 0;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ Your voice time has been reset.')] });
            }

            if (subcommand === 'rolereward') {
                const minutes = parseInt(args[1]);
                const role = message.mentions.roles.first();
                if (!minutes || !role) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime rolereward <minutes> @role`')] });
                if (!data[guildId].roleRewards) data[guildId].roleRewards = {};
                data[guildId].roleRewards[minutes] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${role} will be rewarded at ${minutes} minutes.`)] });
            }

            if (subcommand === 'rolereset') {
                data[guildId].roleRewards = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ All voice time role rewards have been reset.')] });
            }

            if (subcommand === 'blchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime blchannel #channel`')] });
                if (!data[guildId].blacklist) data[guildId].blacklist = [];
                if (data[guildId].blacklist.includes(channel.id)) return message.reply(`${channel} is already blacklisted.`);
                data[guildId].blacklist.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} blacklisted from voice time counting.`)] });
            }

            if (subcommand === 'unblchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime unblchannel #channel`')] });
                if (!data[guildId].blacklist || !data[guildId].blacklist.includes(channel.id)) {
                    return message.reply(`${channel} is not blacklisted.`);
                }
                data[guildId].blacklist = data[guildId].blacklist.filter(c => c !== channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} removed from blacklist.`)] });
            }

            if (subcommand === 'add') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime add @user <minutes>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { minutes: 0 };
                data[guildId].users[target.id].minutes += amount;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${amount} minutes to ${target}.`)] });
            }

            if (subcommand === 'remove') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime remove @user <minutes>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { minutes: 0 };
                data[guildId].users[target.id].minutes = Math.max(0, data[guildId].users[target.id].minutes - amount);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Removed ${amount} minutes from ${target}.`)] });
            }

            if (subcommand === 'reset') {
                const target = message.mentions.users.first();
                if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!voicetime reset @user`')] });
                if (data[guildId].users[target.id]) {
                    data[guildId].users[target.id].minutes = 0;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                }
                return message.reply({ embeds: [embedHelper.success(`✅ Reset voice time for ${target}.`)] });
            }

            return message.reply({ embeds: [embed] });
        }
    }
];
