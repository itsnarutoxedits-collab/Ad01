const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoresponder')
        .setDescription('Configure auto-responders for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('response').setDescription('The response message').setRequired(true)))
        .addSubcommand(sub => sub.setName('edit').setDescription('Edit an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('response').setDescription('The new response').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('toggle').setDescription('Toggle an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all auto-responders'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable auto-responder module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable auto-responder module'))
        .addSubcommandGroup(group => group.setName('ignore').setDescription('Manage auto-responder ignore list')
            .addSubcommand(sub => sub.setName('add').setDescription('Add to ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove from ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset ignore list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show ignore list'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageGuild')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Auto Responder').setDescription(`Executed autoresponder command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **autoresponder add**\n› Add an auto-responder.\n\n` +
                `» **autoresponder edit**\n› Edit an auto-responder.\n\n` +
                `» **autoresponder remove**\n› Remove an auto-responder.\n\n` +
                `» **autoresponder toggle**\n› Toggle an auto-responder on/off.\n\n` +
                `» **autoresponder show**\n› Show all auto-responders.\n\n` +
                `» **autoresponder enable/disable**\n› Enable or disable the entire module.\n\n` +
                `» **autoresponder ignore**\n› Manage ignore list (add/remove/reset/show).`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'edit', 'remove', 'toggle', 'show', 'enable', 'disable', 'ignore'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/autoresponder.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, responders: [] };

        if (!message.member.permissions.has('ManageGuild')) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        if (!data[guildId].responders) data[guildId].responders = [];

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Autoresponder module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Autoresponder module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'show') {
            const cfg = data[guildId];
            const responders = cfg.responders || [];
            const respList = responders.map(r => `${r.trigger}: "${r.response.substring(0, 30)}..."`).join('\n') || 'None';
            const showEmbed = new EmbedBuilder()
                .setTitle('Autoresponder Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Total', value: responders.length.toString(), inline: true },
                    { name: 'Responders', value: respList }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [showEmbed] });
        }

        if (subcommand === 'add') {
            const trigger = args[1];
            const response = args.slice(2).join(' ');
            if (!trigger || !response) {
                return message.reply({ embeds: [embed.error('Usage: `!autoresponder add <trigger> <response>`')] });
            }
            data[guildId].responders.push({ trigger, response, enabled: true });
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Added autoresponder for: **${trigger}**`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'remove') {
            const trigger = args[1];
            if (!trigger) {
                return message.reply({ embeds: [embed.error('Usage: `!autoresponder remove <trigger>`')] });
            }
            data[guildId].responders = data[guildId].responders.filter(r => r.trigger !== trigger);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Removed autoresponder: **${trigger}**`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'edit') {
            const trigger = args[1];
            const response = args.slice(2).join(' ');
            if (!trigger || !response) {
                return message.reply({ embeds: [embed.error('Usage: `!autoresponder edit <trigger> <new response>`')] });
            }
            const responder = data[guildId].responders.find(r => r.trigger === trigger);
            if (!responder) {
                return message.reply({ embeds: [embed.error('No responder found with this trigger.')] });
            }
            responder.response = response;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Updated autoresponder for: **${trigger}**`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'toggle') {
            const trigger = args[1];
            if (!trigger) {
                return message.reply({ embeds: [embed.error('Usage: `!autoresponder toggle <trigger>`')] });
            }
            const responder = data[guildId].responders.find(r => r.trigger === trigger);
            if (!responder) {
                return message.reply({ embeds: [embed.error('No responder found with this trigger.')] });
            }
            responder.enabled = !responder.enabled;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Toggled **${trigger}**: ${responder.enabled ? 'ON' : 'OFF'}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'ignore') {
            const action = args[1];
            if (!action || !['add', 'remove', 'reset', 'show'].includes(action)) {
                return message.reply({ embeds: [embed.error('Usage: `!autoresponder ignore <add/remove/reset/show> [user/channel]`')] });
            }

            if (!data[guildId].ignore) data[guildId].ignore = { users: [], channels: [] };
            const ignore = data[guildId].ignore;

            if (action === 'show') {
                const users = ignore.users.map(id => `<@${id}>`).join(', ') || 'None';
                const channels = ignore.channels.map(id => `<#${id}>`).join(', ') || 'None';
                const ignoreEmbed = new EmbedBuilder()
                    .setTitle('Autoresponder Ignore List')
                    .addFields(
                        { name: 'Users', value: users },
                        { name: 'Channels', value: channels }
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [ignoreEmbed] });
            }

            if (action === 'reset') {
                data[guildId].ignore = { users: [], channels: [] };
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply('✅ Ignore list has been reset.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
                return;
            }

            if (action === 'add' || action === 'remove') {
                const target = args[2];
                if (!target) {
                    return message.reply({ embeds: [embed.error('Usage: `!autoresponder ignore add/remove <@user/#channel>`')] });
                }

                const userMatch = target.match(/^<@!?(\d+)>$/);
                const channelMatch = target.match(/^<#(\d+)>$/);

                if (userMatch) {
                    const userId = userMatch[1];
                    if (action === 'add') {
                        if (!ignore.users.includes(userId)) {
                            ignore.users.push(userId);
                            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                            const reply = await message.reply(`✅ Added <@${userId}> to ignore list.`);
                            setTimeout(() => reply.delete().catch(() => {}), 3000);
                        } else {
                            return message.reply({ embeds: [embed.error('User already in ignore list.')] });
                        }
                    } else {
                        ignore.users = ignore.users.filter(id => id !== userId);
                        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                        const reply = await message.reply(`✅ Removed <@${userId}> from ignore list.`);
                        setTimeout(() => reply.delete().catch(() => {}), 3000);
                    }
                } else if (channelMatch) {
                    const channelId = channelMatch[1];
                    if (action === 'add') {
                        if (!ignore.channels.includes(channelId)) {
                            ignore.channels.push(channelId);
                            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                            const reply = await message.reply(`✅ Added <#${channelId}> to ignore list.`);
                            setTimeout(() => reply.delete().catch(() => {}), 3000);
                        } else {
                            return message.reply({ embeds: [embed.error('Channel already in ignore list.')] });
                        }
                    } else {
                        ignore.channels = ignore.channels.filter(id => id !== channelId);
                        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                        const reply = await message.reply(`✅ Removed <#${channelId}> from ignore list.`);
                        setTimeout(() => reply.delete().catch(() => {}), 3000);
                    }
                } else {
                    return message.reply({ embeds: [embed.error('Invalid target. Use `@user` or `#channel`.')] });
                }
                return;
            }
        }

        return message.reply({ embeds: [embed.info(`All autoresponder commands are now available via prefix!`)] });
    }
};
