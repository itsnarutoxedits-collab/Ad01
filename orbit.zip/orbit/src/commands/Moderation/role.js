const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('role')
            .setDescription('Role management commands')
            .addSubcommand(sub => sub.setName('bots').setDescription('Manage roles for bots'))
            .addSubcommand(sub => sub.setName('temp').setDescription('Add a temporary role').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)).addStringOption(opt => opt.setName('time').setDescription('Time (e.g. 1h, 1d)').setRequired(true)))
            .addSubcommand(sub => sub.setName('all').setDescription('Manage roles for everyone'))
            .addSubcommand(sub => sub.setName('rename').setDescription('Rename a role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)).addStringOption(opt => opt.setName('name').setDescription('New name').setRequired(true)))
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
            .addSubcommand(sub => sub.setName('icon').setDescription('Change a role icon').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)).addStringOption(opt => opt.setName('icon').setDescription('Icon URL or emoji').setRequired(true)))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete a role').addRoleOption(opt => opt.setName('role').setDescription('The role to delete').setRequired(true)))
            .addSubcommand(sub => sub.setName('humans').setDescription('Manage roles for humans'))
            .addSubcommand(sub => sub.setName('colour').setDescription('Change a role colour').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)).addStringOption(opt => opt.setName('colour').setDescription('Hex code').setRequired(true)))
            .addSubcommand(sub => sub.setName('unverified').setDescription('Manage roles for unverified users'))
            .addSubcommand(sub => sub.setName('create').setDescription('Create a new role').addStringOption(opt => opt.setName('name').setDescription('Role name').setRequired(true))),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageRoles')) {
                return interaction.reply({ content: '❌ No access', ephemeral: true });
            }

            const sub = interaction.options.getSubcommand();

            try {
                if (sub === 'add') {
                    const user = interaction.options.getUser('user');
                    const role = interaction.options.getRole('role');
                    const member = await interaction.guild.members.fetch(user.id);
                    await member.roles.add(role);
                    return interaction.reply({ content: `✅ Added ${role} to ${user}`, ephemeral: true });
                }

                if (sub === 'remove') {
                    const user = interaction.options.getUser('user');
                    const role = interaction.options.getRole('role');
                    const member = await interaction.guild.members.fetch(user.id);
                    await member.roles.remove(role);
                    return interaction.reply({ content: `✅ Removed ${role} from ${user}`, ephemeral: true });
                }

                if (sub === 'create') {
                    const name = interaction.options.getString('name');
                    const role = await interaction.guild.roles.create({ name, reason: `Created by ${interaction.user.tag}` });
                    return interaction.reply({ content: `✅ Successfully created role ${role}`, ephemeral: true });
                }

                if (sub === 'delete') {
                    const role = interaction.options.getRole('role');
                    const roleName = role.name;
                    await role.delete(`Deleted by ${interaction.user.tag}`);
                    return interaction.reply({ content: `✅ Successfully deleted role **${roleName}**`, ephemeral: true });
                }

                if (sub === 'rename') {
                    const role = interaction.options.getRole('role');
                    const newName = interaction.options.getString('name');
                    await role.setName(newName, `Renamed by ${interaction.user.tag}`);
                    return interaction.reply({ content: `✅ Successfully renamed role to **${newName}**`, ephemeral: true });
                }

                if (sub === 'colour') {
                    const role = interaction.options.getRole('role');
                    const color = interaction.options.getString('colour');
                    await role.setColor(color, `Color changed by ${interaction.user.tag}`);
                    return interaction.reply({ content: `✅ Successfully changed color of ${role} to **${color}**`, ephemeral: true });
                }

                if (sub === 'icon') {
                    const role = interaction.options.getRole('role');
                    const icon = interaction.options.getString('icon');
                    await role.setIcon(icon, `Icon changed by ${interaction.user.tag}`);
                    return interaction.reply({ content: `✅ Successfully changed icon of ${role}`, ephemeral: true });
                }

                return interaction.reply({ embeds: [new EmbedBuilder().setTitle('Role Command').setDescription(`Subcommand **${sub}** is under development.`).setColor('#000000')], ephemeral: true });
            } catch (error) {
                console.error(error);
                return interaction.reply({ content: `❌ Failed to execute command: ${error.message}`, ephemeral: true });
            }
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **role add/remove**\n› Manage user roles.\n\n` +
                    `» **role create/delete/rename**\n› Manage roles.\n\n` +
                    `» **role icon/colour**\n› Customize roles.\n\n` +
                    `» **role temp**\n› Add temporary roles.\n\n` +
                    `» **role bots/humans/all**\n› Mass role management.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['add', 'remove', 'create', 'delete', 'rename', 'icon', 'colour', 'temp', 'bots', 'humans', 'all', 'unverified'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            if (!message.member.permissions.has('ManageRoles')) {
                return message.reply({ content: '❌ No access' });
            }

            if (!message.guild.members.me.permissions.has('ManageRoles')) {
                return message.reply({ content: '❌ I need Manage Roles permission to execute this command.' });
            }

            if (subcommand === 'create') {
                const roleName = args.slice(1).join(' ');
                if (!roleName) return message.reply('Please provide a role name. Example: `!role create Admin`');
                
                try {
                    const role = await message.guild.roles.create({
                        name: roleName,
                        reason: `Role created by ${message.author.tag}`
                    });
                    return message.reply(`✅ Successfully created role ${role}`);
                } catch (error) {
                    return message.reply(`❌ Failed to create role: ${error.message}`);
                }
            }

            if (subcommand === 'delete') {
                const role = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
                if (!role) return message.reply('Please mention a role or provide a role name. Example: `!role delete @Admin` or `!role delete Admin`');
                
                try {
                    const roleName = role.name;
                    await role.delete(`Deleted by ${message.author.tag}`);
                    return message.reply(`✅ Successfully deleted role **${roleName}**`);
                } catch (error) {
                    return message.reply(`❌ Failed to delete role: ${error.message}`);
                }
            }

            if (subcommand === 'add') {
                const user = message.mentions.users.first();
                const role = message.mentions.roles.first();
                
                if (!user) return message.reply('Please mention a user. Example: `!role add @User @Role`');
                if (!role) return message.reply('Please mention a role. Example: `!role add @User @Role`');
                
                try {
                    const member = await message.guild.members.fetch(user.id);
                    await member.roles.add(role);
                    return message.reply(`✅ Added ${role} to ${user}`);
                } catch (error) {
                    return message.reply(`❌ Failed to add role: ${error.message}`);
                }
            }

            if (subcommand === 'remove') {
                const user = message.mentions.users.first();
                const role = message.mentions.roles.first();
                
                if (!user) return message.reply('Please mention a user. Example: `!role remove @User @Role`');
                if (!role) return message.reply('Please mention a role. Example: `!role remove @User @Role`');
                
                try {
                    const member = await message.guild.members.fetch(user.id);
                    await member.roles.remove(role);
                    return message.reply(`✅ Removed ${role} from ${user}`);
                } catch (error) {
                    return message.reply(`❌ Failed to remove role: ${error.message}`);
                }
            }

            if (subcommand === 'rename') {
                const role = message.mentions.roles.first();
                if (!role) return message.reply('Please mention a role. Example: `!role rename @OldName NewName`');
                
                const newName = args.slice(2).join(' ');
                if (!newName) return message.reply('Please provide a new name. Example: `!role rename @Admin Moderator`');
                
                try {
                    await role.setName(newName, `Renamed by ${message.author.tag}`);
                    return message.reply(`✅ Successfully renamed role to **${newName}**`);
                } catch (error) {
                    return message.reply(`❌ Failed to rename role: ${error.message}`);
                }
            }

            if (subcommand === 'colour' || subcommand === 'color') {
                const role = message.mentions.roles.first();
                if (!role) return message.reply('Please mention a role. Example: `!role colour @Role #FF5555`');
                
                const color = args[2];
                if (!color) return message.reply('Please provide a color hex code. Example: `!role colour @Role #FF5555`');
                
                try {
                    await role.setColor(color, `Color changed by ${message.author.tag}`);
                    return message.reply(`✅ Successfully changed color of ${role} to **${color}**`);
                } catch (error) {
                    return message.reply(`❌ Failed to change color: ${error.message}`);
                }
            }

            return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/role ${subcommand}\``);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('rrole')
            .setDescription('Reaction Role management commands')
            .addSubcommand(sub => sub.setName('humans').setDescription('Reaction roles for humans'))
            .addSubcommand(sub => sub.setName('bots').setDescription('Reaction roles for bots'))
            .addSubcommand(sub => sub.setName('unverified').setDescription('Reaction roles for unverified users'))
            .addSubcommand(sub => sub.setName('all').setDescription('Reaction roles for everyone')),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Rrole Command').setDescription(`Executed rrole sub-command: **${sub}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            return message.reply(`The rrole command is best used via slash command: \`/rrole\``);
        }
    }
];
