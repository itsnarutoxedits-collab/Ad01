const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('mute')
            .setDescription('Timeouts a member (Mute)')
            .addUserOption(opt => opt.setName('target').setDescription('Member to mute').setRequired(true))
            .addIntegerOption(opt => opt.setName('duration').setDescription('Duration in minutes').setRequired(true))
            .addStringOption(opt => opt.setName('reason').setDescription('Reason for mute')),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ embeds: [embedHelper.error('❌ No access')] });
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ embeds: [embedHelper.error('❌ I lack permissions.')] });

            const target = interaction.options.getMember('target');
            const duration = interaction.options.getInteger('duration');
            const reason = interaction.options.getString('reason') || 'No reason provided';

            if (!target) return interaction.reply({ embeds: [embedHelper.error('❌ User not found.')] });
            if (!target.moderatable) return interaction.reply({ embeds: [embedHelper.error('❌ I cannot mute this user.')] });

            try {
                await target.timeout(duration * 60 * 1000, reason);
                await interaction.reply({ embeds: [embedHelper.success(`✅ Muted **${target.user.tag}** for ${duration} minutes. Reason: ${reason}`)] });
            } catch (e) {
                console.error(e);
                await interaction.reply({ embeds: [embedHelper.error('❌ Failed to mute.')] });
            }
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            const target = message.mentions.members.first();
            const duration = parseInt(args[1]);
            if (!target || isNaN(duration)) return message.reply('Usage: `!mute @user <minutes> [reason]`');
            if (!target.moderatable) return message.reply({ embeds: [embedHelper.error('❌ I cannot mute this user.')] });

            const reason = args.slice(2).join(' ') || 'No reason provided';
            try {
                await target.timeout(duration * 60 * 1000, reason);
                message.reply({ embeds: [embedHelper.success(`✅ Muted **${target.user.tag}** for ${duration} minutes. Reason: ${reason}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('❌ Failed to mute.')] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('unmute')
            .setDescription('Remove timeout from a member')
            .addUserOption(opt => opt.setName('target').setDescription('Member to unmute').setRequired(true)),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ embeds: [embedHelper.error('❌ No access')] });
            const target = interaction.options.getMember('target');
            if (!target) return interaction.reply({ embeds: [embedHelper.error('❌ User not found.')] });
            if (!target.moderatable) return interaction.reply({ embeds: [embedHelper.error('❌ I cannot moderate this user.')] });

            try {
                await target.timeout(null);
                await interaction.reply({ embeds: [embedHelper.success(`✅ Unmuted **${target.user.tag}**.`)] });
            } catch (e) {
                await interaction.reply({ embeds: [embedHelper.error('❌ Failed to unmute.')] });
            }
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            const target = message.mentions.members.first();
            if (!target) return message.reply('Usage: `!unmute @user`');
            try {
                await target.timeout(null);
                message.reply({ embeds: [embedHelper.success(`✅ Unmuted **${target.user.tag}**.`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('❌ Failed to unmute.')] });
            }
        }
    },
    {
        name: 'lock',
        description: 'Lock the current channel (Prefix Only)',
        async executeMessage(message) {
            // Placeholder proxy or direct implementation (copying basic.js logic simplified)
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: false });
                message.reply({ embeds: [embedHelper.success(`🔒 Locked ${message.channel}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to lock.')] });
            }
        }
    },
    {
        name: 'unlock',
        description: 'Unlock the current channel (Prefix Only)',
        async executeMessage(message) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: null });
                message.reply({ embeds: [embedHelper.success(`🔓 Unlocked ${message.channel}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to unlock.')] });
            }
        }
    },
    {
        name: 'hide',
        description: 'Hide current channel (Prefix Only)',
        async executeMessage(message) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: false });
                message.reply({ embeds: [embedHelper.success(`👁️ Hidden ${message.channel}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to hide.')] });
            }
        }
    },
    {
        name: 'unhide',
        description: 'Unhide current channel (Prefix Only)',
        async executeMessage(message) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: null });
                message.reply({ embeds: [embedHelper.success(`👁️ Unhidden ${message.channel}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to unhide.')] });
            }
        }
    },
    {
        name: 'slowmode',
        description: 'Set slowmode (Prefix Only)',
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            const seconds = parseInt(args[0]);
            if (isNaN(seconds)) return message.reply('Usage: `!slowmode <seconds>`');
            try {
                await message.channel.setRateLimitPerUser(seconds);
                message.reply({ embeds: [embedHelper.success(`⏱️ Set slowmode to ${seconds}s`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to set slowmode.')] });
            }
        }
    },
    {
        name: 'nuke',
        description: 'Clone and delete channel (Prefix Only)',
        async executeMessage(message) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            try {
                const pos = message.channel.position;
                const clone = await message.channel.clone();
                await message.channel.delete();
                await clone.setPosition(pos);
                await clone.send({ embeds: [embedHelper.success('💥 Channel nuked!')] });
            } catch (e) {
                // message.reply because channel might be deleted
            }
        }
    }
];
