const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('clear')
            .setDescription('Purge messages from the current channel')
            .addSubcommand(sub => sub.setName('all').setDescription('Clear all messages').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to clear').setRequired(true)))
            .addSubcommand(sub => sub.setName('image').setDescription('Clear messages containing images').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('emoji').setDescription('Clear messages containing emojis').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('embed').setDescription('Clear messages containing embeds').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('files').setDescription('Clear messages containing files').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('user').setDescription('Clear messages from a specific user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('contain').setDescription('Clear messages containing specific text').addStringOption(opt => opt.setName('text').setDescription('The text to search for').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('bots').setDescription('Clear messages from bots').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('mentions').setDescription('Clear messages containing mentions').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)))
            .addSubcommand(sub => sub.setName('reactions').setDescription('Clear messages containing reactions').addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true))),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageMessages')) {
                return interaction.reply({ content: '❌ No access', ephemeral: true });
            }

            const sub = interaction.options.getSubcommand();
            const amount = interaction.options.getInteger('amount');

            if (amount < 1 || amount > 100) {
                return interaction.reply({ content: 'Please provide a number between 1 and 100.', ephemeral: true });
            }

            try {
                await interaction.deferReply({ ephemeral: true });
                const messages = await interaction.channel.messages.fetch({ limit: amount });
                let filtered;

                switch(sub) {
                    case 'all':
                        filtered = messages;
                        break;
                    case 'bots':
                        filtered = messages.filter(m => m.author.bot);
                        break;
                    case 'user':
                        const target = interaction.options.getUser('target');
                        filtered = messages.filter(m => m.author.id === target.id);
                        break;
                    case 'image':
                        filtered = messages.filter(m => m.attachments.size > 0 || m.embeds.some(e => e.image || e.thumbnail));
                        break;
                    case 'embed':
                        filtered = messages.filter(m => m.embeds.length > 0);
                        break;
                    case 'emoji':
                        const emojiRegex = /<a?:\w+:\d+>|[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u;
                        filtered = messages.filter(m => emojiRegex.test(m.content));
                        break;
                    case 'files':
                        filtered = messages.filter(m => m.attachments.size > 0);
                        break;
                    case 'contain':
                        const searchText = interaction.options.getString('text');
                        filtered = messages.filter(m => m.content.toLowerCase().includes(searchText.toLowerCase()));
                        break;
                    case 'mentions':
                        filtered = messages.filter(m => m.mentions.users.size > 0 || m.mentions.roles.size > 0);
                        break;
                    case 'reactions':
                        filtered = messages.filter(m => m.reactions.cache.size > 0);
                        break;
                    default:
                        filtered = messages;
                }

                const deleted = await interaction.channel.bulkDelete(filtered, true);
                await interaction.editReply({ content: `✅ Successfully deleted ${deleted.size} messages.`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: `❌ Failed to delete messages: ${error.message}`, ephemeral: true });
            }
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **clear all**\n› Clear all messages.\n\n` +
                    `» **clear user/bots**\n› Clear messages from users/bots.\n\n` +
                    `» **clear image/file/emoji/embed**\n› Clear specific content.\n\n` +
                    `» **clear contain/mentions/reactions**\n› Clear matching messages.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['all', 'image', 'emoji', 'embed', 'files', 'user', 'contain', 'bots', 'mentions', 'reactions'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            if (!message.member.permissions.has('ManageMessages')) {
                return message.reply({ content: '❌ No access' });
            }

            if (!message.guild.members.me.permissions.has('ManageMessages')) {
                return message.reply({ content: '❌ I need Manage Messages permission to execute this command.' });
            }

            const amount = parseInt(args[1]) || 100;
            if (amount < 1 || amount > 100) {
                return message.reply('Please provide a number between 1 and 100.');
            }

            try {
                await message.delete().catch(() => {});
                
                if (subcommand === 'all') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    await message.channel.bulkDelete(messages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${messages.size} messages.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'bots') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const botMessages = messages.filter(m => m.author.bot);
                    await message.channel.bulkDelete(botMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${botMessages.size} bot messages.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'user') {
                    const user = message.mentions.users.first();
                    if (!user) return message.reply('Please mention a user. Example: `!clear user @User 50`');
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const userMessages = messages.filter(m => m.author.id === user.id);
                    await message.channel.bulkDelete(userMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${userMessages.size} messages from ${user.tag}.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'image') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const imageMessages = messages.filter(m => m.attachments.size > 0 || m.embeds.some(e => e.image || e.thumbnail));
                    await message.channel.bulkDelete(imageMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${imageMessages.size} messages with images.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'embed') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const embedMessages = messages.filter(m => m.embeds.length > 0);
                    await message.channel.bulkDelete(embedMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${embedMessages.size} messages with embeds.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'emoji') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const emojiRegex = /<a?:\w+:\d+>|[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u;
                    const emojiMessages = messages.filter(m => emojiRegex.test(m.content));
                    await message.channel.bulkDelete(emojiMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${emojiMessages.size} messages with emojis.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'contain') {
                    const searchText = args.slice(2).join(' ');
                    if (!searchText) return message.reply('Please provide text to search for. Example: `!clear contain hello 50`');
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const containMessages = messages.filter(m => m.content.toLowerCase().includes(searchText.toLowerCase()));
                    await message.channel.bulkDelete(containMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${containMessages.size} messages containing "${searchText}".`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'mentions') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const mentionMessages = messages.filter(m => m.mentions.users.size > 0 || m.mentions.roles.size > 0);
                    await message.channel.bulkDelete(mentionMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${mentionMessages.size} messages with mentions.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'files') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const fileMessages = messages.filter(m => m.attachments.size > 0);
                    await message.channel.bulkDelete(fileMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${fileMessages.size} messages with files.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

                if (subcommand === 'reactions') {
                    const messages = await message.channel.messages.fetch({ limit: amount });
                    const reactionMessages = messages.filter(m => m.reactions.cache.size > 0);
                    await message.channel.bulkDelete(reactionMessages, true);
                    const reply = await message.channel.send(`✅ Successfully deleted ${reactionMessages.size} messages with reactions.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                    return;
                }

            } catch (error) {
                return message.reply(`❌ Failed to delete messages: ${error.message}`);
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('purgeuser')
            .setDescription('Purge messages from a specific user')
            .addUserOption(opt => opt.setName('target').setDescription('The user to purge').setRequired(true))
            .addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageMessages')) {
                return interaction.reply({ content: '❌ No access', ephemeral: true });
            }

            const target = interaction.options.getUser('target');
            const amount = interaction.options.getInteger('amount');

            if (amount < 1 || amount > 100) {
                return interaction.reply({ content: 'Please provide a number between 1 and 100.', ephemeral: true });
            }

            try {
                await interaction.deferReply({ ephemeral: true });
                const messages = await interaction.channel.messages.fetch({ limit: amount });
                const userMessages = messages.filter(m => m.author.id === target.id);
                const deleted = await interaction.channel.bulkDelete(userMessages, true);
                await interaction.editReply({ content: `✅ Successfully deleted ${deleted.size} messages from **${target.tag}**`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: `❌ Failed to delete messages: ${error.message}`, ephemeral: true });
            }
        },
        async executeMessage(message, args) {
            return message.reply(`The purgeuser command is best used via slash command: \`/purgeuser\``);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('purgebots')
            .setDescription('Purge messages from all bots')
            .addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages to check').setRequired(true)),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageMessages')) {
                return interaction.reply({ content: '❌ No access', ephemeral: true });
            }

            const amount = interaction.options.getInteger('amount');

            if (amount < 1 || amount > 100) {
                return interaction.reply({ content: 'Please provide a number between 1 and 100.', ephemeral: true });
            }

            try {
                await interaction.deferReply({ ephemeral: true });
                const messages = await interaction.channel.messages.fetch({ limit: amount });
                const botMessages = messages.filter(m => m.author.bot);
                const deleted = await interaction.channel.bulkDelete(botMessages, true);
                await interaction.editReply({ content: `✅ Successfully deleted ${deleted.size} bot messages`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: `❌ Failed to delete messages: ${error.message}`, ephemeral: true });
            }
        },
        async executeMessage(message, args) {
            return message.reply(`The purgebots command is best used via slash command: \`/purgebots\``);
        }
    }
];
