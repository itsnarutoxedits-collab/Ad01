const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const embed = require('../../functions/embedHelper');

const createCommand = (name, description, executeLogic) => ({
    data: new SlashCommandBuilder()
        .setName(name)
        .setDescription(description),
    async execute(interaction) {
        await executeLogic(interaction);
    },
    async executeMessage(message, args) {
        // Individual implementations below
        if (name === 'lock') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: false });
                const reply = await message.reply({ embeds: [embed.success(`🔒 Locked ${message.channel}`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to lock the channel.')] });
            }
        } else if (name === 'unlock') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: null });
                const reply = await message.reply({ embeds: [embed.success(`🔓 Unlocked ${message.channel}`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to unlock the channel.')] });
            }
        } else if (name === 'hide') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: false });
                const reply = await message.reply({ embeds: [embed.success(`👁️ Hidden ${message.channel}`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to hide the channel.')] });
            }
        } else if (name === 'unhide') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                await message.channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: null });
                const reply = await message.reply({ embeds: [embed.success(`👁️ Unhidden ${message.channel}`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to unhide the channel.')] });
            }
        } else if (name === 'lockall') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const channels = message.guild.channels.cache.filter(ch => ch.type === 0 || ch.type === 2);
                let locked = 0;
                for (const [id, channel] of channels) {
                    try {
                        await channel.permissionOverwrites.edit(message.guild.id, { SendMessages: false });
                        locked++;
                    } catch { }
                }
                const reply = await message.reply({ embeds: [embed.success(`🔒 Locked ${locked} channels`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to lock all channels.')] });
            }
        } else if (name === 'unlockall') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const channels = message.guild.channels.cache.filter(ch => ch.type === 0 || ch.type === 2);
                let unlocked = 0;
                for (const [id, channel] of channels) {
                    try {
                        await channel.permissionOverwrites.edit(message.guild.id, { SendMessages: null });
                        unlocked++;
                    } catch { }
                }
                const reply = await message.reply({ embeds: [embed.success(`🔓 Unlocked ${unlocked} channels`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to unlock all channels.')] });
            }
        } else if (name === 'hideall') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const channels = message.guild.channels.cache.filter(ch => ch.type === 0 || ch.type === 2);
                let hidden = 0;
                for (const [id, channel] of channels) {
                    try {
                        await channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: false });
                        hidden++;
                    } catch { }
                }
                const reply = await message.reply({ embeds: [embed.success(`👁️ Hidden ${hidden} channels`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to hide all channels.')] });
            }
        } else if (name === 'unhideall') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const channels = message.guild.channels.cache.filter(ch => ch.type === 0 || ch.type === 2);
                let unhidden = 0;
                for (const [id, channel] of channels) {
                    try {
                        await channel.permissionOverwrites.edit(message.guild.id, { ViewChannel: null });
                        unhidden++;
                    } catch { }
                }
                const reply = await message.reply({ embeds: [embed.success(`👁️ Unhidden ${unhidden} channels`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to unhide all channels.')] });
            }
        } else if (name === 'slowmode') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            const seconds = parseInt(args[0]);
            if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
                return message.reply({ embeds: [embed.error('Please provide a valid number between 0 and 21600 seconds. Usage: `!slowmode <seconds>`')] });
            }
            try {
                await message.channel.setRateLimitPerUser(seconds);
                const reply = await message.reply({ embeds: [embed.success(`⏱️ Set slowmode to ${seconds} seconds`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to set slowmode.')] });
            }
        } else if (name === 'unslowmode') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                await message.channel.setRateLimitPerUser(0);
                const reply = await message.reply({ embeds: [embed.success('⏱️ Disabled slowmode')] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to disable slowmode.')] });
            }
        } else if (name === 'nuke') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const position = message.channel.position;
                const newChannel = await message.channel.clone();
                await message.channel.delete();
                await newChannel.setPosition(position);
                await newChannel.send({ embeds: [embed.success('💥 Channel nuked!')] });
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to nuke the channel.')] });
            }
        } else if (name === 'clone') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }
            try {
                const cloned = await message.channel.clone();
                const reply = await message.reply({ embeds: [embed.success(`📋 Cloned channel: ${cloned}`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                return message.reply({ embeds: [embed.error('Failed to clone the channel.')] });
            }
        } else if (name === 'unbanall') {
            if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!message.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
            }

            try {
                const bans = await message.guild.bans.fetch();
                let unbanned = 0;
                for (const [userId, banInfo] of bans) {
                    try {
                        await message.guild.bans.remove(userId, `Mass unban by ${message.author.tag}`);
                        unbanned++;
                    } catch (error) {
                        console.error(`Failed to unban ${userId}:`, error);
                    }
                }
                const reply = await message.reply({ embeds: [embed.success(`✅ Successfully unbanned ${unbanned} users.`)] });
                setTimeout(() => reply.delete().catch(() => { }), 5000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to unban all users.')] });
            }
        } else {
            return message.reply({ embeds: [embed.info(`The ${name} command is best used via slash command: \`/${name}\``)] });
        }
    }
});

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('ban')
            .setDescription('Ban a member from the server')
            .addUserOption(option => option.setName('target').setDescription('The member to ban').setRequired(true))
            .addStringOption(option => option.setName('reason').setDescription('The reason for banning')),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                return interaction.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return interaction.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
            }

            const target = interaction.options.getUser('target');
            const reason = interaction.options.getString('reason') || 'No reason provided';

            try {
                await interaction.guild.members.ban(target.id, { reason: `${reason} | Banned by ${interaction.user.tag}` });

                const banEmbed = new EmbedBuilder()
                    .setTitle('Ban')
                    .setDescription(`Successfully banned **${target.tag}** for: ${reason}`)
                    .setColor('#000000');

                await interaction.reply({ embeds: [banEmbed] });
            } catch (error) {
                console.error(error);
                await interaction.reply({ embeds: [embed.error('Failed to ban the user. They may have a higher role than me or be already banned.')] });
            }
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!message.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
            }

            if (!args[0]) {
                return message.reply({ embeds: [embed.error('Please mention a user to ban. Usage: `!ban @user [reason]`')] });
            }

            const userId = args[0].replace(/[<@!>]/g, '');
            const reason = args.slice(1).join(' ') || 'No reason provided';

            try {
                let user;
                if (/^\d+$/.test(userId)) {
                    // It's a user ID
                    user = await message.client.users.fetch(userId).catch(() => null);
                } else {
                    // Assume it's a username or tag
                    const member = message.guild.members.cache.find(m =>
                        m.user.username.toLowerCase() === userId.toLowerCase() ||
                        m.user.tag.toLowerCase() === userId.toLowerCase() ||
                        m.displayName.toLowerCase() === userId.toLowerCase()
                    );
                    user = member?.user;
                }

                if (!user) {
                    return message.reply({ embeds: [embed.error('Invalid user provided. Please use a mention, user ID, username, or tag.')] });
                }

                await message.guild.members.ban(user.id, { reason: `${reason} | Banned by ${message.author.tag}` });

                const banEmbed = new EmbedBuilder()
                    .setTitle('Ban')
                    .setDescription(`Successfully banned **${user.tag}** for: ${reason}`)
                    .setColor('#000000');

                const reply = await message.reply({ embeds: [banEmbed] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to ban the user. They may have a higher role than me or be already banned.')] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('unban')
            .setDescription('Unban a user from the server')
            .addStringOption(option => option.setName('userid').setDescription('The ID of the user to unban').setRequired(true)),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                return interaction.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return interaction.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
            }

            const userId = interaction.options.getString('userid');

            try {
                await interaction.guild.bans.fetch(userId);
                await interaction.guild.bans.remove(userId, `Unbanned by ${interaction.user.tag}`);

                const unbanEmbed = new EmbedBuilder()
                    .setTitle('Unban')
                    .setDescription(`Successfully unbanned user with ID: **${userId}**`)
                    .setColor('#000000');

                await interaction.reply({ embeds: [unbanEmbed] });
            } catch (error) {
                console.error(error);
                await interaction.reply({ embeds: [embed.error('Failed to unban the user. They may not be banned or the ID is invalid.')] });
            }
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!message.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return message.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
            }

            if (!args[0]) {
                return message.reply({ embeds: [embed.error('Please provide a user ID to unban. Usage: `!unban <userid>`')] });
            }

            const userId = args[0].replace(/[<@!>]/g, '');

            try {
                await message.guild.bans.fetch(userId);
                await message.guild.bans.remove(userId, `Unbanned by ${message.author.tag}`);

                const unbanEmbed = new EmbedBuilder()
                    .setTitle('Unban')
                    .setDescription(`Successfully unbanned user with ID: **${userId}**`)
                    .setColor('#000000');

                const reply = await message.reply({ embeds: [unbanEmbed] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to unban the user. They may not be banned or the ID is invalid.')] });
            }
        }
    },
    createCommand('unbanall', 'Unban all users from the server', async (interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ embeds: [embed.error('❌ No access')] });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ embeds: [embed.error('I need Ban Members permission to execute this command.')] });
        }

        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Unban All').setDescription('Starting to unban all users...').setColor('#000000')] });

        try {
            const bans = await interaction.guild.bans.fetch();
            let unbanned = 0;
            for (const [userId, banInfo] of bans) {
                try {
                    await interaction.guild.bans.remove(userId, `Mass unban by ${interaction.user.tag}`);
                    unbanned++;
                } catch (error) {
                    console.error(`Failed to unban ${userId}:`, error);
                }
            }
            await interaction.followUp({ embeds: [embed.success(`✅ Successfully unbanned ${unbanned} users.`)] });
        } catch (error) {
            console.error(error);
            await interaction.followUp({ embeds: [embed.error('Failed to unban all users.')] });
        }
    }),
    {
        data: new SlashCommandBuilder()
            .setName('kick')
            .setDescription('Kick a member from the server')
            .addUserOption(option => option.setName('target').setDescription('The member to kick').setRequired(true))
            .addStringOption(option => option.setName('reason').setDescription('The reason for kicking')),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
                return interaction.reply({ embeds: [embed.error('❌ No access')] });
            }

            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
                return interaction.reply({ embeds: [embed.error('I need Kick Members permission to execute this command.')] });
            }

            const target = interaction.options.getUser('target');
            const reason = interaction.options.getString('reason') || 'No reason provided';

            try {
                const member = await interaction.guild.members.fetch(target.id);
                await member.kick(reason);

                const kickEmbed = new EmbedBuilder()
                    .setTitle('Kick')
                    .setDescription(`Successfully kicked **${target.tag}** for: ${reason}`)
                    .setColor('#000000');

                await interaction.reply({ embeds: [kickEmbed] });
            } catch (error) {
                console.error(error);
                await interaction.reply({ embeds: [embed.error('Failed to kick the user. They may have a higher role than me or be already kicked.')] });
            }
        },
        async executeMessage(message, args) {
            return message.reply({ embeds: [embed.info(`The kick command is best used via slash command: \`/kick\``)] });
        }
    },
    createCommand('nick', 'Change a member\'s nickname', async (interaction) => { await interaction.reply('Changed nickname.'); }),
    createCommand('clone', 'Clone a channel', async (interaction) => { await interaction.reply('Cloning channel...'); }),
    createCommand('lockall', 'Lock all channels', async (interaction) => { await interaction.reply('Locked all channels.'); }),
    createCommand('unlockall', 'Unlock all channels', async (interaction) => { await interaction.reply('Unlocked all channels.'); }),
    createCommand('hideall', 'Hide all channels', async (interaction) => { await interaction.reply('Hid all channels.'); }),
    createCommand('unhideall', 'Unhide all channels', async (interaction) => { await interaction.reply('Unhid all channels.'); }),
    createCommand('unslowmode', 'Disable slowmode for a channel', async (interaction) => { await interaction.reply('Disabled slowmode.'); }),
    createCommand('enlarge', 'Enlarge an emoji', async (interaction) => { await interaction.reply('Enlarged emoji.'); }),
    createCommand('deleteemoji', 'Delete an emoji', async (interaction) => { await interaction.reply('Deleted emoji.'); }),
    createCommand('deletesticker', 'Delete a sticker', async (interaction) => { await interaction.reply('Deleted sticker.'); }),
    {
        data: new SlashCommandBuilder()
            .setName('channel')
            .setDescription('Channel management commands')
            .addSubcommand(sub => sub.setName('deleteafter').setDescription('Delete channel after specified time').addIntegerOption(opt => opt.setName('time').setDescription('Time in seconds').setRequired(true)))
            .addSubcommand(sub => sub.setName('transfer').setDescription('Transfer channel ownership'))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete current channel'))
            .addSubcommand(sub => sub.setName('create').setDescription('Create a new channel').addStringOption(opt => opt.setName('name').setDescription('Channel name').setRequired(true)))
            .addSubcommand(sub => sub.setName('rename').setDescription('Rename current channel').addStringOption(opt => opt.setName('name').setDescription('New name').setRequired(true))),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            await interaction.reply(`Channel ${sub} executed.`);
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';

            if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }

            const helpEmbed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **channel create <name>**\n› Create a new channel.\n\n` +
                    `» **channel delete**\n› Delete current channel.\n\n` +
                    `» **channel rename <name>**\n› Rename current channel.\n\n` +
                    `» **channel transfer**\n› Transfer ownership.\n\n` +
                    `» **channel deleteafter <seconds>**\n› Delete channel after time.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['create', 'delete', 'rename', 'transfer', 'deleteafter'].includes(subcommand)) {
                return message.reply({ embeds: [helpEmbed] });
            }

            try {
                if (subcommand === 'create') {
                    const channelName = args.slice(1).join(' ');
                    if (!channelName) {
                        return message.reply({ embeds: [embed.error('Please provide a channel name. Usage: `!channel create <name>`')] });
                    }
                    const newChannel = await message.guild.channels.create({
                        name: channelName,
                        type: 0
                    });
                    const reply = await message.reply({ embeds: [embed.success(`✅ Created channel: ${newChannel}`)] });
                    setTimeout(() => reply.delete().catch(() => { }), 3000);
                } else if (subcommand === 'delete') {
                    await message.reply({ embeds: [embed.warning('This channel will be deleted in 3 seconds...')] });
                    setTimeout(async () => {
                        await message.channel.delete();
                    }, 3000);
                } else if (subcommand === 'rename') {
                    const newName = args.slice(1).join(' ');
                    if (!newName) {
                        return message.reply({ embeds: [embed.error('Please provide a new name. Usage: `!channel rename <name>`')] });
                    }
                    await message.channel.setName(newName);
                    const reply = await message.reply({ embeds: [embed.success(`✅ Renamed channel to: ${newName}`)] });
                    setTimeout(() => reply.delete().catch(() => { }), 3000);
                } else if (subcommand === 'deleteafter') {
                    const seconds = parseInt(args[1]);
                    if (isNaN(seconds) || seconds < 1) {
                        return message.reply({ embeds: [embed.error('Please provide a valid number of seconds. Usage: `!channel deleteafter <seconds>`')] });
                    }
                    const reply = await message.reply({ embeds: [embed.warning(`⏱️ This channel will be deleted in ${seconds} seconds...`)] });
                    setTimeout(async () => {
                        await message.channel.delete();
                    }, seconds * 1000);
                } else if (subcommand === 'transfer') {
                    return message.reply({ embeds: [embed.info('Channel transfer is best configured via slash command: `/channel transfer`')] });
                }
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error(`Failed to execute channel ${subcommand}.`)] });
            }
        }
    },
    createCommand('snipe', 'Snipe a deleted message', async (interaction) => { await interaction.reply('Sniping...'); }),
];
