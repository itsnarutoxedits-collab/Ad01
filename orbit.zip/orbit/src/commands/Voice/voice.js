const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('vcmute')
            .setDescription('Mute a user in voice channel')
            .addUserOption(opt => opt.setName('target').setDescription('User to mute').setRequired(true)),
        async execute(interaction) {
            await handleVoiceAction(interaction, 'mute');
        },
        async executeMessage(message, args) {
            const target = message.mentions.members.first();
            if (!target) return message.reply('Usage: `!vcmute @user`');
            await handleVoiceAction(message, 'mute', target);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('vcunmute')
            .setDescription('Unmute a user in voice channel')
            .addUserOption(opt => opt.setName('target').setDescription('User to unmute').setRequired(true)),
        async execute(interaction) {
            await handleVoiceAction(interaction, 'unmute');
        },
        async executeMessage(message, args) {
            const target = message.mentions.members.first();
            if (!target) return message.reply('Usage: `!vcunmute @user`');
            await handleVoiceAction(message, 'unmute', target);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('vckick')
            .setDescription('Kick a user from voice channel')
            .addUserOption(opt => opt.setName('target').setDescription('User to disconnect').setRequired(true)),
        async execute(interaction) {
            await handleVoiceAction(interaction, 'kick');
        },
        async executeMessage(message, args) {
            const target = message.mentions.members.first();
            if (!target) return message.reply('Usage: `!vckick @user`');
            await handleVoiceAction(message, 'kick', target);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('vcmove')
            .setDescription('Move a user to another voice channel')
            .addUserOption(opt => opt.setName('target').setDescription('User to move').setRequired(true))
            .addChannelOption(opt => opt.setName('channel').setDescription('Target channel').setRequired(true)),
        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.MoveMembers)) return interaction.reply({ embeds: [embedHelper.error('❌ No access')] });
            const target = interaction.options.getMember('target');
            const channel = interaction.options.getChannel('channel');

            if (!target.voice.channel) return interaction.reply({ embeds: [embedHelper.error('User is not in VC.')] });

            try {
                await target.voice.setChannel(channel);
                interaction.reply({ embeds: [embedHelper.success(`Moved ${target} to ${channel}`)] });
            } catch (e) {
                interaction.reply({ embeds: [embedHelper.error('Failed to move user.')] });
            }
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.MoveMembers)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            const target = message.mentions.members.first();
            const channelId = args[1]?.replace(/[<#>]/g, '');
            const channel = message.guild.channels.cache.get(channelId);

            if (!target || !channel) return message.reply('Usage: `!vcmove @user #channel`');
            if (!target.voice.channel) return message.reply({ embeds: [embedHelper.error('User is not in VC.')] });

            try {
                await target.voice.setChannel(channel);
                message.reply({ embeds: [embedHelper.success(`Moved ${target} to ${channel}`)] });
            } catch (e) {
                message.reply({ embeds: [embedHelper.error('Failed to move user.')] });
            }
        }
    }
];

async function handleVoiceAction(context, action, manualTarget) {
    const member = context.member;
    if (!member.permissions.has(PermissionFlagsBits.MuteMembers)) { // simplified check
        const msg = { embeds: [embedHelper.error('❌ No access')] };
        return context.reply ? context.reply(msg) : null;
    }

    const target = manualTarget || context.options.getMember('target');
    if (!target.voice.channel) {
        const msg = { embeds: [embedHelper.error('User is not in a voice channel.')] };
        return context.reply ? context.reply(msg) : null;
    }

    try {
        if (action === 'mute') await target.voice.setMute(true);
        if (action === 'unmute') await target.voice.setMute(false);
        if (action === 'kick') await target.voice.disconnect();

        const actionStr = action === 'kick' ? 'disconnected' : (action + 'd');
        const msg = { embeds: [embedHelper.success(`✅ Successfully ${actionStr} **${target.user.tag}**.`)] };
        if (context.reply) await context.reply(msg);
    } catch (e) {
        console.error(e);
        const msg = { embeds: [embedHelper.error(`Failed to ${action} user.`)] };
        if (context.reply) await context.reply(msg);
    }
}
