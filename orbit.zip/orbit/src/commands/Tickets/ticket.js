const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    MessageFlags
} = require('discord.js');
const ticketManager = require('../../functions/ticketManager');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Advanced Multi-Panel Ticket System')
        .addSubcommand(sub => sub.setName('panel-create').setDescription('Start interactive wizard to create a ticket panel'))
        .addSubcommand(sub => sub.setName('panel-delete').setDescription('Delete a ticket panel').addStringOption(opt => opt.setName('id').setDescription('Panel ID').setRequired(true)))
        .addSubcommand(sub => sub.setName('panel-list').setDescription('List all ticket panels'))
        .addSubcommand(sub => sub.setName('close').setDescription('Close the current ticket').addStringOption(opt => opt.setName('reason').setDescription('Reason for closing')))
        .addSubcommand(sub => sub.setName('add').setDescription('Add user to ticket').addUserOption(opt => opt.setName('user').setDescription('User to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove user from ticket').addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('rename').setDescription('Rename ticket channel').addStringOption(opt => opt.setName('name').setDescription('New name').setRequired(true)))
        .addSubcommand(sub => sub.setName('transcript').setDescription('Generate transcript for this ticket')),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // --- PANEL MANAGEMENT ---

        if (sub === 'panel-list') {
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: '❌ Admin only.', flags: MessageFlags.Ephemeral });
            }
            const panels = ticketManager.getAllPanels(guildId);
            if (panels.length === 0) return interaction.reply({ content: 'No panels found.', flags: MessageFlags.Ephemeral });

            const embed = new EmbedBuilder()
                .setTitle('Ticket Panels')
                .setColor('#2b2d31');

            panels.forEach(p => {
                embed.addFields({
                    name: `ID: ${p.id} | ${p.name}`,
                    value: `Channel: <#${p.channelId}>\nCategory: <#${p.categoryId}>`
                });
            });
            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (sub === 'panel-delete') {
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: '❌ Admin only.', flags: MessageFlags.Ephemeral });
            }
            const id = interaction.options.getString('id');
            const success = ticketManager.deletePanel(guildId, id);
            return interaction.reply({ content: success ? `✅ Deleted panel ${id}` : '❌ Panel not found.', flags: MessageFlags.Ephemeral });
        }

        if (sub === 'panel-create') {
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: '❌ Admin only.', flags: MessageFlags.Ephemeral });
            }

            // --- Interactive Wizard Step 1: Modal for details ---
            const modal = new ModalBuilder()
                .setCustomId('ticket_panel_wizard')
                .setTitle('Create Ticket Panel');

            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_name').setLabel('Panel Name (e.g. Support)').setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_title').setLabel('Embed Title').setStyle(TextInputStyle.Short).setValue('Support Ticket').setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_desc').setLabel('Embed Description').setStyle(TextInputStyle.Paragraph).setValue('Click to open a ticket.').setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('p_btn').setLabel('Button Label').setStyle(TextInputStyle.Short).setValue('Open Ticket').setRequired(true))
            );

            await interaction.showModal(modal);
            return;
        }

        // --- TICKET OPERATIONS ---

        if (sub === 'rename') {
            const ticket = ticketManager.getTicket(guildId, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: '❌ Not a ticket channel.', flags: MessageFlags.Ephemeral });
            const name = interaction.options.getString('name');
            await interaction.channel.setName(name);
            return interaction.reply({ content: `✅ Renamed to ${name}` });
        }

        if (sub === 'add') {
            const ticket = ticketManager.getTicket(guildId, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: '❌ Not a ticket channel.', flags: MessageFlags.Ephemeral });
            const user = interaction.options.getUser('user');
            await interaction.channel.permissionOverwrites.edit(user, { ViewChannel: true, SendMessages: true });
            return interaction.reply({ content: `✅ Added ${user}` });
        }

        if (sub === 'remove') {
            const ticket = ticketManager.getTicket(guildId, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: '❌ Not a ticket channel.', flags: MessageFlags.Ephemeral });
            const user = interaction.options.getUser('user');
            await interaction.channel.permissionOverwrites.delete(user);
            return interaction.reply({ content: `✅ Removed ${user}` });
        }

        if (sub === 'close') {
            const ticket = ticketManager.getTicket(guildId, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: '❌ Not a ticket channel.', flags: MessageFlags.Ephemeral });

            const reason = interaction.options.getString('reason') || 'No reason provided';
            await interaction.reply(`🔒 Closing ticket... Reason: ${reason}`);

            // Generate transcript
            const buffer = await ticketManager.generateTranscript(interaction.channel, ticket, interaction.user, reason);

            // Send to log channel if it exists
            const panel = ticketManager.getPanel(guildId, ticket.panelId);
            if (panel && panel.logChannelId) {
                const logCh = interaction.guild.channels.cache.get(panel.logChannelId);
                if (logCh && buffer) {
                    await logCh.send({
                        content: `Ticket **${interaction.channel.name}** closed by ${interaction.user.tag}`,
                        files: [{ attachment: buffer, name: `transcript-${interaction.channel.name}.txt` }]
                    });
                }
            }
            // DM user transcript
            try {
                if (buffer) await (await interaction.guild.members.fetch(ticket.userId)).send({ content: `Your ticket ${interaction.channel.name} was closed.`, files: [{ attachment: buffer, name: 'transcript.txt' }] });
            } catch (e) { }

            await ticketManager.closeTicket(interaction.guild, interaction.channel.id, interaction.user, reason);
            setTimeout(() => interaction.channel.delete().catch(() => { }), 5000);
        }

        if (sub === 'transcript') {
            const ticket = ticketManager.getTicket(guildId, interaction.channel.id);
            if (!ticket) return interaction.reply({ content: '❌ Not a ticket channel.', flags: MessageFlags.Ephemeral });

            await interaction.deferReply();
            const buffer = await ticketManager.generateTranscript(interaction.channel, ticket, interaction.user, 'Manual Request');
            if (buffer) {
                interaction.editReply({ files: [{ attachment: buffer, name: `transcript-${interaction.channel.name}.txt` }] });
            } else {
                interaction.editReply('Failed to generate transcript.');
            }
        }
    },

    // --- INTERACTION HANDLERS (Modals, Buttons, Selects) ---

    async handleModal(interaction) {
        if (interaction.customId === 'ticket_panel_wizard') {
            // Step 1 done, now ask for Channels (Text-based wizard style because Modals can't have Select Menus)

            const name = interaction.fields.getTextInputValue('p_name');
            const title = interaction.fields.getTextInputValue('p_title');
            const desc = interaction.fields.getTextInputValue('p_desc');
            const btn = interaction.fields.getTextInputValue('p_btn');

            interaction.client.ticketWizard = interaction.client.ticketWizard || {};
            interaction.client.ticketWizard[`${interaction.user.id}_${interaction.guild.id}`] = { name, title, desc, btn };

            const channelSelect = new StringSelectMenuBuilder()
                .setCustomId('ticket_wizard_channel')
                .setPlaceholder('Select Ticket Category')
                .addOptions(interaction.guild.channels.cache
                    .filter(c => c.type === ChannelType.GuildCategory)
                    .first(25) // Limitation
                    .map(c => new StringSelectMenuOptionBuilder().setLabel(c.name).setValue(c.id))
                );

            if (channelSelect.options.length === 0) return interaction.reply({ content: '❌ No categories found in server.', flags: MessageFlags.Ephemeral });

            await interaction.reply({
                content: 'Please select the **Category** where tickets will be created.',
                components: [new ActionRowBuilder().addComponents(channelSelect)],
                flags: MessageFlags.Ephemeral
            });
        }

        if (interaction.customId === 'ticket_close_modal_action') {
            const reason = interaction.fields.getTextInputValue('reason') || 'No reason provided';
            await interaction.reply(`🔒 Closing ticket... Reason: ${reason}`);

            const ticket = ticketManager.getTicket(interaction.guild.id, interaction.channel.id);
            if (ticket) {
                const buffer = await ticketManager.generateTranscript(interaction.channel, ticket, interaction.user, reason);
                const panel = ticketManager.getPanel(interaction.guild.id, ticket.panelId);
                if (panel && panel.logChannelId) {
                    const logCh = interaction.guild.channels.cache.get(panel.logChannelId);
                    if (logCh && buffer) await logCh.send({ content: `Ticket closed by ${interaction.user.tag}`, files: [{ attachment: buffer, name: 'log.txt' }] });
                }
                ticketManager.closeTicket(interaction.guild, interaction.channel.id, interaction.user, reason);
            }
            setTimeout(() => interaction.channel.delete().catch(() => { }), 5000);
        }
    },

    async handleComponent(interaction) {
        const guildId = interaction.guild.id;

        // --- WIZARD: Select Category ---
        if (interaction.customId === 'ticket_wizard_channel') {
            const cache = interaction.client.ticketWizard?.[`${interaction.user.id}_${interaction.guild.id}`];
            if (!cache) return interaction.update({ content: '❌ Session expired.', components: [] });

            cache.categoryId = interaction.values[0];

            // Next: Select Log Channel (Optional - manually skipped for now to keep simple, just default to none or current channel?)
            // Let's ask to confirm creation in current channel.

            const confirmBtn = new ButtonBuilder().setCustomId('ticket_wizard_finish').setLabel('Create Panel Here').setStyle(ButtonStyle.Success);

            await interaction.update({
                content: `Category selected! Now click below to create the panel **in this channel**.\n(Log channel will be disabled by default. Config more via commands later).`,
                components: [new ActionRowBuilder().addComponents(confirmBtn)]
            });
        }

        // --- WIZARD: Finish ---
        if (interaction.customId === 'ticket_wizard_finish') {
            const cache = interaction.client.ticketWizard?.[`${interaction.user.id}_${interaction.guild.id}`];
            if (!cache) return interaction.update({ content: '❌ Session expired.', components: [] });

            // Create Panel Data
            const panel = ticketManager.createPanel(guildId, {
                name: cache.name,
                categoryId: cache.categoryId,
                channelId: interaction.channel.id,
                messageTitle: cache.title,
                messageDesc: cache.desc,
                buttonLabel: cache.btn
            });

            // Send Panel Message
            const embed = new EmbedBuilder().setTitle(panel.messageTitle).setDescription(panel.messageDesc).setColor('Green');
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`ticket_open_${panel.id}`).setLabel(panel.buttonLabel).setStyle(ButtonStyle.Primary).setEmoji(panel.buttonEmoji)
            );

            await interaction.channel.send({ embeds: [embed], components: [row] });
            await interaction.update({ content: '✅ Panel created successfully!', components: [] });

            delete interaction.client.ticketWizard[`${interaction.user.id}_${interaction.guild.id}`];
        }

        // --- TICKET: Open ---
        if (interaction.customId.startsWith('ticket_open_')) {
            const panelId = interaction.customId.split('_')[2];
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const res = await ticketManager.createTicket(interaction.guild, interaction.user, panelId);

            if (!res.success) {
                return interaction.editReply(res.message);
            }

            // Send greeting in new ticket
            const embed = new EmbedBuilder()
                .setTitle(`Ticket: ${res.panel.name}`)
                .setDescription(`Welcome ${interaction.user}! Support will be with you shortly.`)
                .setColor('Green');

            const items = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_action_close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                new ButtonBuilder().setCustomId('ticket_action_claim').setLabel('Claim').setStyle(ButtonStyle.Secondary).setEmoji('🙋‍♂️')
            );

            const ch = interaction.guild.channels.cache.get(res.channel.id);
            if (ch) await ch.send({ content: `${interaction.user} | <@&${res.panel.supportRoles[0] || ''}>`, embeds: [embed], components: [items] });

            interaction.editReply(`✅ Ticket created: ${ch}`);
        }

        // --- TICKET: Close Button ---
        if (interaction.customId === 'ticket_action_close') {
            // Trigger close modal
            const modal = new ModalBuilder().setCustomId('ticket_close_modal_action').setTitle('Close Ticket');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('Reason').setStyle(TextInputStyle.Short).setRequired(false)));
            await interaction.showModal(modal);
        }

        // --- TICKET: Claim Button ---
        if (interaction.customId === 'ticket_action_claim') {
            await interaction.reply({ content: `✅ Ticket claimed by ${interaction.user}`, flags: MessageFlags.Ephemeral });
            await interaction.channel.send(`🙋‍♂️ **${interaction.user.tag}** has claimed this ticket.`);
            // Logic to update topic or db could go here
        }
    },
};
