const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const embed = require('../../functions/embedHelper');

const mediaPath = path.join(__dirname, '../../data/media.json');

function getMediaData() {
    if (!fs.existsSync(mediaPath)) {
        fs.writeFileSync(mediaPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(mediaPath, 'utf8'));
}

function setMediaData(data) {
    fs.writeFileSync(mediaPath, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('media')
        .setDescription('Media channel management and bypass')
        .addSubcommand(sub => sub.setName('show').setDescription('Show current media channels'))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a media channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('add').setDescription('Add a media channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all media channels'))
        .addSubcommandGroup(group => group.setName('bypass').setDescription('Manage media bypass')
            .addSubcommand(sub => sub.setName('show').setDescription('Show bypass users/roles'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove bypass').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('add').setDescription('Add bypass').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset all bypass settings'))),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Media System').setDescription(`Executed media command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const secondArg = args[1] ? args[1].toLowerCase() : null;

        const mainHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **media add #channel**\n› Add a media-only channel.\n\n` +
                `» **media remove #channel**\n› Remove media-only channel.\n\n` +
                `» **media show**\n› Show media channels.\n\n` +
                `» **media reset**\n› Reset all media channels.\n\n` +
                `» **media bypass**\n› Manage bypass settings.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const bypassHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **media bypass add @user/@role**\n› Add bypass for user/role.\n\n` +
                `» **media bypass remove @user/@role**\n› Remove bypass.\n\n` +
                `» **media bypass show**\n› Show all bypasses.\n\n` +
                `» **media bypass reset**\n› Reset all bypasses.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'reset', 'bypass'].includes(subcommand)) {
            return message.reply({ embeds: [mainHelp] });
        }

        if (subcommand === 'bypass' && (!secondArg || !['add', 'remove', 'show', 'reset'].includes(secondArg))) {
            return message.reply({ embeds: [bypassHelp] });
        }

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        const guildId = message.guild.id;
        const data = getMediaData();
        if (!data[guildId]) {
            data[guildId] = { channels: [], bypassUsers: [], bypassRoles: [] };
        }

        // Add channel
        if (subcommand === 'add') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply('Please mention a channel. Usage: `!media add #channel`');
            }
            const channel = message.guild.channels.cache.get(channelId);
            if (!channel) {
                return message.reply('Invalid channel provided.');
            }
            if (data[guildId].channels.includes(channelId)) {
                return message.reply('This channel is already a media channel.');
            }
            data[guildId].channels.push(channelId);
            setMediaData(data);
            const reply = await message.reply(`✅ Added ${channel} as media-only channel`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Remove channel
        if (subcommand === 'remove') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply('Please mention a channel. Usage: `!media remove #channel`');
            }
            data[guildId].channels = data[guildId].channels.filter(id => id !== channelId);
            setMediaData(data);
            const reply = await message.reply(`✅ Removed channel from media-only list`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Show channels
        if (subcommand === 'show') {
            const channels = data[guildId].channels.length > 0 
                ? data[guildId].channels.map(id => `<#${id}>`).join(', ')
                : 'None';
            const embed = new EmbedBuilder()
                .setTitle('Media-Only Channels')
                .setDescription(channels)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }

        // Reset channels
        if (subcommand === 'reset') {
            data[guildId].channels = [];
            setMediaData(data);
            const reply = await message.reply(`✅ Reset all media channels`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Bypass commands
        if (subcommand === 'bypass') {
            const action = secondArg;

            if (action === 'add') {
                const userId = args[2] ? args[2].replace(/[<@!>]/g, '') : null;
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;

                if (!userId && !roleId) {
                    return message.reply('Please mention a user or role. Usage: `!media bypass add @user/@role`');
                }

                const user = await message.guild.members.fetch(userId).catch(() => null);
                const role = message.guild.roles.cache.get(roleId);

                if (user) {
                    if (!data[guildId].bypassUsers.includes(userId)) {
                        data[guildId].bypassUsers.push(userId);
                        setMediaData(data);
                        const reply = await message.reply(`✅ Added ${user} to media bypass`);
                        setTimeout(() => reply.delete().catch(() => {}), 3000);
                    } else {
                        return message.reply('User already has bypass.');
                    }
                } else if (role) {
                    if (!data[guildId].bypassRoles.includes(roleId)) {
                        data[guildId].bypassRoles.push(roleId);
                        setMediaData(data);
                        const reply = await message.reply(`✅ Added ${role} to media bypass`);
                        setTimeout(() => reply.delete().catch(() => {}), 3000);
                    } else {
                        return message.reply('Role already has bypass.');
                    }
                } else {
                    return message.reply('Invalid user or role.');
                }
                return;
            }

            if (action === 'remove') {
                const userId = args[2] ? args[2].replace(/[<@!>]/g, '') : null;
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;

                data[guildId].bypassUsers = data[guildId].bypassUsers.filter(id => id !== userId);
                data[guildId].bypassRoles = data[guildId].bypassRoles.filter(id => id !== roleId);
                setMediaData(data);
                const reply = await message.reply(`✅ Removed from media bypass`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
                return;
            }

            if (action === 'show') {
                const users = data[guildId].bypassUsers.length > 0
                    ? data[guildId].bypassUsers.map(id => `<@${id}>`).join(', ')
                    : 'None';
                const roles = data[guildId].bypassRoles.length > 0
                    ? data[guildId].bypassRoles.map(id => `<@&${id}>`).join(', ')
                    : 'None';
                const embed = new EmbedBuilder()
                    .setTitle('Media Bypass')
                    .addFields(
                        { name: 'Users', value: users },
                        { name: 'Roles', value: roles }
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            if (action === 'reset') {
                data[guildId].bypassUsers = [];
                data[guildId].bypassRoles = [];
                setMediaData(data);
                const reply = await message.reply(`✅ Reset all media bypasses`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
                return;
            }
        }
    }
};
