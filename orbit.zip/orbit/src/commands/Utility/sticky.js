const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const embed = require('../../functions/embedHelper');

const stickyPath = path.join(__dirname, '../../data/sticky.json');

function getStickyData() {
    if (!fs.existsSync(stickyPath)) {
        fs.writeFileSync(stickyPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(stickyPath, 'utf8'));
}

function setStickyData(data) {
    fs.writeFileSync(stickyPath, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sticky')
        .setDescription('Sticky message management')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a sticky message').addStringOption(opt => opt.setName('message').setDescription('The message').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel')))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset sticky messages in current or specified channel').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('bump').setDescription('Bump sticky message').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove sticky message').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('show').setDescription('Show sticky message details').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage sticky message channels')
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from sticky list').addChannelOption(opt => opt.setName('channel').setDescription('Channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to sticky list').addChannelOption(opt => opt.setName('channel').setDescription('Channel').setRequired(true)))),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Sticky Message').setDescription(`Executed sticky command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';

        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **sticky add <message> [#channel]**\n› Add a sticky message.\n\n` +
                `» **sticky remove [#channel]**\n› Remove sticky message.\n\n` +
                `» **sticky show [#channel]**\n› Show sticky message details.\n\n` +
                `» **sticky bump [#channel]**\n› Bump sticky message.\n\n` +
                `» **sticky reset [#channel]**\n› Reset sticky messages.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'bump', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed] });
        }

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        const guildId = message.guild.id;
        const data = getStickyData();
        if (!data[guildId]) data[guildId] = {};

        // Add command
        if (subcommand === 'add') {
            const channelMention = args.find(arg => arg.startsWith('<#'));
            let targetChannel = message.channel;
            let stickyMessage = '';

            if (channelMention) {
                const channelId = channelMention.replace(/[<#>]/g, '');
                targetChannel = message.guild.channels.cache.get(channelId);
                if (!targetChannel) {
                    return message.reply('Invalid channel provided.');
                }
                stickyMessage = args.filter(arg => !arg.startsWith('<#')).slice(1).join(' ');
            } else {
                stickyMessage = args.slice(1).join(' ');
            }

            if (!stickyMessage) {
                return message.reply('Please provide a message. Usage: `!sticky add <message> [#channel]`');
            }

            data[guildId][targetChannel.id] = {
                message: stickyMessage,
                lastMessageId: null
            };
            setStickyData(data);

            const reply = await message.reply(`✅ Sticky message set for ${targetChannel}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Remove command
        if (subcommand === 'remove') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : message.channel.id;
            const targetChannel = message.guild.channels.cache.get(channelId) || message.channel;

            if (!data[guildId][targetChannel.id]) {
                return message.reply(`No sticky message found in ${targetChannel}`);
            }

            // Delete last sticky message if exists
            if (data[guildId][targetChannel.id].lastMessageId) {
                try {
                    const msg = await targetChannel.messages.fetch(data[guildId][targetChannel.id].lastMessageId);
                    await msg.delete();
                } catch {}
            }

            delete data[guildId][targetChannel.id];
            setStickyData(data);

            const reply = await message.reply(`✅ Removed sticky message from ${targetChannel}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Show command
        if (subcommand === 'show') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : message.channel.id;
            const targetChannel = message.guild.channels.cache.get(channelId) || message.channel;

            if (!data[guildId][targetChannel.id]) {
                return message.reply(`No sticky message found in ${targetChannel}`);
            }

            const stickyData = data[guildId][targetChannel.id];
            const embed = new EmbedBuilder()
                .setTitle('Sticky Message Details')
                .setDescription(`**Channel:** ${targetChannel}\n**Message:** ${stickyData.message}`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }

        // Bump command
        if (subcommand === 'bump') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : message.channel.id;
            const targetChannel = message.guild.channels.cache.get(channelId) || message.channel;

            if (!data[guildId][targetChannel.id]) {
                return message.reply(`No sticky message found in ${targetChannel}`);
            }

            const stickyData = data[guildId][targetChannel.id];

            // Delete old sticky message
            if (stickyData.lastMessageId) {
                try {
                    const oldMsg = await targetChannel.messages.fetch(stickyData.lastMessageId);
                    await oldMsg.delete();
                } catch {}
            }

            // Send new sticky message
            const newMsg = await targetChannel.send(stickyData.message);
            data[guildId][targetChannel.id].lastMessageId = newMsg.id;
            setStickyData(data);

            const reply = await message.reply(`✅ Bumped sticky message in ${targetChannel}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Reset command
        if (subcommand === 'reset') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;

            if (channelId) {
                const targetChannel = message.guild.channels.cache.get(channelId);
                if (!targetChannel) {
                    return message.reply('Invalid channel provided.');
                }

                if (data[guildId][targetChannel.id]) {
                    if (data[guildId][targetChannel.id].lastMessageId) {
                        try {
                            const msg = await targetChannel.messages.fetch(data[guildId][targetChannel.id].lastMessageId);
                            await msg.delete();
                        } catch {}
                    }
                    delete data[guildId][targetChannel.id];
                }
            } else {
                // Reset all sticky messages in the guild
                for (const chId in data[guildId]) {
                    if (data[guildId][chId].lastMessageId) {
                        try {
                            const channel = message.guild.channels.cache.get(chId);
                            if (channel) {
                                const msg = await channel.messages.fetch(data[guildId][chId].lastMessageId);
                                await msg.delete();
                            }
                        } catch {}
                    }
                }
                data[guildId] = {};
            }

            setStickyData(data);
            const reply = await message.reply(`✅ Reset sticky messages`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }
    }
};
