const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const premiumManager = require('../../functions/premiumManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('redeem')
        .setDescription('Manage your premium subscription')
        .addSubcommand(sub => sub.setName('activate').setDescription('Activate Premium on this server'))
        .addSubcommand(sub => sub.setName('deactivate').setDescription('Deactivate Premium on this server'))
        .addSubcommand(sub => sub.setName('profile').setDescription('Check your premium profile')),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        const userId = interaction.user.id;
        const guildId = interaction.guild.id;

        if (sub === 'profile') {
            const user = premiumManager.getPremiumUser(userId);
            if (!user) {
                return interaction.reply({ content: '❌ You do not have a premium subscription.', flags: MessageFlags.Ephemeral });
            }
            const embed = new EmbedBuilder()
                .setTitle('Premium Profile')
                .setColor('#FFD700') // Gold
                .addFields(
                    { name: 'Expires In', value: `<t:${Math.floor(user.expires / 1000)}:R>`, inline: true },
                    { name: 'Keys Used', value: `${user.count}/${user.maxKeys}`, inline: true }
                )
                .setFooter({ text: 'Orbit Premium', iconURL: interaction.client.user.displayAvatarURL() });

            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (sub === 'activate') {
            const res = premiumManager.activateGuild(guildId, userId);
            if (res.success) {
                return interaction.reply({ content: '✅ **Premium Activated!** This server is now premium.', flags: MessageFlags.Ephemeral });
            } else {
                return interaction.reply({ content: `❌ Activation failed: ${res.message}`, flags: MessageFlags.Ephemeral });
            }
        }

        if (sub === 'deactivate') {
            const res = premiumManager.deactivateGuild(guildId, userId);
            if (res.success) {
                return interaction.reply({ content: '✅ **Premium Deactivated.** Key returned to your wallet.', flags: MessageFlags.Ephemeral });
            } else {
                return interaction.reply({ content: `❌ Deactivation failed: ${res.message}`, flags: MessageFlags.Ephemeral });
            }
        }
    },

    async executeMessage(message, args) {
        const sub = args[0];
        const userId = message.author.id;
        const guildId = message.guild.id;

        if (!sub || sub === 'profile') {
            const user = premiumManager.getPremiumUser(userId);
            if (!user) return message.reply('❌ You do not have a premium subscription.');

            const embed = new EmbedBuilder()
                .setTitle('Premium Profile')
                .setColor('#FFD700')
                .addFields(
                    { name: 'Expires In', value: `<t:${Math.floor(user.expires / 1000)}:R>`, inline: true },
                    { name: 'Keys Used', value: `${user.count}/${user.maxKeys}`, inline: true }
                );
            return message.reply({ embeds: [embed] });
        }

        if (sub === 'activate') {
            const res = premiumManager.activateGuild(guildId, userId);
            return message.reply(res.success ? '✅ **Premium Activated!**' : `❌ ${res.message}`);
        }

        if (sub === 'deactivate') {
            const res = premiumManager.deactivateGuild(guildId, userId);
            return message.reply(res.success ? '✅ **Premium Deactivated.**' : `❌ ${res.message}`);
        }
    }
};
