const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const controlCommands = [
    { name: 'play', desc: 'Play a song', stringOption: 'query' },
    { name: 'tts', desc: 'Play TTS message', stringOption: 'text' },
    { name: 'nowplaying', desc: 'Show current song' },
    { name: 'queue', desc: 'Show music queue' },
    { name: 'history', desc: 'Show history' },
    { name: 'search', desc: 'Search for songs', stringOption: 'query' },
    { name: 'grab', desc: 'Save current song to DMs' },
    { name: 'stop', desc: 'Stop music' },
    { name: 'autoplay', desc: 'Toggle autoplay' },
    { name: 'join', desc: 'Join voice' },
    { name: 'leave', desc: 'Leave voice' },
    { name: 'forcefix', desc: 'Force fix connection' },
    { name: 'pause', desc: 'Pause song' },
    { name: 'resume', desc: 'Resume song' },
    { name: 'replay', desc: 'Replay song' },
    { name: 'shuffle', desc: 'Shuffle queue' },
    { name: 'clearqueue', desc: 'Clear queue' },
    { name: 'volume', desc: 'Adjust volume', intOption: 'amount' }
];

const adjustCommands = [
    { name: 'skip', desc: 'Skip current song' },
    { name: 'skipinto', desc: 'Skip into position', intOption: 'position' },
    { name: 'seek', desc: 'Seek to time', stringOption: 'time' },
    { name: 'remove', desc: 'Remove from queue', intOption: 'index' },
    { name: 'move', desc: 'Move in queue', intOption: 'from', intOption2: 'to' },
    { name: 'loop', desc: 'Loop song' },
    { name: 'loopqueue', desc: 'Loop queue' }
];

const configGroups = [
    { name: 'filter', desc: 'Manage filters', subs: [{ name: 'toggle', opt: 'filter' }, { name: 'reset' }, { name: 'show' }] },
    { name: 'djrole', desc: 'Manage DJ roles', subs: [{ name: 'show' }, { name: 'clear' }, { name: 'set', role: true }] },
    { name: 'source', desc: 'Manage sources', subs: [{ name: 'show' }, { name: 'set', opt: 'source' }] },
    { name: '247', desc: 'Manage 24/7', subs: [{ name: 'enable' }, { name: 'disable' }, { name: 'channel', channel: true }] },
    { name: 'djmix', desc: 'Manage DJ mix', subs: [{ name: 'show' }, { name: 'enable' }, { name: 'disable' }] }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('music')
        .setDescription('Music system controls')
        .addSubcommandGroup(group => {
            group.setName('control').setDescription('General music controls');
            controlCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    return sub;
                });
            });
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('edit').setDescription('Adjust current queue/playback');
            adjustCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    if (cmd.intOption2) sub.addIntegerOption(o => o.setName(cmd.intOption2).setDescription('Target').setRequired(true));
                    return sub;
                });
            });
            return group;
        }),
    // The existing config groups would need to be moved to subcommand level OR we need more groups.
    // Since we can only have 25 total, and we have 2 groups + 5 more groups, that is 7 items.
    // But we cannot nest Groups.
    // Wait! configGroups were already being implemented as top-level commands.
    // If I want them in /music, I can either make them subcommands of a /music config group,
    // but they already have subcommands. You CANNOT have sub-sub-commands.
    // So /music filter toggle -> music (command) filter (group) toggle (subcommand).
    // This is the max depth (3 levels: cmd -> group -> sub).

    // So I can add the configGroups as groups to the SlachCommandBuilder.
    async execute(interaction) {
        // execute logic
    }
};

// I need to add the configGroups to the data builder.
configGroups.forEach(g => {
    module.exports.data.addSubcommandGroup(group => {
        group.setName(g.name).setDescription(g.desc);
        g.subs.forEach(s => {
            group.addSubcommand(sub => {
                sub.setName(s.name).setDescription(s.name);
                if (s.opt) sub.addStringOption(o => o.setName(s.opt).setDescription('Value').setRequired(true));
                if (s.role) sub.addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true));
                if (s.channel) sub.addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true));
                return sub;
            });
        });
        return group;
    });
});

module.exports.execute = async (interaction) => {
    const group = interaction.options.getSubcommandGroup();
    const sub = interaction.options.getSubcommand();
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Music System').setDescription(`Executed: **${group} ${sub}**`).setColor('#000000')] });
};

module.exports.executeMessage = async (message, args) => {
    const subcommand = args[0] ? args[0].toLowerCase() : 'help';
    const embed = new EmbedBuilder()
        .setDescription(
            `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
            `» **music control**\n› Play, pause, resume, etc.\n\n` +
            `» **music edit**\n› Skip, seek, remove, loop.\n\n` +
            `» **music filter**\n› Manage audio filters.\n\n` +
            `» **music djrole/source**\n› detailed config settings.`
        )
        .setColor('#2b2d31')
        .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

    if (subcommand === 'help' || !['control', 'edit', 'filter', 'djrole', 'source', '247', 'djmix'].includes(subcommand)) {
        return message.reply({ embeds: [embed] });
    }

    if (!message.member.voice.channel) {
        return message.reply('You must be in a voice channel to use music commands.');
    }

    return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/music ${subcommand}\``);
};
