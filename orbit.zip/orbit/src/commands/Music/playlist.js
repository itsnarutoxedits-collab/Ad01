const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('like')
            .setDescription('Like the current song and save it to your default playlist'),
        async execute(interaction) {
            await interaction.reply('Added current song to your liked songs!');
        },
        async executeMessage(message, args) {
            return message.reply(`The like command is best used via slash command: \`/like\``);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('playlist')
            .setDescription('Manage your music playlists')
            .addSubcommand(sub => sub.setName('play').setDescription('Play a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)))
            .addSubcommand(sub => sub.setName('rename').setDescription('Rename a playlist').addStringOption(opt => opt.setName('name').setDescription('Current name').setRequired(true)).addStringOption(opt => opt.setName('newname').setDescription('New name').setRequired(true)))
            .addSubcommand(sub => sub.setName('view').setDescription('View songs in a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)))
            .addSubcommand(sub => sub.setName('addcurrent').setDescription('Add the current song to a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)))
            .addSubcommand(sub => sub.setName('create').setDescription('Create a new playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)))
            .addSubcommand(sub => sub.setName('list').setDescription('List your playlists'))
            .addSubcommand(sub => sub.setName('import').setDescription('Import a playlist from a URL').addStringOption(opt => opt.setName('url').setDescription('Playlist URL').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a song from a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)).addIntegerOption(opt => opt.setName('index').setDescription('Song index').setRequired(true)))
            .addSubcommand(sub => sub.setName('add').setDescription('Add a song to a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true)).addStringOption(opt => opt.setName('song').setDescription('Song name or URL').setRequired(true)))
            .addSubcommand(sub => sub.setName('export').setDescription('Export a playlist').addStringOption(opt => opt.setName('name').setDescription('Playlist name').setRequired(true))),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Playlist System').setDescription(`Executed playlist subcommand: **${sub}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **playlist create/delete**\n› Manage playlists.\n\n` +
                    `» **playlist add/remove**\n› Manage songs.\n\n` +
                    `» **playlist list/view**\n› View playlists.\n\n` +
                    `» **playlist play**\n› Play a playlist.\n\n` +
                    `» **playlist import/export**\n› Transfer playlists.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['create', 'delete', 'play', 'view', 'add', 'remove', 'list', 'import', 'export', 'addcurrent', 'rename'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            if (['list', 'view'].includes(subcommand)) {
                return message.reply('Use `/playlist list` to view your playlists.');
            }

            return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/playlist ${subcommand}\``);
        }
    }
];
