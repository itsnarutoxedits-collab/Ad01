const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const premiumManager = require('../../functions/premiumManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('premium')
        .setDescription('Manage premium status (Developer Only)')
        .addSubcommand(sub => sub.setName('add').setDescription('Add premium to a user')
            .addStringOption(opt => opt.setName('id').setDescription('User ID').setRequired(true))
            .addIntegerOption(opt => opt.setName('days').setDescription('Duration in days').setRequired(true))
            .addIntegerOption(opt => opt.setName('count').setDescription('Max server count').setRequired(true))
        )
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove premium from a user').addStringOption(opt => opt.setName('id').setDescription('User ID').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List all premium users/servers'))
        .addSubcommand(sub => sub.setName('status').setDescription('Check premium status').addStringOption(opt => opt.setName('id').setDescription('ID').setRequired(true))),
    async execute(interaction) {
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        const id = interaction.options.getString('id');

        if (sub === 'add') {
            const days = interaction.options.getInteger('days');
            const count = interaction.options.getInteger('count');
            premiumManager.addPremiumUser(id, days, count);
            return interaction.reply({ content: `✅ Added Premium to <@${id}>\nDuration: ${days} days\nCount: ${count}`, flags: MessageFlags.Ephemeral });
        }

        if (sub === 'remove') {
            const success = premiumManager.removePremiumUser(id);
            if (success) return interaction.reply({ content: `✅ Removed premium from <@${id}>`, flags: MessageFlags.Ephemeral });
            return interaction.reply({ content: `❌ ID <@${id}> is not premium.`, flags: MessageFlags.Ephemeral });
        }

        if (sub === 'status') {
            const user = premiumManager.getPremiumUser(id);
            if (user) {
                return interaction.reply({
                    content: `**User**: <@${id}>\n**Expires**: <t:${Math.floor(user.expires / 1000)}:R>\n**Keys**: ${user.count}/${user.maxKeys}`,
                    flags: MessageFlags.Ephemeral
                });
            }
            const isGuild = premiumManager.isGuildPremium(id);
            if (isGuild) return interaction.reply({ content: `Guild ${id} is Premium ✅`, flags: MessageFlags.Ephemeral });
            return interaction.reply({ content: `ID ${id} has no premium status.`, flags: MessageFlags.Ephemeral });
        }

        if (sub === 'list') {
            const stats = premiumManager.getStats();
            return interaction.reply({ content: `**Stats**\nUsers: ${stats.users}\nGuilds: ${stats.guilds}`, flags: MessageFlags.Ephemeral });
        }
    },

    async executeMessage(message, args) {
        if (message.author.id !== message.guild.ownerId) return;

        const sub = args[0];
        if (!sub) return message.reply('Usage: !premium add/remove/list/status ...');

        if (sub === 'add') { // !premium add <id> <days> <count>
            const id = args[1];
            const days = parseInt(args[2]);
            const count = parseInt(args[3]);
            if (!id || !days || !count) return message.reply('Usage: !premium add <id> <days> <count>');

            premiumManager.addPremiumUser(id, days, count);
            return message.reply(`✅ Added Premium to <@${id}>\nDuration: ${days} days\nCount: ${count}`);
        }

        if (sub === 'remove') {
            const id = args[1];
            if (!id) return;
            const success = premiumManager.removePremiumUser(id);
            return message.reply(success ? `Removed premium from ${id}` : 'Not found');
        }

        if (sub === 'status') {
            const id = args[1];
            if (!id) return;
            const user = premiumManager.getPremiumUser(id);
            if (user) return message.reply(`User: <@${id}>\nExpires: <t:${Math.floor(user.expires / 1000)}:R>\nKeys: ${user.count}/${user.maxKeys}`);
            return message.reply('Not found or expired.');
        }

        if (sub === 'list') {
            const stats = premiumManager.getStats();
            return message.reply(`Users: ${stats.users}, Guilds: ${stats.guilds}`);
        }
    }
};
