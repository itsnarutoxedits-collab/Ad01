const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

// List commands - prefix only
module.exports = [
    {
        name: 'list',
        async executeMessage(message, args) {
            const subcommand = args[0]?.toLowerCase();
            const guild = message.guild;

            if (!subcommand) {
                const embed = new EmbedBuilder()
                    .setTitle('📋 List Commands')
                    .setDescription('Available list commands:\n\n`list users` - All members\n`list bots` - All bots\n`list roles` - All roles\n`list admins` - Administrators\n`list mods` - Moderators\n`list boosters` - Server boosters\n`list bans` - Banned users\n`list emojis` - Server emojis\n`list joinedat` - Members by join date\n`list createdat` - Members by account age\n`list early` - Early supporters\n`list activedeveloper` - Active developers\n`list inrole <role>` - Members in role\n`list servers` - Bot servers\n`list invoice` - Invoice count\n`list allusers` - Total users')
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Users (All Members)
            if (subcommand === 'users') {
                const members = guild.members.cache.filter(m => !m.user.bot);
                const memberList = members.map(m => `${m.user.username} (${m.user.id})`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('👥 All Users')
                    .setDescription(memberList.join('\n') || 'No users found')
                    .setFooter({ text: `Total: ${members.size} users | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Bots
            if (subcommand === 'bots') {
                const bots = guild.members.cache.filter(m => m.user.bot);
                const botList = bots.map(m => `${m.user.username} (${m.user.id})`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('🤖 All Bots')
                    .setDescription(botList.join('\n') || 'No bots found')
                    .setFooter({ text: `Total: ${bots.size} bots | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Roles
            if (subcommand === 'roles') {
                const roles = guild.roles.cache.filter(r => r.id !== guild.id).sort((a, b) => b.position - a.position);
                const roleList = roles.map(r => `${r.toString()} - ${r.members.size} members`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('📜 All Roles')
                    .setDescription(roleList.join('\n') || 'No roles found')
                    .setFooter({ text: `Total: ${roles.size} roles | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Admins
            if (subcommand === 'admins') {
                const admins = [];
                guild.members.cache.forEach(m => {
                    if (m.user.bot) return;
                    
                    // Check all roles for Administrator permission
                    const hasAdminPerm = m.roles.cache.some(r => r.permissions.has(PermissionFlagsBits.Administrator));
                    
                    if (hasAdminPerm || m.id === guild.ownerId) {
                        let roleName = 'Administrator';
                        
                        if (m.id === guild.ownerId) {
                            roleName = 'Server Owner';
                        } else {
                            const adminRole = m.roles.cache.find(r => r.permissions.has(PermissionFlagsBits.Administrator));
                            if (adminRole) {
                                roleName = adminRole.name;
                            }
                        }
                        
                        admins.push({ member: m, role: roleName });
                    }
                });
                
                const adminList = admins.map(a => `${a.member.user.username} - ${a.role}`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('👑 Administrators')
                    .setDescription(adminList.join('\n') || 'No admins found')
                    .setFooter({ text: `Total: ${admins.length} admins | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Mods
            if (subcommand === 'mods') {
                const mods = [];
                guild.members.cache.forEach(m => {
                    if (m.user.bot) return;
                    if (m.permissions.has(PermissionFlagsBits.Administrator)) return;
                    if (m.id === guild.ownerId) return;
                    
                    const hasModPerms = m.permissions.has(PermissionFlagsBits.ManageMessages) || 
                                       m.permissions.has(PermissionFlagsBits.KickMembers) ||
                                       m.permissions.has(PermissionFlagsBits.BanMembers);
                    
                    if (hasModPerms) {
                        const modRole = m.roles.cache.find(r => 
                            r.permissions.has(PermissionFlagsBits.ManageMessages) ||
                            r.permissions.has(PermissionFlagsBits.KickMembers) ||
                            r.permissions.has(PermissionFlagsBits.BanMembers)
                        );
                        mods.push({ member: m, role: modRole ? modRole.name : 'Unknown' });
                    }
                });
                const modList = mods.map(m => `${m.member.user.username} - ${m.role}`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('🛡️ Moderators')
                    .setDescription(modList.join('\n') || 'No moderators found')
                    .setFooter({ text: `Total: ${mods.length} mods | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Boosters
            if (subcommand === 'boosters') {
                const boosters = guild.members.cache.filter(m => m.premiumSince);
                const boosterList = boosters.map(m => `${m.user.username} (Boosting since <t:${Math.floor(m.premiumSinceTimestamp / 1000)}:R>)`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('💎 Server Boosters')
                    .setDescription(boosterList.join('\n') || 'No boosters found')
                    .setFooter({ text: `Total: ${boosters.size} boosters | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Bans
            if (subcommand === 'bans') {
                if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
                    return message.reply('❌ No access');
                }
                try {
                    const bans = await guild.bans.fetch();
                    const banList = bans.map(ban => `${ban.user.username} (${ban.user.id}) - ${ban.reason || 'No reason'}`).slice(0, 20);
                    const embed = new EmbedBuilder()
                        .setTitle('🔨 Banned Users')
                        .setDescription(banList.join('\n') || 'No bans found')
                        .setFooter({ text: `Total: ${bans.size} bans | Showing first 20` })
                        .setColor('#2b2d31');
                    return message.reply({ embeds: [embed] });
                } catch (error) {
                    return message.reply('Failed to fetch bans.');
                }
            }

            // List Emojis
            if (subcommand === 'emojis') {
                const emojis = guild.emojis.cache;
                const emojiList = emojis.map(e => `${e.toString()} - ${e.name}`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('😀 Server Emojis')
                    .setDescription(emojiList.join('\n') || 'No emojis found')
                    .setFooter({ text: `Total: ${emojis.size} emojis | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Joined At (sorted by join date)
            if (subcommand === 'joinedat') {
                const sorted = guild.members.cache.filter(m => !m.user.bot).sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
                const joinList = sorted.map(m => `${m.user.username} - <t:${Math.floor(m.joinedTimestamp / 1000)}:R>`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('📅 Members by Join Date')
                    .setDescription(joinList.join('\n') || 'No members found')
                    .setFooter({ text: `Total: ${sorted.size} members | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Created At (sorted by account age)
            if (subcommand === 'createdat') {
                const sorted = guild.members.cache.filter(m => !m.user.bot).sort((a, b) => a.user.createdTimestamp - b.user.createdTimestamp);
                const createList = sorted.map(m => `${m.user.username} - <t:${Math.floor(m.user.createdTimestamp / 1000)}:R>`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('🎂 Members by Account Age')
                    .setDescription(createList.join('\n') || 'No members found')
                    .setFooter({ text: `Total: ${sorted.size} members | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Early Supporters
            if (subcommand === 'early') {
                const early = guild.members.cache.filter(m => m.user.flags?.has('HypeSquadOnlineHouse1') || m.user.flags?.has('EarlySupporter'));
                const earlyList = early.map(m => `${m.user.username} (${m.user.id})`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('🌟 Early Supporters')
                    .setDescription(earlyList.join('\n') || 'No early supporters found')
                    .setFooter({ text: `Total: ${early.size} | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Active Developers
            if (subcommand === 'activedeveloper') {
                const devs = guild.members.cache.filter(m => m.user.flags?.has('ActiveDeveloper'));
                const devList = devs.map(m => `${m.user.username} (${m.user.id})`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('💻 Active Developers')
                    .setDescription(devList.join('\n') || 'No active developers found')
                    .setFooter({ text: `Total: ${devs.size} | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List In Role
            if (subcommand === 'inrole') {
                const roleId = args[1]?.replace(/[<@&>]/g, '');
                if (!roleId) {
                    return message.reply('Please mention a role: `!list inrole @role`');
                }
                const role = guild.roles.cache.get(roleId);
                if (!role) {
                    return message.reply('Role not found.');
                }
                const members = role.members.filter(m => !m.user.bot);
                const memberList = members.map(m => `${m.user.username} (${m.user.id})`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle(`Members in ${role.name}`)
                    .setDescription(memberList.join('\n') || 'No members in this role')
                    .setFooter({ text: `Total: ${members.size} members | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Servers (bot is in)
            if (subcommand === 'servers') {
                const guilds = message.client.guilds.cache;
                const guildList = guilds.map(g => `${g.name} (${g.memberCount} members)`).slice(0, 20);
                const embed = new EmbedBuilder()
                    .setTitle('🌐 Bot Servers')
                    .setDescription(guildList.join('\n') || 'No servers found')
                    .setFooter({ text: `Total: ${guilds.size} servers | Showing first 20` })
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List Invoice
            if (subcommand === 'invoice') {
                const invites = await guild.invites.fetch().catch(() => null);
                if (!invites) {
                    return message.reply('Could not fetch invites.');
                }
                const embed = new EmbedBuilder()
                    .setTitle('📧 Server Invites')
                    .setDescription(`Total Invites: **${invites.size}**`)
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            // List All Users (total across all servers)
            if (subcommand === 'allusers') {
                const totalUsers = message.client.users.cache.size;
                const embed = new EmbedBuilder()
                    .setTitle('👥 Total Users')
                    .setDescription(`The bot can see **${totalUsers}** users across **${message.client.guilds.cache.size}** servers`)
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            return message.reply('Unknown subcommand. Use `!list` to see all available options.');
        }
    }
];
