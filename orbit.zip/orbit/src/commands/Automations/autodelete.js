const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autodelete')
        .setDescription('Configure auto-deletion for messages')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to auto-delete').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)).addStringOption(opt => opt.setName('time').setDescription('Time before deletion (e.g. 10s, 1m)').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset auto-delete settings for a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from auto-delete').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show auto-delete configurations'))
        .addSubcommandGroup(group => group.setName('whitelist').setDescription('Manage auto-delete whitelist')
            .addSubcommand(sub => sub.setName('add').setDescription('Add to whitelist').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove from whitelist').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset whitelist'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show whitelist'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageMessages')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Auto Delete').setDescription(`Executed autodelete command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **autodelete add**\n› Add a channel to auto-delete.\n\n` +
                `» **autodelete remove**\n› Remove a channel from auto-delete.\n\n` +
                `» **autodelete reset**\n› Reset auto-delete settings for a channel.\n\n` +
                `» **autodelete show**\n› Show auto-delete configurations.\n\n` +
                `» **autodelete whitelist**\n› Manage auto-delete whitelist (add/remove/reset/show).`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'reset', 'show', 'whitelist'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        if (!message.member.permissions.has('ManageMessages')) {
            return message.reply('❌ No access');
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/autodelete.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { channels: {}, whitelist: [] };

        if (subcommand === 'show') {
            const cfg = data[guildId];
            const channels = Object.keys(cfg.channels || {});
            const channelList = channels.map(id => `<#${id}> (${cfg.channels[id]})`).join('\n') || 'None';
            const showEmbed = new EmbedBuilder()
                .setTitle('Autodelete Configuration')
                .addFields(
                    { name: 'Channels', value: channelList },
                    { name: 'Whitelisted', value: (cfg.whitelist || []).length.toString() }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [showEmbed] });
        }

        if (subcommand === 'add') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            const time = args[2];
            if (!channelId || !time) {
                return message.reply('Please provide a channel and time. Usage: `!autodelete add #channel <time>` (e.g., 10s, 1m)');
            }
            const channel = message.guild.channels.cache.get(channelId);
            if (!channel) {
                return message.reply('Invalid channel provided.');
            }
            if (!data[guildId].channels) data[guildId].channels = {};
            data[guildId].channels[channelId] = time;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Added ${channel} to autodelete with ${time} timer.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'remove') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply('Please mention a channel. Usage: `!autodelete remove #channel`');
            }
            if (!data[guildId].channels) data[guildId].channels = {};
            delete data[guildId].channels[channelId];
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Removed channel from autodelete.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'reset') {
            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply('Please mention a channel to reset. Usage: `!autodelete reset #channel`');
            }
            if (!data[guildId].channels) data[guildId].channels = {};
            delete data[guildId].channels[channelId];
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Autodelete settings for channel have been reset.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'whitelist') {
            const action = args[1] ? args[1].toLowerCase() : null;
            if (!data[guildId].whitelist) data[guildId].whitelist = [];

            if (action === 'add') {
                const targetId = args[2] ? args[2].replace(/[<@!&#>]/g, '') : null;
                if (!targetId) {
                    return message.reply('Please mention a user or role. Usage: `!autodelete whitelist add @user/@role`');
                }
                if (data[guildId].whitelist.includes(targetId)) {
                    return message.reply('This user/role is already whitelisted.');
                }
                data[guildId].whitelist.push(targetId);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply('✅ Added to autodelete whitelist.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'remove') {
                const targetId = args[2] ? args[2].replace(/[<@!&#>]/g, '') : null;
                if (!targetId) {
                    return message.reply('Please mention a user or role. Usage: `!autodelete whitelist remove @user/@role`');
                }
                data[guildId].whitelist = data[guildId].whitelist.filter(id => id !== targetId);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply('✅ Removed from autodelete whitelist.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'reset') {
                data[guildId].whitelist = [];
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply('✅ Reset autodelete whitelist.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'show') {
                const whitelistStr = data[guildId].whitelist.map(id => {
                    const user = message.guild.members.cache.get(id);
                    const role = message.guild.roles.cache.get(id);
                    return user ? `<@${id}>` : role ? `<@&${id}>` : id;
                }).join(', ') || 'None';
                return message.reply(`**Autodelete Whitelist**\n${whitelistStr}`);
            } else {
                return message.reply('Usage: `!autodelete whitelist <add/remove/reset/show>`');
            }
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/autodelete ${subcommand}\``);
    }
};
