const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mainrole')
        .setDescription('Security: Configure main roles for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all main roles'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all main roles')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);
        
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand(false);

        if (!subcommand) {
            const embed = new EmbedBuilder()
                .setTitle('Orbit™ mainrole [4]')
                .setDescription('`<..> <required> | [..] [optional]`\n\n' +
                    '⟫ `mainrole add <role>`\n' +
                    '⟩ Add a main role.\n\n' +
                    '⟫ `mainrole remove <role>`\n' +
                    '⟩ Remove a main role.\n\n' +
                    '⟫ `mainrole show`\n' +
                    '⟩ Show all main roles.\n\n' +
                    '⟫ `mainrole reset`\n' +
                    '⟩ Reset all main roles.')
                .setColor('#2b2d31')
                .setFooter({
                    text: `Page 1/1 | Requested by ${interaction.user.username}`,
                    iconURL: interaction.user.displayAvatarURL()
                });

            return await interaction.reply({ embeds: [embed] });
        }

        const embed = new EmbedBuilder()
            .setTitle(`Mainrole: ${subcommand}`)
            .setDescription(`You have triggered the **${subcommand}** module of Mainrole.`)
            .setColor('#2b2d31')
            .setFooter({ text: `Orbit™ Security System`, iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed] });
    },
    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
        
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embed.error('❌ No access - Only server owner or extra owners can use this command')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **mainrole add**\n› Add a main role.\n\n` +
                `» **mainrole remove**\n› Remove a main role.\n\n` +
                `» **mainrole show**\n› Show all main roles.\n\n` +
                `» **mainrole reset**\n› Reset all main roles.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const antinuke = require('../../functions/antinukeManager');
        const guildId = message.guild.id;
        const config = antinuke.getConfig(guildId);
        const mainRoles = config.mainRoles || [];

        if (subcommand === 'show') {
            if (!mainRoles.length) return message.reply({ embeds: [embed.info('No main roles configured.')] });
            return message.reply({ embeds: [embed.info(`Main roles: ${mainRoles.map(id => `<@&${id}>`).join(', ')}`)] });
        }

        if (subcommand === 'reset') {
            antinuke.setConfig(guildId, { mainRoles: [] });
            return message.reply({ embeds: [embed.success('All main roles have been reset.')] });
        }

        if (subcommand === 'add') {
            const role = message.mentions.roles.first();
            if (!role) return message.reply({ embeds: [embed.error('Please mention a role to add.')] });
            if (mainRoles.includes(role.id)) return message.reply({ embeds: [embed.info('This role is already a main role.')] });
            mainRoles.push(role.id);
            antinuke.setConfig(guildId, { mainRoles });
            return message.reply({ embeds: [embed.success(`Added ${role} as a main role.`)] });
        }

        if (subcommand === 'remove') {
            const role = message.mentions.roles.first();
            if (!role) return message.reply('Please mention a role to remove.');
            if (!mainRoles.includes(role.id)) return message.reply('This role is not a main role.');
            const updated = mainRoles.filter(id => id !== role.id);
            antinuke.setConfig(guildId, { mainRoles: updated });
            return message.reply(`Removed ${role} from main roles.`);
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/mainrole ${subcommand}\``);
    }
};
