const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('setup')
            .setDescription('Configure custom roles for the server')
            .addSubcommandGroup(group => group.setName('reqrole').setDescription('Manage required roles')
                .addSubcommand(sub => sub.setName('show').setDescription('Show required roles'))
                .addSubcommand(sub => sub.setName('remove').setDescription('Remove a required role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
                .addSubcommand(sub => sub.setName('set').setDescription('Set a required role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true))))
            .addSubcommand(sub => sub.setName('staff').setDescription('Configure staff role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('vip').setDescription('Configure VIP role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset custom role settings'))
            .addSubcommand(sub => sub.setName('guest').setDescription('Configure guest role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('create').setDescription('Create a custom role setup'))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete custom role setup'))
            .addSubcommand(sub => sub.setName('list').setDescription('List all custom role setups'))
            .addSubcommand(sub => sub.setName('friend').setDescription('Configure friend role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('girl').setDescription('Configure girl role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true))),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }

            const group = interaction.options.getSubcommandGroup();
            const sub = interaction.options.getSubcommand();
            const path = group ? `${group} ${sub}` : sub;
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Custom Role Setup').setDescription(`Executed setup command: **${path}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embed.error('❌ No access')] });
            }

            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **setup reqrole set/remove/show @role**\n› Manage required roles.\n\n` +
                    `» **setup staff/vip/guest/friend/girl @role**\n› Configure custom roles.\n\n` +
                    `» **setup list**\n› View all custom role setups.\n\n` +
                    `» **setup reset**\n› Reset all custom role settings.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['reqrole', 'staff', 'vip', 'guest', 'friend', 'girl', 'list', 'reset'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { reqRoles: [], staffRole: null, vipRole: null, guestRole: null, friendRole: null, girlRole: null };

            if (subcommand === 'list') {
                const cfg = data[guildId];
                const listEmbed = new EmbedBuilder()
                    .setTitle('🎭 Custom Role Setup')
                    .setDescription(
                        `**Required Roles:** ${(cfg.reqRoles || []).map(r => `<@&${r}>`).join(', ') || 'None'}\n` +
                        `**Staff Role:** ${cfg.staffRole ? `<@&${cfg.staffRole}>` : 'Not set'}\n` +
                        `**VIP Role:** ${cfg.vipRole ? `<@&${cfg.vipRole}>` : 'Not set'}\n` +
                        `**Guest Role:** ${cfg.guestRole ? `<@&${cfg.guestRole}>` : 'Not set'}\n` +
                        `**Friend Role:** ${cfg.friendRole ? `<@&${cfg.friendRole}>` : 'Not set'}\n` +
                        `**Girl Role:** ${cfg.girlRole ? `<@&${cfg.girlRole}>` : 'Not set'}`
                    )
                    .setColor('#5865F2');
                return message.reply({ embeds: [listEmbed] });
            }

            if (subcommand === 'reset') {
                data[guildId] = { reqRoles: [], staffRole: null, vipRole: null, guestRole: null, friendRole: null, girlRole: null };
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embed.success('Custom role setup has been reset.')] });
            }

            if (subcommand === 'reqrole') {
                const action = args[1] ? args[1].toLowerCase() : null;
                if (!action || !['set', 'remove', 'show'].includes(action)) {
                    return message.reply({ embeds: [embed.error('Usage: `!setup reqrole set/remove/show @role`')] });
                }

                if (action === 'show') {
                    const roles = (data[guildId].reqRoles || []).map(r => `<@&${r}>`).join(', ') || 'None';
                    return message.reply({ embeds: [embed.info(`**Required Roles:** ${roles}`)] });
                }

                const role = message.mentions.roles.first();
                if (!role) return message.reply({ embeds: [embed.error('Please mention a role.')] });

                if (action === 'set') {
                    if (!data[guildId].reqRoles) data[guildId].reqRoles = [];
                    if (data[guildId].reqRoles.includes(role.id)) {
                        return message.reply({ embeds: [embed.info(`${role} is already a required role.`)] });
                    }
                    data[guildId].reqRoles.push(role.id);
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embed.success(`${role} added as required role.`)] });
                }

                if (action === 'remove') {
                    if (!data[guildId].reqRoles || !data[guildId].reqRoles.includes(role.id)) {
                        return message.reply({ embeds: [embed.info(`${role} is not a required role.`)] });
                    }
                    data[guildId].reqRoles = data[guildId].reqRoles.filter(r => r !== role.id);
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embed.success(`${role} removed from required roles.`)] });
                }
            }

            if (['staff', 'vip', 'guest', 'friend', 'girl'].includes(subcommand)) {
                const role = message.mentions.roles.first();
                if (!role) return message.reply({ embeds: [embed.error(`Usage: \`!setup ${subcommand} @role\``)] });
                
                const roleKey = `${subcommand}Role`;
                data[guildId][roleKey] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embed.success(`${role} set as **${subcommand}** role.`)] });
            }

            return message.reply({ embeds: [embed] });
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('staff')
            .setDescription('Assign or remove staff role')
            .addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)),
        async execute(interaction) {
            const user = interaction.options.getUser('user');
            await interaction.reply({ content: `Processed **staff** role for ${user}.` });
        },
        async executeMessage(message, args) {
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].staffRole) {
                return message.reply({ embeds: [embed.error('Staff role not configured. Use `!setup staff @role` first.')] });
            }

            const target = message.mentions.members.first();
            if (!target) return message.reply({ embeds: [embed.error('Please mention a user. Usage: `!staff @user`')] });

            const staffRoleId = data[guildId].staffRole;
            const staffRole = message.guild.roles.cache.get(staffRoleId);
            if (!staffRole) return message.reply({ embeds: [embed.error('Configured staff role not found.')] });

            if (target.roles.cache.has(staffRoleId)) {
                await target.roles.remove(staffRole);
                return message.reply({ embeds: [embed.success(`Removed ${staffRole} from ${target}.`)] });
            } else {
                await target.roles.add(staffRole);
                return message.reply({ embeds: [embed.success(`Added ${staffRole} to ${target}.`)] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('girl')
            .setDescription('Assign or remove girl role')
            .addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)),
        async execute(interaction) {
            const user = interaction.options.getUser('user');
            await interaction.reply({ content: `Processed **girl** role for ${user}.` });
        },
        async executeMessage(message, args) {
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].girlRole) {
                return message.reply({ embeds: [embed.error('Girl role not configured. Use `!setup girl @role` first.')] });
            }

            const target = message.mentions.members.first();
            if (!target) return message.reply({ embeds: [embed.error('Please mention a user. Usage: `!girl @user`')] });

            const girlRoleId = data[guildId].girlRole;
            const girlRole = message.guild.roles.cache.get(girlRoleId);
            if (!girlRole) return message.reply({ embeds: [embed.error('Configured girl role not found.')] });

            if (target.roles.cache.has(girlRoleId)) {
                await target.roles.remove(girlRole);
                return message.reply({ embeds: [embed.success(`Removed ${girlRole} from ${target}.`)] });
            } else {
                await target.roles.add(girlRole);
                return message.reply({ embeds: [embed.success(`Added ${girlRole} to ${target}.`)] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('friend')
            .setDescription('Assign or remove friend role')
            .addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)),
        async execute(interaction) {
            const user = interaction.options.getUser('user');
            await interaction.reply({ content: `Processed **friend** role for ${user}.` });
        },
        async executeMessage(message, args) {
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].friendRole) {
                return message.reply({ embeds: [embed.error('Friend role not configured. Use `!setup friend @role` first.')] });
            }

            const target = message.mentions.members.first();
            if (!target) return message.reply({ embeds: [embed.error('Please mention a user. Usage: `!friend @user`')] });

            const friendRoleId = data[guildId].friendRole;
            const friendRole = message.guild.roles.cache.get(friendRoleId);
            if (!friendRole) return message.reply({ embeds: [embed.error('Configured friend role not found.')] });

            if (target.roles.cache.has(friendRoleId)) {
                await target.roles.remove(friendRole);
                return message.reply({ embeds: [embed.success(`Removed ${friendRole} from ${target}.`)] });
            } else {
                await target.roles.add(friendRole);
                return message.reply({ embeds: [embed.success(`Added ${friendRole} to ${target}.`)] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('vip')
            .setDescription('Assign or remove VIP role')
            .addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)),
        async execute(interaction) {
            const user = interaction.options.getUser('user');
            await interaction.reply({ content: `Processed **vip** role for ${user}.` });
        },
        async executeMessage(message, args) {
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].vipRole) {
                return message.reply({ embeds: [embed.error('VIP role not configured. Use `!setup vip @role` first.')] });
            }

            const target = message.mentions.members.first();
            if (!target) return message.reply({ embeds: [embed.error('Please mention a user. Usage: `!vip @user`')] });

            const vipRoleId = data[guildId].vipRole;
            const vipRole = message.guild.roles.cache.get(vipRoleId);
            if (!vipRole) return message.reply({ embeds: [embed.error('Configured VIP role not found.')] });

            if (target.roles.cache.has(vipRoleId)) {
                await target.roles.remove(vipRole);
                return message.reply({ embeds: [embed.success(`Removed ${vipRole} from ${target}.`)] });
            } else {
                await target.roles.add(vipRole);
                return message.reply({ embeds: [embed.success(`Added ${vipRole} to ${target}.`)] });
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('guest')
            .setDescription('Assign or remove guest role')
            .addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)),
        async execute(interaction) {
            const user = interaction.options.getUser('user');
            await interaction.reply({ content: `Processed **guest** role for ${user}.` });
        },
        async executeMessage(message, args) {
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/customrole.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId] || !data[guildId].guestRole) {
                return message.reply({ embeds: [embed.error('Guest role not configured. Use `!setup guest @role` first.')] });
            }

            const target = message.mentions.members.first();
            if (!target) return message.reply({ embeds: [embed.error('Please mention a user. Usage: `!guest @user`')] });

            const guestRoleId = data[guildId].guestRole;
            const guestRole = message.guild.roles.cache.get(guestRoleId);
            if (!guestRole) return message.reply({ embeds: [embed.error('Configured guest role not found.')] });

            if (target.roles.cache.has(guestRoleId)) {
                await target.roles.remove(guestRole);
                return message.reply({ embeds: [embed.success(`Removed ${guestRole} from ${target}.`)] });
            } else {
                await target.roles.add(guestRole);
                return message.reply({ embeds: [embed.success(`Added ${guestRole} to ${target}.`)] });
            }
        }
    }
];
