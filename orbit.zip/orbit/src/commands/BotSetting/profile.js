const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [{
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('Show your or another user\'s profile')
        .addUserOption(opt => opt.setName('user').setDescription('The user to check')),
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`${user.username}'s Profile`).setDescription('This is a placeholder for the user profile.').setColor('#000000')] });
    },
    async executeMessage(message, args) {
        const target = message.mentions.users.first() || message.author;
        
        const fs = require('fs');
        const path = require('path');
        const bioPath = path.join(__dirname, '../../data/bio.json');
        const badgePath = path.join(__dirname, '../../data/badges.json');
        
        let bioData = {};
        let badgeData = {};
        try {
            if (fs.existsSync(bioPath)) bioData = JSON.parse(fs.readFileSync(bioPath, 'utf8'));
            if (fs.existsSync(badgePath)) badgeData = JSON.parse(fs.readFileSync(badgePath, 'utf8'));
        } catch (e) { }
        
        const bio = bioData[target.id] || 'No bio set';
        const badges = badgeData[target.id] || [];
        const badgeStr = badges.length > 0 ? badges.join(', ') : 'No badges';
        
        const profileEmbed = new EmbedBuilder()
            .setTitle(`${target.username}'s Profile`)
            .setThumbnail(target.displayAvatarURL())
            .addFields(
                { name: 'Bio', value: bio },
                { name: 'Badges', value: badgeStr },
                { name: 'Joined Discord', value: `<t:${Math.floor(target.createdTimestamp / 1000)}:R>` }
            )
            .setColor('#5865F2');
        
        return message.reply({ embeds: [profileEmbed] });
    }
},
{
    data: new SlashCommandBuilder()
        .setName('bio')
        .setDescription('Manage your profile bio')
        .addSubcommand(sub => sub.setName('set').setDescription('Set your profile bio').addStringOption(opt => opt.setName('content').setDescription('The bio content').setRequired(true)))
        .addSubcommand(sub => sub.setName('clear').setDescription('Clear your profile bio')),
    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        await interaction.reply(`Successfully ${sub === 'set' ? 'updated' : 'cleared'} your bio!`);
    },
    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **bio set**\n› Set your profile bio.\n\n` +
                `» **bio clear**\n› Clear your profile bio.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['set', 'clear'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/bio.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }

        if (subcommand === 'set') {
            const bioContent = args.slice(1).join(' ');
            if (!bioContent) return message.reply({ embeds: [embedHelper.info('Usage: `!bio set <content>`')] });
            data[message.author.id] = bioContent;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Successfully updated your bio!');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'clear') {
            delete data[message.author.id];
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Successfully cleared your bio!');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/bio ${subcommand}\``);
    }
},
{
    data: new SlashCommandBuilder()
        .setName('badge')
        .setDescription('Manage user badges')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a badge to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addStringOption(opt => opt.setName('badge').setDescription('The badge name').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a badge from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addStringOption(opt => opt.setName('badge').setDescription('The badge name').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List all available badges')),
    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        const configCommands = ['add', 'remove'];
        if (configCommands.includes(sub) && !interaction.member.permissions.has('Administrator')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Badge Management').setDescription(`Executed badge subcommand: **${sub}**`).setColor('#000000')] });
    },
    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **badge add @user <badge>**\n› Add a badge to a user.\n\n` +
                `» **badge remove @user <badge>**\n› Remove a badge from a user.\n\n` +
                `» **badge list**\n› List all available badges.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'list'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/badges.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }

        if (subcommand === 'list') {
            const availableBadges = ['👑 VIP', '🛡️ Staff', '👨‍💻 Developer', '❤️ Supporter', '⭐ Premium', '🏆 Champion'];
            const badgeEmbed = new EmbedBuilder()
                .setTitle('🏷️ Available Badges')
                .setDescription(availableBadges.join('\n'))
                .setColor('#FFD700');
            return message.reply({ embeds: [badgeEmbed] });
        }

        const configCommands = ['add', 'remove'];
        if (configCommands.includes(subcommand) && !message.member.permissions.has('Administrator')) {
            return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        }

        if (subcommand === 'add') {
            const target = message.mentions.users.first();
            const badge = args.slice(2).join(' ');
            if (!target || !badge) return message.reply({ embeds: [embedHelper.info('Usage: `!badge add @user <badge>`')] });
            
            if (!data[target.id]) data[target.id] = [];
            if (data[target.id].includes(badge)) return message.reply({ embeds: [embedHelper.info('User already has this badge.')] });
            
            data[target.id].push(badge);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Added **${badge}** badge to ${target}.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'remove') {
            const target = message.mentions.users.first();
            const badge = args.slice(2).join(' ');
            if (!target || !badge) return message.reply({ embeds: [embedHelper.info('Usage: `!badge remove @user <badge>`')] });
            
            if (!data[target.id] || !data[target.id].includes(badge)) {
                return message.reply({ embeds: [embedHelper.info('User does not have this badge.')] });
            }
            
            data[target.id] = data[target.id].filter(b => b !== badge);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Removed **${badge}** badge from ${target}.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply({ embeds: [embed] });
    }
},
{
    data: new SlashCommandBuilder()
        .setName('branding')
        .setDescription('Show bot branding information'),
    async execute(interaction) {
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Bot Branding').setDescription('Orbot is the ultimate multipurpose Discord bot.').setColor('#000000')] });
    },
    async executeMessage(message, args) {
        const brandingEmbed = new EmbedBuilder()
            .setTitle('🌐 Orbit Bot Branding')
            .setDescription('**Orbit** is the ultimate multipurpose Discord bot designed to enhance your server experience.')
            .addFields(
                { name: '✨ Features', value: 'Moderation, Automod, Music, Fun, Counters, Custom Roles & More!' },
                { name: '👥 Community', value: 'Join thousands of servers using Orbit!' },
                { name: '🛡️ Security', value: 'Advanced anti-nuke and security features built-in.' }
            )
            .setColor('#5865F2')
            .setFooter({ text: 'Orbit™ - Your Server, Enhanced', iconURL: message.client.user.displayAvatarURL() });
        
        return message.reply({ embeds: [brandingEmbed] });
    }
}
];
