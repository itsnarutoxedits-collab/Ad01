const { Events } = require('discord.js');
const statsManager = require('../functions/statsManager');

module.exports = {
    name: Events.MessageCreate,
    async execute(message, client) {
        if (message.author.bot || !message.guild) return;
        statsManager.addMessage(message.guild.id, message.author.id);
    },
};
