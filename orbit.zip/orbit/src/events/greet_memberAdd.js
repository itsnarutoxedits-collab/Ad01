const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/greet.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (!guildConfig.channel || !guildConfig.message) return;

            const channel = member.guild.channels.cache.get(guildConfig.channel);
            if (!channel) {
                console.warn(`GREET: configured channel ${guildConfig.channel} not found in guild ${member.guild.id}`);
                return;
            }

            let welcomeMessage = guildConfig.message
                .replace(/{user}/g, member.user.toString())
                .replace(/{username}/g, member.user.username)
                .replace(/{server}/g, member.guild.name)
                .replace(/{membercount}/g, member.guild.memberCount.toString());

            const sentMessage = await channel.send(welcomeMessage);

            // Handle autodelete if configured
            if (guildConfig.autodelete) {
                const timeMatch = guildConfig.autodelete.match(/^(\d+)([smhd])$/);
                if (timeMatch) {
                    const value = parseInt(timeMatch[1]);
                    const unit = timeMatch[2];
                    let milliseconds = 0;

                    switch(unit) {
                        case 's': milliseconds = value * 1000; break;
                        case 'm': milliseconds = value * 60 * 1000; break;
                        case 'h': milliseconds = value * 60 * 60 * 1000; break;
                        case 'd': milliseconds = value * 24 * 60 * 60 * 1000; break;
                    }

                    if (milliseconds > 0 && milliseconds <= 86400000) { // Max 24 hours
                        setTimeout(() => sentMessage.delete().catch(() => {}), milliseconds);
                    }
                }
            }
        } catch (error) {
            console.error('Greet error (guildMemberAdd):', error);
        }
    }
};
