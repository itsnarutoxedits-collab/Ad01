const { Events } = require('discord.js');
const statsManager = require('../functions/statsManager');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState, client) {
        const guild = newState.guild || oldState.guild;
        if (!guild) return;
        const userId = newState.member ? newState.member.id : oldState.member.id;
        if (newState.member && newState.member.user.bot) return;

        // User Joined (or switched channels, effectively handled as join new if we ignore channelId)
        // Actually, if switching, we should calc duration for old, start new.
        // Simplified: 'channelId' change triggers this.

        if (!oldState.channelId && newState.channelId) {
            // Joined
            statsManager.voiceJoin(guild.id, userId);
        } else if (oldState.channelId && !newState.channelId) {
            // Left
            statsManager.voiceLeave(guild.id, userId);
        } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
            // Switched
            // Treat as leave + join to accumulate time for previous session? 
            // Or just do nothing since they are still in voice?
            // If we just track "total time in ANY voice", we don't need to stop.
            // But if statsManager relies on a single 'joinTime', we are fine as long as we don't reset it.
            // However, verify if 'voiceLeave' expects a specific channel? No, just guildId/userId.
            // So if they switch, we can just let the timer run.
        }
    },
};
