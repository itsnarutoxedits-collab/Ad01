const { EmbedBuilder, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.member || guildConfig.channels?.server;
            if (!logChannel) return;

            const channel = member.guild.channels.cache.get(logChannel);
            if (!channel) return;

            const accountAge = Date.now() - member.user.createdTimestamp;
            const days = Math.floor(accountAge / (1000 * 60 * 60 * 24));

            const embed = new EmbedBuilder()
                .setTitle('📥 Member Joined')
                .setColor('#00ff00')
                .setThumbnail(member.user.displayAvatarURL())
                .addFields(
                    { name: 'User', value: `${member.user.tag} (${member.user.id})`, inline: true },
                    { name: 'Account Age', value: `${days} days old`, inline: true },
                    { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true },
                    { name: 'Created At', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (guildMemberAdd):', error);
        }
    }
};
