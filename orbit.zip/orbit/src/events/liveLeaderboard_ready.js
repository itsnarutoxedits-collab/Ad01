const { Events } = require('discord.js');
const liveLeaderboardManager = require('../functions/liveLeaderboardManager');

module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        console.log('Starting Live Leaderboard Loop...');
        liveLeaderboardManager.startLoop(client);
    },
};
