const { Events, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const giveawayPath = path.join(__dirname, '../data/giveaways.json');

function getGiveawayData() {
    if (!fs.existsSync(giveawayPath)) {
        fs.writeFileSync(giveawayPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(giveawayPath, 'utf8'));
}

function setGiveawayData(data) {
    fs.writeFileSync(giveawayPath, JSON.stringify(data, null, 2));
}

async function checkGiveaways(client) {
    const data = getGiveawayData();
    
    for (const guildId in data) {
        for (const messageId in data[guildId]) {
            const giveaway = data[guildId][messageId];
            
            if (giveaway.ended) continue;
            if (!giveaway.endTime) continue;
            
            if (Date.now() >= giveaway.endTime) {
                // Time to end this giveaway
                try {
                    const guild = client.guilds.cache.get(guildId);
                    if (!guild) continue;
                    
                    const channel = guild.channels.cache.get(giveaway.channelId);
                    if (!channel) continue;
                    
                    const giveawayMsg = await channel.messages.fetch(messageId).catch(() => null);
                    if (!giveawayMsg) continue;
                    
                    const reaction = giveawayMsg.reactions.cache.get('🎉');
                    if (reaction) {
                        const users = await reaction.users.fetch();
                        const entries = users.filter(u => !u.bot);
                        
                        if (entries.size > 0) {
                            const winnersArray = [];
                            const winnerCount = Math.min(giveaway.winners, entries.size);
                            const entriesArray = Array.from(entries.values());
                            
                            for (let i = 0; i < winnerCount; i++) {
                                const randomIndex = Math.floor(Math.random() * entriesArray.length);
                                winnersArray.push(entriesArray[randomIndex]);
                                entriesArray.splice(randomIndex, 1);
                            }
                            
                            const embed = new EmbedBuilder()
                                .setTitle('Giveaway Ended 🎉')
                                .setDescription(
                                    `✅ **${giveaway.prize}**\n\n` +
                                    `• Winner(s): ${winnersArray.map(w => w.toString()).join(', ')}\n` +
                                    `• Hosted By: <@${giveaway.hostId}>`
                                )
                                .setColor('#ff0000');
                            
                            await giveawayMsg.edit({ embeds: [embed] });
                            await channel.send(`Congratulations ${winnersArray.map(w => w.toString()).join(', ')}! You won **${giveaway.prize}**! 🎉`);
                        } else {
                            const embed = new EmbedBuilder()
                                .setTitle('Giveaway Ended 🎉')
                                .setDescription(
                                    `✅ **${giveaway.prize}**\n\n` +
                                    `• Winner(s): No valid entries\n` +
                                    `• Hosted By: <@${giveaway.hostId}>`
                                )
                                .setColor('#ff0000');
                            
                            await giveawayMsg.edit({ embeds: [embed] });
                            await channel.send(`No one entered the giveaway for **${giveaway.prize}**!`);
                        }
                    }
                    
                    data[guildId][messageId].ended = true;
                    setGiveawayData(data);
                } catch (error) {
                    console.error('Error ending giveaway:', error);
                }
            }
        }
    }
}

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);
        
        // Fetch all members for cache
        try {
            for (const guild of client.guilds.cache.values()) {
                await guild.members.fetch();
            }
        } catch (error) {
            console.error('Error fetching members:', error);
        }
        
        // Check giveaways every 10 seconds
        setInterval(() => {
            checkGiveaways(client);
        }, 10000);
    },
};
