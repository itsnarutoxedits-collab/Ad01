const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberRemove,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/leavemsg.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (!guildConfig.message) return;

            // Use the same channel as greet if not set
            let channelId = guildConfig.channel;
            if (!channelId) {
                const greetPath = path.join(__dirname, '../data/greet.json');
                if (fs.existsSync(greetPath)) {
                    const greetData = JSON.parse(fs.readFileSync(greetPath, 'utf8'));
                    if (greetData[member.guild.id]) {
                        channelId = greetData[member.guild.id].channel;
                    }
                }
            }

            if (!channelId) return;

            const channel = member.guild.channels.cache.get(channelId);
            if (!channel) return;

            let leaveMessage = guildConfig.message
                .replace(/{user}/g, member.user.username)
                .replace(/{username}/g, member.user.username)
                .replace(/{server}/g, member.guild.name)
                .replace(/{membercount}/g, member.guild.memberCount.toString());

            await channel.send(leaveMessage);
        } catch (error) {
            console.error('Leave message error (guildMemberRemove):', error);
        }
    }
};
