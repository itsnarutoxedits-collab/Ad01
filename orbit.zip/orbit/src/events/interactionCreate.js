const { Events, MessageFlags } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);

            if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
            }

            const permit = require('../functions/permitManager');
            const gid = interaction.guild.id;
            const uid = interaction.user.id;
            const commandName = interaction.commandName;

            // 1. Bypass check
            if (!permit.isUserInList(gid, 'ignore_bypass', uid)) {
                // 2. User ignore
                if (permit.isUserInList(gid, 'ignore_user', uid)) return;
                // 3. Channel ignore
                if (permit.isUserInList(gid, 'ignore_channel', interaction.channel.id)) return;
                // 4. Role ignore
                const ignoredRoles = permit.getEntries(gid, 'ignore_role');
                if (ignoredRoles.some(roleId => interaction.member.roles.cache.has(roleId))) return;
                // 5. Command ignore
                if (permit.isUserInList(gid, 'ignore_command', commandName)) return;
            }

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error(error);
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ content: 'There was an error while executing this command!', flags: MessageFlags.Ephemeral });
                } else {
                    await interaction.reply({ content: 'There was an error while executing this command!', flags: MessageFlags.Ephemeral });
                }
            }
        } else if (interaction.isModalSubmit()) {
        } else if (interaction.isModalSubmit()) {
            // Route ticket modals
            if (interaction.customId && interaction.customId.startsWith('ticket_')) {
                const command = client.commands.get('ticket');
                if (command && command.handleModal) await command.handleModal(interaction);
                return;
            }
            // Route embed modals
            if (interaction.customId && interaction.customId.startsWith('embed_')) {
                const command = client.commands.get('embed');
                if (command && command.handleModal) await command.handleModal(interaction);
                return;
            }
        } else if (interaction.isStringSelectMenu() || interaction.isButton()) {
            // Special handling for ticket system
            if (interaction.customId === 'create_ticket') {
                const command = client.commands.get('ticket');
                console.log('Ticket button clicked, command found:', !!command);
                if (command && command.handleComponent) {
                    try {
                        await command.handleComponent(interaction);
                    } catch (error) {
                        console.error('Error in ticket handleComponent:', error);
                        if (!interaction.replied && !interaction.deferred) {
                            try {
                                await interaction.reply({ content: 'There was an error while creating the ticket! Please contact an administrator.', flags: MessageFlags.Ephemeral });
                            } catch (replyError) {
                                console.error('Failed to reply to interaction:', replyError);
                            }
                        }
                    }
                } else {
                    console.log('Ticket command or handleComponent not found');
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: 'Ticket system is not properly configured. Please contact an administrator.', flags: MessageFlags.Ephemeral });
                    }
                }
                return;
            }

            const [commandName] = interaction.customId.split('_');
            const command = client.commands.get(commandName);

            // If a command is found and has a handleComponent method, use it.
            // Otherwise, we do NOTHING and let local collectors (like in antinuke.js) handle it.
            if (command && command.handleComponent) {
                try {
                    await command.handleComponent(interaction);
                } catch (error) {
                    console.error('Error in handleComponent:', error);
                    if (!interaction.replied && !interaction.deferred) {
                        try {
                            await interaction.reply({ content: 'There was an error while handling this component!', ephemeral: true });
                        } catch (replyError) {
                            try {
                                await interaction.followUp({ content: 'There was an error while handling this component!', ephemeral: true });
                            } catch (followErr) {
                                console.error('Failed to reply/follow-up to interaction:', followErr);
                            }
                        }
                    }
                }
            }
        }
    },
};
