const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/joindm.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (!guildConfig.message) return;

            let dmMessage = guildConfig.message
                .replace(/{user}/g, member.user.username)
                .replace(/{username}/g, member.user.username)
                .replace(/{server}/g, member.guild.name)
                .replace(/{membercount}/g, member.guild.memberCount.toString());

            try {
                await member.send(dmMessage);
            } catch (error) {
                // User has DMs disabled or bot can't DM them
                console.log(`Could not DM ${member.user.tag} for join DM.`);
            }
        } catch (error) {
            console.error('Join DM error (guildMemberAdd):', error);
        }
    }
};
