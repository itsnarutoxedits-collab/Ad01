const { EmbedBuilder, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.MessageUpdate,
    async execute(oldMessage, newMessage) {
        if (!newMessage.guild || newMessage.author?.bot) return;
        if (oldMessage.content === newMessage.content) return;

        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[newMessage.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (guildConfig.ignores?.includes(newMessage.channel.id)) return;
            if (guildConfig.ignores?.includes(newMessage.author?.id)) return;

            const logChannel = guildConfig.channels?.message || guildConfig.channels?.moderation;
            if (!logChannel) return;

            const channel = newMessage.guild.channels.cache.get(logChannel);
            if (!channel) return;

            const embed = new EmbedBuilder()
                .setTitle('✏️ Message Edited')
                .setColor('#ffa500')
                .addFields(
                    { name: 'Author', value: `${newMessage.author.tag} (${newMessage.author.id})`, inline: true },
                    { name: 'Channel', value: `<#${newMessage.channel.id}> (${newMessage.channel.name})`, inline: true },
                    { name: 'Before', value: oldMessage.content ? (oldMessage.content.length > 1024 ? oldMessage.content.substring(0, 1021) + '...' : oldMessage.content) : '*No content*' },
                    { name: 'After', value: newMessage.content ? (newMessage.content.length > 1024 ? newMessage.content.substring(0, 1021) + '...' : newMessage.content) : '*No content*' },
                    { name: 'Jump to Message', value: `[Click here](${newMessage.url})` }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (messageUpdate):', error);
        }
    }
};
