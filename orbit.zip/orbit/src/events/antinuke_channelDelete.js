const { AuditLogEvent, EmbedBuilder } = require('discord.js');
const antinuke = require('../functions/antinukeManager');

module.exports = {
    name: 'channelDelete',
    async execute(channel, client) {
        try {
            if (!channel.guild) return;
            const guildId = channel.guild.id;
            const cfg = antinuke.getConfig(guildId);
            if (!cfg || !cfg.enabled) return;
            if (cfg.filters && cfg.filters.channelDelete === false) return;

            const logs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete }).catch(() => null);
            const entry = logs?.entries?.first();
            const executor = entry?.executor?.id;
            if (!executor) return;
            if (executor === client.user.id) return;
            if (executor === channel.guild.ownerId) return;
            if (cfg.whitelist && cfg.whitelist.includes(executor)) return;

            const heat = antinuke.addHeat(guildId, executor, cfg.heatPerAction || 10);

            if (cfg.loggingChannel) {
                const ch = channel.guild.channels.cache.get(cfg.loggingChannel);
                if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Antinuke: Channel Deleted').setDescription(`Channel **${channel.name}** deleted by <@${executor}> (${heat} heat)`).setColor('#ff5555')] }).catch(() => { });
            }

            if (cfg.panicMode && !cfg.zplus && heat >= (cfg.thresholdHeat || 100)) {
                antinuke.setConfig(guildId, { zplus: true });
                if (cfg.loggingChannel) {
                    const ch = channel.guild.channels.cache.get(cfg.loggingChannel);
                    if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Panic Mode Triggered').setDescription('Server heat exceeded threshold. Z+ Config loaded automatically.').setColor('#ff0000')] }).catch(() => { });
                }
            }

            if (heat >= (cfg.thresholdHeat || 100)) {
                const member = await channel.guild.members.fetch(executor).catch(() => null);
                if (member) {
                    if (member.bannable) {
                        await channel.guild.members.ban(executor, { reason: 'Antinuke: exceeded heat threshold' }).catch(() => { });
                    } else {
                        await member.kick('Antinuke: exceeded heat threshold').catch(() => { });
                    }
                }
                if (cfg.loggingChannel) {
                    const ch = channel.guild.channels.cache.get(cfg.loggingChannel);
                    if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Antinuke Action').setDescription(`<@${executor}> was punished for exceeding antinuke threshold`).setColor('#ff5555')] }).catch(() => { });
                }
            }
        } catch (e) {
            console.error('Antinuke channelDelete handler error:', e);
        }
    }
};
