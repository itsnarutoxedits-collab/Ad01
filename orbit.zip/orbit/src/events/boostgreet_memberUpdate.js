const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        try {
            // Check if the member just boosted the server
            const hadBoost = oldMember.premiumSince;
            const hasBoost = newMember.premiumSince;

            if (!hadBoost && hasBoost) {
                // Member just boosted
                const dataPath = path.join(__dirname, '../data/boostgreet.json');
                if (!fs.existsSync(dataPath)) return;

                const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
                const guildConfig = data[newMember.guild.id];

                if (!guildConfig || !guildConfig.enabled) return;
                if (!guildConfig.message) return;

                // Use greet channel if not set
                let channelId = guildConfig.channel;
                if (!channelId) {
                    const greetPath = path.join(__dirname, '../data/greet.json');
                    if (fs.existsSync(greetPath)) {
                        const greetData = JSON.parse(fs.readFileSync(greetPath, 'utf8'));
                        if (greetData[newMember.guild.id]) {
                            channelId = greetData[newMember.guild.id].channel;
                        }
                    }
                }

                if (!channelId) return;

                const channel = newMember.guild.channels.cache.get(channelId);
                if (!channel) return;

                let boostMessage = guildConfig.message
                    .replace(/{user}/g, newMember.user.toString())
                    .replace(/{username}/g, newMember.user.username)
                    .replace(/{server}/g, newMember.guild.name)
                    .replace(/{boosts}/g, newMember.guild.premiumSubscriptionCount.toString());

                await channel.send(boostMessage);
            }
        } catch (error) {
            console.error('Boost greet error (guildMemberUpdate):', error);
        }
    }
};
