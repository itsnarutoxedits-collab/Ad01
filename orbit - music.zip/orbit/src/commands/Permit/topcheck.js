const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const permit = require('../../functions/permitManager');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('topcheck')
        .setDescription('Permit: Configure top check settings')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable top check'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable top check')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // Permission check: Owner or ExtraOwner
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: 'Only the server owner or extra owners can use this command.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'enable') {
            permit.setFlag(guildId, 'topcheck', true);
            return interaction.reply({ content: 'Successfully enabled topcheck for this server.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'disable') {
            permit.setFlag(guildId, 'topcheck', false);
            return interaction.reply({ content: 'Successfully disabled topcheck for this server.', flags: MessageFlags.Ephemeral });
        }
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const guildId = message.guild.id;

        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **topcheck disable**\n› Disable topchecks for this server.\n\n` +
                `» **topcheck enable**\n› Enable topchecks for this server.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['enable', 'disable'].includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed] });
        }

        // Permission check: Owner or ExtraOwner
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embed.error('Only the server owner or extra owners can use this command.')] });
        }

        if (subcommand === 'enable') {
            permit.setFlag(guildId, 'topcheck', true);
            return message.reply({ embeds: [embed.success('Successfully enabled topcheck for this server.')] });
        }

        if (subcommand === 'disable') {
            permit.setFlag(guildId, 'topcheck', false);
            return message.reply({ embeds: [embed.success('Successfully disabled topcheck for this server.')] });
        }
    }
};
