const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    // Allow short alias `np` for prefix usage
    aliases: ['np'],
    data: new SlashCommandBuilder()
        .setName('noprefix')
        .setDescription('Manage the no-prefix list (Developer Only)')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a user to the no-prefix list').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a user from the no-prefix list').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show the no-prefix list'))
        .addSubcommand(sub => sub.setName('status').setDescription('Check no-prefix status for a user').addUserOption(opt => opt.setName('user').setDescription('The user')))
        .addSubcommand(sub => sub.setName('claim').setDescription('Claim no-prefix status'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable no-prefix for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable no-prefix for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset the no-prefix list'))
        .addSubcommand(sub => sub.setName('generate').setDescription('Generate a no-prefix code'))
        .addSubcommand(sub => sub.setName('trial').setDescription('Give a trial no-prefix to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true))),
    async execute(interaction) {
        // Turn slash invocation into our existing subcommand handling for parity with prefix usage
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: '❌ No access', ephemeral: true });
        }

        const sub = interaction.options.getSubcommand();
        // Convert options to args-like array for reuse
        const args = [];
        const subName = sub;
        args.push(subName);

        // If subcommands expect a user, attempt to find and append
        const userOpt = interaction.options.getUser('user');
        if (userOpt) args.push(`<@${userOpt.id}>`);

        // Reuse executeMessage logic by calling executeMessage with a fabricated message-like object
        const fakeMessage = {
            author: interaction.user,
            guild: interaction.guild,
            // Provide a minimal Collection-like interface used by existing handlers: `.mentions.users.first()`
            mentions: { users: { first: () => userOpt || null } },
            reply: (payload) => interaction.reply(payload),
        };

        try {
            return await this.executeMessage(fakeMessage, args);
        } catch (err) {
            console.error('Error handling slash noprefix:', err);
            return interaction.reply({ content: 'There was an error while handling this command.', ephemeral: true });
        }
    },

    async executeMessage(message, args) {
        if (message.author.id !== message.guild.ownerId) {
            return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **noprefix (alias: np) add/remove**\n› Manage no-prefix users.\n\n` +
                `» **noprefix (alias: np) show/status**\n› View no-prefix status.\n\n` +
                `» **noprefix (alias: np) enable/disable**\n› Toggle status.\n\n` +
                `» **noprefix (alias: np) claim**\n› Claim status.\n\n` +
                `» **noprefix (alias: np) reset**\n› Reset list.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'status', 'claim', 'enable', 'disable', 'reset', 'generate', 'trial'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const noprefix = require('../../functions/noprefixManager');

        // Ensure we operate on a per-guild dataset
        const gid = message.guild.id;

        if (subcommand === 'show') {
            const guildData = noprefix.getGuildData(gid);
            if (!guildData.users || guildData.users.length === 0) return message.reply({ embeds: [embedHelper.info('No users in the no-prefix list for this server.')] });
            return message.reply(`**No-Prefix Users (this server)**: ${guildData.users.map(id => `<@${id}>`).join(', ')}`);
        }

        if (subcommand === 'status') {
            const user = message.mentions.users.first() || message.author;
            const hasNoPrefix = noprefix.hasUser(gid, user.id);
            return message.reply({ embeds: [embedHelper.default(`${user} ${hasNoPrefix ? '**has**' : '**does not have**'} no-prefix status in this server.`)] });
        }

        if (subcommand === 'add') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to add.')] });
            if (noprefix.hasUser(gid, user.id)) return message.reply(`${user} already has no-prefix status in this server.`);
            noprefix.addUser(gid, user.id);
            return message.reply({ embeds: [embedHelper.success(`Successfully added ${user} to no-prefix list for this server.`)] });
        }

        if (subcommand === 'remove') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to remove.')] });
            if (!noprefix.hasUser(gid, user.id)) return message.reply(`${user} does not have no-prefix status in this server.`);
            noprefix.removeUser(gid, user.id);
            return message.reply({ embeds: [embedHelper.success(`Successfully removed ${user} from no-prefix list for this server.`)] });
        }

        if (subcommand === 'enable') {
            // "enable" now functions as: add user (alias kept for compatibility)
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to enable.')] });
            if (noprefix.hasUser(gid, user.id)) return message.reply(`${user} already has no-prefix enabled in this server.`);
            noprefix.addUser(gid, user.id);
            return message.reply({ embeds: [embedHelper.success(`Successfully enabled no-prefix for ${user} in this server.`)] });
        }

        if (subcommand === 'disable') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to disable.')] });
            if (!noprefix.hasUser(gid, user.id)) return message.reply(`${user} does not have no-prefix enabled in this server.`);
            noprefix.removeUser(gid, user.id);
            return message.reply({ embeds: [embedHelper.success(`Successfully disabled no-prefix for ${user} in this server.`)] });
        }

        if (subcommand === 'reset') {
            noprefix.resetGuild(gid);
            return message.reply({ embeds: [embedHelper.success('Successfully reset the no-prefix list for this server.')] });
        }

        if (subcommand === 'claim') {
            if (noprefix.hasUser(gid, message.author.id)) return message.reply({ embeds: [embedHelper.info('You already have no-prefix status in this server.')] });
            noprefix.addUser(gid, message.author.id);
            return message.reply({ embeds: [embedHelper.success('Successfully claimed no-prefix status for this server.')] });
        }

        return message.reply({ embeds: [embedHelper.default(`Subcommand \`${subcommand}\` executed successfully.`)] });
    }
};
