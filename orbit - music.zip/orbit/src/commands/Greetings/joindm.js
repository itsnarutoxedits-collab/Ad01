const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('joindm')
        .setDescription('Configure DM message sent to new members')
        .addSubcommand(sub => sub.setName('show').setDescription('Show current Join DM message'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set Join DM message').addStringOption(opt => opt.setName('message').setDescription('The message content').setRequired(true)))
        .addSubcommand(sub => sub.setName('test').setDescription('Test Join DM message'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable Join DM module'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset Join DM configuration'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable Join DM module')),
    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Join DM System').setDescription(`Executed joindm command: **${sub}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **joindm set**\n› Set Join DM message.\n\n` +
                `» **joindm test**\n› Test Join DM message.\n\n` +
                `» **joindm show**\n› Show current message.\n\n` +
                `» **joindm enable/disable**\n› Enable/Disable module.\n\n` +
                `» **joindm reset**\n› Reset configuration.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['show', 'set', 'test', 'enable', 'reset', 'disable'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/joindm.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, message: '' };

        if (!message.member.permissions.has('ManageGuild')) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Join DM module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Join DM module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'show') {
            const cfg = data[guildId];
            const showEmbed = new EmbedBuilder()
                .setTitle('Join DM Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Message', value: cfg.message || 'Not set' }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [showEmbed] });
        }

        if (subcommand === 'reset') {
            data[guildId] = { enabled: false, message: '' };
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Join DM configuration has been reset.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'set') {
            const msgContent = args.slice(1).join(' ');
            if (!msgContent) {
                return message.reply({ embeds: [embed.error('Please provide a message. Usage: `!joindm set <message>`\nVariables: {user}, {server}')] });
            }
            data[guildId].message = msgContent;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Join DM message has been set.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'test') {
            if (!data[guildId].message) {
                return message.reply('Please set a Join DM message first using `!joindm set <message>`');
            }
            try {
                let testMsg = data[guildId].message
                    .replace(/{user}/g, message.author.toString())
                    .replace(/{server}/g, message.guild.name);
                await message.author.send(testMsg);
                const confirmReply = await message.reply('✅ Test DM sent to you.');
                setTimeout(() => confirmReply.delete().catch(() => {}), 3000);
            } catch (error) {
                return message.reply('Failed to send DM. Please make sure your DMs are open.');
            }
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/joindm ${subcommand}\``);
    }
};
