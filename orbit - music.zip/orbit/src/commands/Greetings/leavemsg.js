const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leavemsg')
        .setDescription('Configure leave messages')
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset leave message configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable leave message module'))
        .addSubcommand(sub => sub.setName('test').setDescription('Test leave message'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable leave message module'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set leave message').addStringOption(opt => opt.setName('message').setDescription('The message content').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show current leave message config')),
    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Leave Message System').setDescription(`Executed leavemsg command: **${sub}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **leavemsg set**\n› Set leave message.\n\n` +
                `» **leavemsg test**\n› Test leave message.\n\n` +
                `» **leavemsg show**\n› Show current message.\n\n` +
                `» **leavemsg enable/disable**\n› Enable/Disable module.\n\n` +
                `» **leavemsg reset**\n› Reset configuration.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['reset', 'enable', 'test', 'disable', 'set', 'show'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/leavemsg.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, message: '' };

        if (!message.member.permissions.has('ManageGuild')) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        if (!data[guildId].channel) data[guildId].channel = null;

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Leave message module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Leave message module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'show') {
            const cfg = data[guildId];
            const showEmbed = new EmbedBuilder()
                .setTitle('Leave Message Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Channel', value: cfg.channel ? `<#${cfg.channel}>` : 'Not set', inline: true },
                    { name: 'Message', value: cfg.message || 'Not set' }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [showEmbed] });
        }

        if (subcommand === 'reset') {
            data[guildId] = { enabled: false, message: '', channel: null };
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Leave message configuration has been reset.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'set') {
            const msgContent = args.slice(1).join(' ');
            if (!msgContent) {
                return message.reply({ embeds: [embed.error('Please provide a message. Usage: `!leavemsg set <message>`\nVariables: {user}, {server}')] });
            }
            data[guildId].message = msgContent;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Leave message has been set.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'test') {
            if (!data[guildId].message) {
                return message.reply('Please set a leave message first using `!leavemsg set <message>`');
            }
            let testMsg = data[guildId].message
                .replace(/{user}/g, message.author.toString())
                .replace(/{server}/g, message.guild.name);
            await message.channel.send(testMsg);
            const confirmReply = await message.reply('✅ Test message sent.');
            setTimeout(() => confirmReply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/leavemsg ${subcommand}\``);
    }
};
