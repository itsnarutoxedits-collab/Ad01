const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('greet')
        .setDescription('Configure welcomer greetings')
        .addSubcommand(sub => sub.setName('test').setDescription('Test the welcomer message'))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage welcomer channel')
            .addSubcommand(sub => sub.setName('set').setDescription('Set welcomer channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset welcomer channel')))
        .addSubcommand(sub => sub.setName('delete').setDescription('Delete welcomer configuration'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable welcomer module'))
        .addSubcommand(sub => sub.setName('config').setDescription('Show welcomer configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable welcomer module'))
        .addSubcommand(sub => sub.setName('create').setDescription('Create a new welcomer message'))
        .addSubcommand(sub => sub.setName('style').setDescription('Change welcomer message style').addStringOption(opt => opt.setName('style').setDescription('Style name').setRequired(true)))
        .addSubcommand(sub => sub.setName('autodelete').setDescription('Set autodelete for greeting messages').addStringOption(opt => opt.setName('time').setDescription('Time (e.g. 10s, 1m)').setRequired(true)))
        .addSubcommand(sub => sub.setName('debug').setDescription('Show greet debug info'))
        .addSubcommand(sub => sub.setName('card').setDescription('Configure greeting card')),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Welcomer System').setDescription(`Executed greet command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **greet channel set <#channel>**\n› Set welcomer channel.\n\n` +
                `» **greet channel reset**\n› Reset welcomer channel.\n\n` +
                `» **greet config**\n› Show configuration.\n\n` +
                `» **greet enable/disable**\n› Enable/Disable module.\n\n` +
                `» **greet test**\n› Test welcomer message.\n\n` +
                `» **greet create <message>**\n› Create welcomer message.\n\n` +
                `» **greet delete**\n› Delete configuration.\n\n` +
                `» **greet style <style>**\n› Set message style.\n\n` +
                `» **greet autodelete <time>**\n› Set autodelete timer.\n\n` +
                `» **greet debug**\n› Show debug information and permissions.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['channel', 'test', 'delete', 'disable', 'config', 'enable', 'create', 'style', 'autodelete', 'debug', 'card'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        if (!message.member.permissions.has('ManageGuild')) {
            return message.reply({ embeds: [embed.error('❌ No access')] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/greet.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, channel: null, message: '', style: 'default', autodelete: null };

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Welcomer module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Welcomer module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'config') {
            const cfg = data[guildId];
            const configEmbed = new EmbedBuilder()
                .setTitle('Welcomer Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Channel', value: cfg.channel ? `<#${cfg.channel}>` : 'Not set', inline: true },
                    { name: 'Style', value: cfg.style || 'default', inline: true },
                    { name: 'Autodelete', value: cfg.autodelete || 'Disabled', inline: true },
                    { name: 'Message', value: cfg.message || 'Not set' }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [configEmbed] });
        }

        if (subcommand === 'delete') {
            data[guildId] = { enabled: false, channel: null, message: '', style: 'default', autodelete: null };
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Welcomer configuration has been deleted.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'channel') {
            const action = args[1] ? args[1].toLowerCase() : null;
            if (action === 'set') {
                const channelId = args[2] ? args[2].replace(/[<#>]/g, '') : null;
                if (!channelId) {
                    return message.reply('Please mention a channel. Usage: `!greet channel set #channel`');
                }
                const channel = message.guild.channels.cache.get(channelId);
                if (!channel) {
                    return message.reply('Invalid channel provided.');
                }
                data[guildId].channel = channelId;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply(`✅ Welcomer channel set to ${channel}`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'reset') {
                data[guildId].channel = null;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply('✅ Welcomer channel has been reset.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else {
                return message.reply('Usage: `!greet channel set #channel` or `!greet channel reset`');
            }
            return;
        }

        if (subcommand === 'create') {
            const msgContent = args.slice(1).join(' ');
            if (!msgContent) {
                return message.reply('Please provide a message. Usage: `!greet create <message>`\nVariables: {user}, {server}, {membercount}');
            }
            data[guildId].message = msgContent;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Welcomer message has been created.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'test') {
            if (!data[guildId].channel) {
                return message.reply('Please set a welcomer channel first using `!greet channel set #channel`');
            }
            if (!data[guildId].message) {
                return message.reply('Please create a welcomer message first using `!greet create <message>`');
            }
            const channel = message.guild.channels.cache.get(data[guildId].channel);
            if (!channel) {
                return message.reply('The configured welcomer channel no longer exists.');
            }
            let testMsg = data[guildId].message
                .replace(/{user}/g, message.author.toString())
                .replace(/{server}/g, message.guild.name)
                .replace(/{membercount}/g, message.guild.memberCount);
            await channel.send(testMsg);
            const reply = await message.reply('✅ Test message sent to welcomer channel.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }



        if (subcommand === 'debug') {
            const { GatewayIntentBits } = require('discord.js');
            const client = message.client;
            const listenerCount = client.listeners('guildMemberAdd') ? client.listeners('guildMemberAdd').length : 0;
            const hasGuildMembersIntent = Boolean(client.options?.intents && (client.options.intents & GatewayIntentBits.GuildMembers));
            const cfg = data[guildId] || {};
            const channelObj = cfg.channel ? message.guild.channels.cache.get(cfg.channel) : null;
            const botMember = message.guild.members.me;
            const botCanSend = channelObj ? channelObj.permissionsFor(botMember)?.has('SendMessages') : false;

            const debugEmbed = new EmbedBuilder()
                .setTitle('Welcomer Debug Info')
                .addFields(
                    { name: 'Module Enabled', value: cfg.enabled ? '✅ Yes' : '❌ No', inline: true },
                    { name: 'Channel Configured', value: cfg.channel ? `✅ <#${cfg.channel}>` : '❌ No', inline: true },
                    { name: 'Channel Exists', value: channelObj ? '✅ Yes' : '❌ No', inline: true },
                    { name: 'Bot Can Send', value: botCanSend ? '✅ Yes' : '❌ No', inline: true },
                    { name: 'GUILD_MEMBERS Intent', value: hasGuildMembersIntent ? '✅ Present' : '❌ Not present', inline: true },
                    { name: 'guildMemberAdd listeners', value: `${listenerCount}`, inline: true }
                )
                .setColor('#ffcc00');

            return message.reply({ embeds: [debugEmbed] });
        }

        if (subcommand === 'style') {
            const style = args[1];
            if (!style) {
                return message.reply('Please provide a style name. Usage: `!greet style <style>`');
            }
            data[guildId].style = style;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Welcomer style set to: ${style}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'autodelete') {
            const time = args[1];
            if (!time) {
                return message.reply('Please provide a time. Usage: `!greet autodelete <time>` (e.g., 10s, 1m)');
            }
            data[guildId].autodelete = time;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ Welcomer autodelete set to: ${time}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/greet ${subcommand}\``);
    }
};
