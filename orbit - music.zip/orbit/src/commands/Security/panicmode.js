const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('panicmode')
        .setDescription('Security: Configure server panic mode')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable panic mode'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable panic mode'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set panic mode settings'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset panic mode settings')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);
        
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand();
        const antinuke = require('../../functions/antinukeManager');
        const guildId = interaction.guild.id;
        const config = antinuke.getConfig(guildId);

        if (!config.enabled) {
            return interaction.reply({ content: 'Antinuke system is disabled. You must enable it first to use Panic Mode.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'enable') {
            antinuke.setConfig(guildId, { panicMode: true });
            const embed = new EmbedBuilder()
                .setDescription(`✅ **Panic Mode System Enabled**\nThe bot will now automatically trigger Z+ mode if server heat exceeds the threshold.\n\n**Settings Configured:**\n• Threshold: ${config.thresholdHeat}\n• Duration: 300s\n• Decay Rate: ${config.decayAmount}/min`)
                .setColor('#00ff00')
                .setFooter({ text: `Orbit™ Panic System`, iconURL: interaction.client.user.displayAvatarURL() });
            return interaction.reply({ embeds: [embed] });
        }

        if (subcommand === 'disable') {
            antinuke.setConfig(guildId, { panicMode: false });
            const embed = new EmbedBuilder()
                .setDescription(`✅ **Panic Mode System Disabled**\nThe automated panic mode system has been turned off.`)
                .setColor('#ff0000')
                .setFooter({ text: `Orbit™ Panic System`, iconURL: interaction.client.user.displayAvatarURL() });
            return interaction.reply({ embeds: [embed] });
        }

        const embed = new EmbedBuilder()
            .setTitle(`Panicmode: ${subcommand}`)
            .setDescription(`You have triggered the **${subcommand}** module of Panicmode.`)
            .setColor('#000000')
            .setFooter({ text: `Orbit™ Panic System`, iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed] });
    },

    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
        
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embed.error('❌ No access - Only server owner or extra owners can use this command')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **panicmode enable**\n› Enable panic mode.\n\n` +
                `» **panicmode disable**\n› Disable panic mode.\n\n` +
                `» **panicmode set**\n› Configure settings.\n\n` +
                `» **panicmode reset**\n› Reset settings.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['enable', 'disable', 'set', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const antinuke = require('../../functions/antinukeManager');
        const guildId = message.guild.id;
        const config = antinuke.getConfig(guildId);

        if (!config.enabled) {
            return message.reply({ embeds: [embed.error('Antinuke system is disabled. You must enable it first to use Panic Mode.')] });
        }

        if (subcommand === 'enable') {
            antinuke.setConfig(guildId, { panicMode: true });
            const embed2 = new EmbedBuilder()
                .setDescription(`✅ **Panic Mode System Enabled**\nThe bot will now automatically trigger Z+ mode if server heat exceeds the threshold.\n\n**Settings Configured:**\n• Threshold: ${config.thresholdHeat}\n• Duration: 300s\n• Decay Rate: ${config.decayAmount}/min`)
                .setColor('#00ff00')
                .setFooter({ text: `Orbit™ Panic System`, iconURL: message.client.user.displayAvatarURL() });
            return message.reply({ embeds: [embed2] });
        }

        if (subcommand === 'disable') {
            antinuke.setConfig(guildId, { panicMode: false });
            const embed2 = new EmbedBuilder()
                .setDescription(`✅ **Panic Mode System Disabled**\nThe automated panic mode system has been turned off.`)
                .setColor('#ff0000')
                .setFooter({ text: `Orbit™ Panic System`, iconURL: message.client.user.displayAvatarURL() });
            return message.reply({ embeds: [embed2] });
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/panicmode ${subcommand}\``);
    }
};
