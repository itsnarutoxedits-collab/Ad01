const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../../data/customrole.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

function ensureGuildData(data, guildId) {
    if (!data[guildId]) data[guildId] = { names: [], roles: [], reqrole: null };
    // Migration from old check if needed, but we assume fresh start or overwrite for dynamic system
    if (!data[guildId].names) data[guildId] = { names: [], roles: [], reqrole: null };
    return data;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('customrole')
        .setDescription('Manage custom roles')
        .addSubcommand(sub => sub.setName('setup').setDescription('Setup the custom role module')) // Adding setup as subcommand if needed, or just relying on subcommands
        .addSubcommand(sub => sub.setName('add').setDescription('Add a custom role').addStringOption(opt => opt.setName('name').setDescription('Name').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a custom role').addStringOption(opt => opt.setName('name').setDescription('Name').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List custom roles'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset configuration'))
        .addSubcommand(sub => sub.setName('reqrole').setDescription('Set required role').addRoleOption(opt => opt.setName('role').setDescription('Role (empty to check)').setRequired(false))),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;
        let data = getData();
        ensureGuildData(data, guildId);

        if (sub === 'add') {
            const name = interaction.options.getString('name').toLowerCase();
            const role = interaction.options.getRole('role');

            if (data[guildId].names.includes(name)) {
                return interaction.reply({ embeds: [embedHelper.error(`Custom role command **${name}** already exists.`)] });
            }

            data[guildId].names.push(name);
            data[guildId].roles.push(role.id);
            setData(data);
            return interaction.reply({ embeds: [embedHelper.success(`Added custom role command **${name}** for ${role}.`)] });
        }

        if (sub === 'remove') {
            const name = interaction.options.getString('name').toLowerCase();
            const idx = data[guildId].names.indexOf(name);
            if (idx === -1) {
                return interaction.reply({ embeds: [embedHelper.error(`Custom role command **${name}** not found.`)] });
            }

            data[guildId].names.splice(idx, 1);
            data[guildId].roles.splice(idx, 1);
            setData(data);
            return interaction.reply({ embeds: [embedHelper.success(`Removed custom role command **${name}**.`)] });
        }

        if (sub === 'list') {
            const names = data[guildId].names;
            const roles = data[guildId].roles;

            if (names.length === 0) {
                return interaction.reply({ embeds: [embedHelper.info('No custom roles configured.')] });
            }

            const description = names.map((n, i) => `**${n}**: <@&${roles[i]}>`).join('\n');
            const embed = new EmbedBuilder()
                .setTitle('Custom Roles Configuration')
                .setDescription(description)
                .addFields({ name: 'Required Role', value: data[guildId].reqrole ? `<@&${data[guildId].reqrole}>` : 'None' })
                .setColor('#2b2d31');
            return interaction.reply({ embeds: [embed] });
        }

        if (sub === 'reset') {
            data[guildId] = { names: [], roles: [], reqrole: null };
            setData(data);
            return interaction.reply({ embeds: [embedHelper.success('Custom roles reset.')] });
        }

        if (sub === 'reqrole') {
            const role = interaction.options.getRole('role');
            data[guildId].reqrole = role ? role.id : null;
            setData(data);
            return interaction.reply({ embeds: [embedHelper.success(`Required role set to ${role ? role : 'None'}.`)] });
        }
    },

    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        }

        const sub = args[0] ? args[0].toLowerCase() : 'help';
        const guildId = message.guild.id;
        let data = getData();
        ensureGuildData(data, guildId);

        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **setup add <name> <role>**\n› Add a custom role.\n\n` +
                `» **setup remove <name>**\n› Remove a custom role.\n\n` +
                `» **setup list**\n› List custom roles.\n\n` +
                `» **setup reqrole [role]**\n› Set/Check required role.\n\n` +
                `» **setup reset**\n› Reset all custom roles.`
            )
            .setColor('#2b2d31');

        if (sub === 'help' || !['add', 'remove', 'list', 'reset', 'reqrole'].includes(sub)) {
            return message.reply({ embeds: [embed] });
        }

        if (sub === 'add') {
            const name = args[1];
            const role = message.mentions.roles.first();
            if (!name || !role) return message.reply({ embeds: [embedHelper.error('Usage: `!setup add <name> @role`')] });

            if (data[guildId].names.includes(name.toLowerCase())) {
                return message.reply({ embeds: [embedHelper.error(`Custom role **${name}** already exists.`)] });
            }

            data[guildId].names.push(name.toLowerCase());
            data[guildId].roles.push(role.id);
            setData(data);
            return message.reply({ embeds: [embedHelper.success(`Added custom role **${name}** for ${role}.`)] });
        }

        if (sub === 'remove') {
            const name = args[1];
            if (!name) return message.reply({ embeds: [embedHelper.error('Usage: `!setup remove <name>`')] });

            const idx = data[guildId].names.indexOf(name.toLowerCase());
            if (idx === -1) {
                return message.reply({ embeds: [embedHelper.error(`Custom role **${name}** not found.`)] });
            }

            data[guildId].names.splice(idx, 1);
            data[guildId].roles.splice(idx, 1);
            setData(data);
            return message.reply({ embeds: [embedHelper.success(`Removed custom role **${name}**.`)] });
        }

        if (sub === 'list') {
            const names = data[guildId].names;
            const roles = data[guildId].roles;
            if (names.length === 0) return message.reply({ embeds: [embedHelper.info('No custom roles configured.')] });

            const listStr = names.map((n, i) => `**${n}**: <@&${roles[i]}>`).join('\n');
            const listEmbed = new EmbedBuilder()
                .setTitle('Custom Roles Configuration')
                .setDescription(listStr)
                .addFields({ name: 'Required Role', value: data[guildId].reqrole ? `<@&${data[guildId].reqrole}>` : 'None' })
                .setColor('#2b2d31');
            return message.reply({ embeds: [listEmbed] });
        }

        if (sub === 'reset') {
            data[guildId] = { names: [], roles: [], reqrole: null };
            setData(data);
            return message.reply({ embeds: [embedHelper.success('Custom check reset.')] });
        }

        if (sub === 'reqrole') {
            const role = message.mentions.roles.first();
            data[guildId].reqrole = role ? role.id : null;
            setData(data);
            return message.reply({ embeds: [embedHelper.success(`Required role set to ${role ? role : 'None'}.`)] });
        }
    }
};
