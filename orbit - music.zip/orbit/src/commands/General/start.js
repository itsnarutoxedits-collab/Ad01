const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('start')
        .setDescription('Starts the bot interaction'),
    async execute(interaction) {
        await interaction.reply('bot is start');
    },
};
