const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('messages')
            .setDescription('Check your or another user\'s message count')
            .addUserOption(opt => opt.setName('user').setDescription('The user to check')),
        async execute(interaction) {
            const user = interaction.options.getUser('user') || interaction.user;
            const statsManager = require('../../functions/statsManager');
            const stats = statsManager.getUserStats(interaction.guild.id, user.id);
            await interaction.reply({ embeds: [embedHelper.info(`${user.username} has **${stats.total.toLocaleString()}** messages.`)] });
        },
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;
            const statsManager = require('../../functions/statsManager');
            const stats = statsManager.getUserStats(message.guild.id, target.id);
            return message.reply({ embeds: [embedHelper.info(`💬 **${target.username}** has sent **${stats.total.toLocaleString()}** messages.`)] });
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('message')
            .setDescription('Manage message counting system')
            .addSubcommand(sub => sub.setName('rolereward').setDescription('Configure message role rewards').addIntegerOption(opt => opt.setName('messages').setDescription('Message count').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role to reward').setRequired(true)))
            .addSubcommand(sub => sub.setName('config').setDescription('Show message count configuration'))
            .addSubcommand(sub => sub.setName('lbweekly').setDescription('Show weekly message leaderboard'))
            .addSubcommand(sub => sub.setName('blchannel').setDescription('Blacklist a channel from counting messages').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('lbdaily').setDescription('Show daily message leaderboard'))
            .addSubcommand(sub => sub.setName('add').setDescription('Add messages to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages').setRequired(true)))
            .addSubcommand(sub => sub.setName('resetme').setDescription('Reset your own message count'))
            .addSubcommand(sub => sub.setName('rolereset').setDescription('Reset all message role rewards'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove messages from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset message count for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('unblchannel').setDescription('Unblacklist a channel from counting messages').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('leaderboard').setDescription('Show overall message leaderboard')),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            const statsManager = require('../../functions/statsManager');
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/messages.json');

            // Should reuse logic or call executeMessage? 
            // Better to implement cleanly.

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = interaction.guild.id;
            if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, blacklist: [] };

            if (sub === 'config') {
                const cfg = data[guildId];
                const configEmbed = new EmbedBuilder()
                    .setTitle('📊 Message Configuration')
                    .addFields(
                        { name: 'Role Rewards', value: `${Object.keys(cfg.roleRewards || {}).length}`, inline: true },
                        { name: 'Blacklisted Channels', value: `${(cfg.blacklist || []).length}`, inline: true }
                    )
                    .setColor('#5865F2');
                return interaction.reply({ embeds: [configEmbed] });
            }

            if (['leaderboard', 'lbdaily', 'lbweekly'].includes(sub)) {
                const type = sub === 'lbdaily' ? 'dailymessages' : 'messages';
                const topUsers = statsManager.getTopUsers(guildId, type, 10);

                let desc = 'No data yet';
                if (topUsers.length > 0) {
                    desc = topUsers.map((u, i) => `${i + 1}. <@${u.id}> - ${u.value.toLocaleString()} messages`).join('\n');
                }

                const lbEmbed = new EmbedBuilder()
                    .setTitle(`🏆 Message Leaderboard ${sub === 'lbdaily' ? '(Daily)' : ''}`)
                    .setDescription(desc)
                    .setColor('#FFD700');
                return interaction.reply({ embeds: [lbEmbed] });
            }

            // ... Permission checks for admin commands ...
            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(sub) && !interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', ephemeral: true });
            }

            if (sub === 'resetme') {
                statsManager.setUserMessages(guildId, interaction.user.id, 0);
                return interaction.reply({ content: '✅ Your message count has been reset.', ephemeral: true });
            }

            if (sub === 'add') {
                const target = interaction.options.getUser('user');
                const amount = interaction.options.getInteger('amount');
                const current = statsManager.getUserStats(guildId, target.id).total;
                statsManager.setUserMessages(guildId, target.id, current + amount);
                return interaction.reply({ embeds: [embedHelper.success(`✅ Added ${amount} messages to ${target}.`)] });
            }

            if (sub === 'remove') {
                const target = interaction.options.getUser('user');
                const amount = interaction.options.getInteger('amount');
                const current = statsManager.getUserStats(guildId, target.id).total;
                statsManager.setUserMessages(guildId, target.id, Math.max(0, current - amount));
                return interaction.reply({ embeds: [embedHelper.success(`✅ Removed ${amount} messages from ${target}.`)] });
            }

            if (sub === 'reset') {
                const target = interaction.options.getUser('user');
                statsManager.setUserMessages(guildId, target.id, 0);
                return interaction.reply({ embeds: [embedHelper.success(`✅ Reset messages for ${target}.`)] });
            }

            // ... Other config commands (rolereward, blacklist) still use messages.json ...
            if (sub === 'rolereward') {
                const messageCount = interaction.options.getInteger('messages');
                const role = interaction.options.getRole('role');
                if (!data[guildId].roleRewards) data[guildId].roleRewards = {};
                data[guildId].roleRewards[messageCount] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return interaction.reply({ embeds: [embedHelper.success(`✅ ${role} will be rewarded at ${messageCount} messages.`)] });
            }

            if (sub === 'rolereset') {
                data[guildId].roleRewards = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return interaction.reply({ embeds: [embedHelper.success('✅ All message role rewards have been reset.')] });
            }

            if (sub === 'blchannel') {
                const channel = interaction.options.getChannel('channel');
                if (!data[guildId].blacklist) data[guildId].blacklist = [];
                if (data[guildId].blacklist.includes(channel.id)) return interaction.reply({ embeds: [embedHelper.info(`${channel} is already blacklisted.`)] });
                data[guildId].blacklist.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return interaction.reply({ embeds: [embedHelper.success(`✅ ${channel} blacklisted from message counting.`)] });
            }

            if (sub === 'unblchannel') {
                const channel = interaction.options.getChannel('channel');
                if (!data[guildId].blacklist || !data[guildId].blacklist.includes(channel.id)) return interaction.reply({ embeds: [embedHelper.info(`${channel} is not blacklisted.`)] });
                data[guildId].blacklist = data[guildId].blacklist.filter(c => c !== channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return interaction.reply({ embeds: [embedHelper.success(`✅ ${channel} removed from blacklist.`)] });
            }
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **message config**\n› Show configuration.\n\n` +
                    `» **message leaderboard** (or label: lb)\n› Show message leaderboard.\n\n` +
                    `» **message rolereward <messages> @role**\n› Set role reward.\n\n` +
                    `» **message rolereset**\n› Reset role rewards.\n\n` +
                    `» **message blchannel/unblchannel #channel**\n› Manage blacklist.\n\n` +
                    `» **message add/remove/reset @user <amount>**\n› Manage messages.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['config', 'leaderboard', 'rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset', 'resetme', 'lb', 'lbweekly', 'lbdaily'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(subcommand) && !message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/messages.json');
            const statsManager = require('../../functions/statsManager');

            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }

            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, blacklist: [] };

            if (subcommand === 'config') {
                const cfg = data[guildId];
                const configEmbed = new EmbedBuilder()
                    .setTitle('📊 Message Configuration')
                    .addFields(
                        { name: 'Role Rewards', value: `${Object.keys(cfg.roleRewards || {}).length}`, inline: true },
                        { name: 'Blacklisted Channels', value: `${(cfg.blacklist || []).length}`, inline: true }
                    )
                    .setColor('#5865F2');
                return message.reply({ embeds: [configEmbed] });
            }

            if (['leaderboard', 'lb', 'lbdaily'].includes(subcommand)) {
                // Use statsManager
                const type = subcommand === 'lbdaily' ? 'dailymessages' : 'messages';
                const topUsers = statsManager.getTopUsers(guildId, type, 10);

                let desc = 'No data yet';
                if (topUsers.length > 0) {
                    desc = topUsers.map((u, i) => `${i + 1}. <@${u.id}> - ${u.value.toLocaleString()} messages`).join('\n');
                }

                const lbEmbed = new EmbedBuilder()
                    .setTitle(`🏆 Message Leaderboard ${subcommand === 'lbdaily' ? '(Daily)' : ''}`)
                    .setDescription(desc)
                    .setColor('#FFD700');
                return message.reply({ embeds: [lbEmbed] });
            }

            if (subcommand === 'resetme') {
                statsManager.setUserMessages(guildId, message.author.id, 0);
                return message.reply({ embeds: [embedHelper.success('✅ Your message count has been reset.')] });
            }

            if (subcommand === 'rolereward') {
                const messageCount = parseInt(args[1]);
                const role = message.mentions.roles.first();
                if (!messageCount || !role) return message.reply({ embeds: [embedHelper.info('Usage: `!message rolereward <messages> @role`')] });
                if (!data[guildId].roleRewards) data[guildId].roleRewards = {};
                data[guildId].roleRewards[messageCount] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${role} will be rewarded at ${messageCount} messages.`)] });
            }

            if (subcommand === 'rolereset') {
                data[guildId].roleRewards = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ All message role rewards have been reset.')] });
            }

            if (subcommand === 'blchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!message blchannel #channel`')] });
                if (!data[guildId].blacklist) data[guildId].blacklist = [];
                if (data[guildId].blacklist.includes(channel.id)) return message.reply({ embeds: [embedHelper.info(`${channel} is already blacklisted.`)] });
                data[guildId].blacklist.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} blacklisted from message counting.`)] });
            }

            if (subcommand === 'unblchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!message unblchannel #channel`')] });
                if (!data[guildId].blacklist || !data[guildId].blacklist.includes(channel.id)) {
                    return message.reply({ embeds: [embedHelper.info(`${channel} is not blacklisted.`)] });
                }
                data[guildId].blacklist = data[guildId].blacklist.filter(c => c !== channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} removed from blacklist.`)] });
            }

            if (subcommand === 'add') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!message add @user <amount>`')] });

                const current = statsManager.getUserStats(guildId, target.id).total;
                statsManager.setUserMessages(guildId, target.id, current + amount);

                return message.reply({ embeds: [embedHelper.success(`✅ Added ${amount} messages to ${target}.`)] });
            }

            if (subcommand === 'remove') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!message remove @user <amount>`')] });

                const current = statsManager.getUserStats(guildId, target.id).total;
                statsManager.setUserMessages(guildId, target.id, Math.max(0, current - amount));

                return message.reply({ embeds: [embedHelper.success(`✅ Removed ${amount} messages from ${target}.`)] });
            }

            if (subcommand === 'reset') {
                const target = message.mentions.users.first();
                if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!message reset @user`')] });
                statsManager.setUserMessages(guildId, target.id, 0);
                return message.reply({ embeds: [embedHelper.success(`✅ Reset messages for ${target}.`)] });
            }

            return message.reply({ embeds: [embed] });
        }
    }
];
