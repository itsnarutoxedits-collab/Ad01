const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tempvc')
        .setDescription('Manage your temporary voice channel')
        .addSubcommand(sub => sub.setName('name').setDescription('Change the name of your VC').addStringOption(opt => opt.setName('name').setDescription('New name').setRequired(true)))
        .addSubcommand(sub => sub.setName('ban').setDescription('Ban a user from your VC').addUserOption(opt => opt.setName('user').setDescription('User to ban').setRequired(true)))
        .addSubcommand(sub => sub.setName('lock').setDescription('Lock your VC'))
        .addSubcommand(sub => sub.setName('unban').setDescription('Unban a user from your VC').addUserOption(opt => opt.setName('user').setDescription('User to unban').setRequired(true)))
        .addSubcommand(sub => sub.setName('trust').setDescription('Trust a user in your VC').addUserOption(opt => opt.setName('user').setDescription('User to trust').setRequired(true)))
        .addSubcommand(sub => sub.setName('transfer').setDescription('Transfer VC ownership').addUserOption(opt => opt.setName('user').setDescription('New owner').setRequired(true)))
        .addSubcommand(sub => sub.setName('config').setDescription('Show your VC configuration'))
        .addSubcommand(sub => sub.setName('limit').setDescription('Set member limit for your VC').addIntegerOption(opt => opt.setName('limit').setDescription('Limit').setRequired(true).setMinValue(0).setMaxValue(99)))
        .addSubcommandGroup(group => group.setName('lobby').setDescription('Manage your VC lobby')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a lobby role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a lobby role').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('edit').setDescription('Edit lobby settings')))
        .addSubcommand(sub => sub.setName('claim').setDescription('Claim ownership of the current VC'))
        .addSubcommand(sub => sub.setName('hide').setDescription('Hide your VC'))
        .addSubcommand(sub => sub.setName('kick').setDescription('Kick a user from your VC').addUserOption(opt => opt.setName('user').setDescription('User to kick').setRequired(true)))
        .addSubcommand(sub => sub.setName('untrust').setDescription('Untrust a user in your VC').addUserOption(opt => opt.setName('user').setDescription('User to untrust').setRequired(true)))
        .addSubcommand(sub => sub.setName('unlock').setDescription('Unlock your VC'))
        .addSubcommand(sub => sub.setName('unhide').setDescription('Unhide your VC')),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('VoiceMaster').setDescription(`Executed tempvc command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const { PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';

        const pages = [
            new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **tempvc lock**\n› Lock your voice channel.\n\n` +
                    `» **tempvc unlock**\n› Unlock your voice channel.\n\n` +
                    `» **tempvc hide**\n› Hide your voice channel.\n\n` +
                    `» **tempvc unhide**\n› Unhide your voice channel.\n\n` +
                    `» **tempvc name <name>**\n› Rename your voice channel.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/3 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() }),
            new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **tempvc limit <number>**\n› Set user limit (0-99).\n\n` +
                    `» **tempvc ban @user**\n› Ban user from your VC.\n\n` +
                    `» **tempvc unban @user**\n› Unban user from your VC.\n\n` +
                    `» **tempvc kick @user**\n› Kick user from your VC.\n\n` +
                    `» **tempvc trust @user**\n› Trust user in your VC.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 2/3 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() }),
            new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **tempvc untrust @user**\n› Untrust user from your VC.\n\n` +
                    `» **tempvc claim**\n› Claim ownership of VC.\n\n` +
                    `» **tempvc transfer @user**\n› Transfer VC ownership.\n\n` +
                    `» **tempvc config**\n› Show VC configuration.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 3/3 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
        ];

        if (subcommand === 'help' || !['name', 'limit', 'hide', 'unhide', 'lock', 'unlock', 'claim', 'ban', 'unban', 'trust', 'untrust', 'transfer', 'config', 'kick'].includes(subcommand)) {
            let currentPage = 0;

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('previous')
                        .setLabel('◀')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('▶')
                        .setStyle(ButtonStyle.Secondary)
                );

            const msg = await message.reply({ embeds: [pages[currentPage]], components: [row] });

            const collector = msg.createMessageComponentCollector({
                componentType: ComponentType.Button,
                time: 60000
            });

            collector.on('collect', async i => {
                if (i.user.id !== message.author.id) {
                    return i.reply({ content: 'This is not for you!', flags: MessageFlags.Ephemeral });
                }

                if (i.customId === 'previous') {
                    currentPage--;
                } else if (i.customId === 'next') {
                    currentPage++;
                }

                row.components[0].setDisabled(currentPage === 0);
                row.components[1].setDisabled(currentPage === pages.length - 1);

                await i.update({ embeds: [pages[currentPage]], components: [row] });
            });

            collector.on('end', () => {
                row.components.forEach(button => button.setDisabled(true));
                msg.edit({ components: [row] }).catch(() => { });
            });

            return;
        }

        if (!message.member.voice.channel) {
            return message.reply({ embeds: [embed.error('You must be in a voice channel to use this command.')] });
        }

        const voiceChannel = message.member.voice.channel;

        // Lock command
        if (subcommand === 'lock') {
            try {
                await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    Connect: false
                });
                const reply = await message.reply({ embeds: [embed.success(`🔒 Locked your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to lock the voice channel.')] });
            }
            return;
        }

        // Unlock command
        if (subcommand === 'unlock') {
            try {
                await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    Connect: null
                });
                const reply = await message.reply({ embeds: [embed.success(`🔓 Unlocked your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to unlock the voice channel.')] });
            }
            return;
        }

        // Hide command
        if (subcommand === 'hide') {
            try {
                await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    ViewChannel: false
                });
                const reply = await message.reply({ embeds: [embed.success(`👁️ Hidden your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to hide the voice channel.')] });
            }
            return;
        }

        // Unhide command
        if (subcommand === 'unhide') {
            try {
                await voiceChannel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    ViewChannel: null
                });
                const reply = await message.reply({ embeds: [embed.success(`👁️ Unhidden your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to unhide the voice channel.')] });
            }
            return;
        }

        // Name command
        if (subcommand === 'name') {
            const newName = args.slice(1).join(' ');
            if (!newName) {
                return message.reply({ embeds: [embed.info('Please provide a new name. Usage: `!tempvc name <new name>`')] });
            }
            try {
                await voiceChannel.setName(newName);
                const reply = await message.reply({ embeds: [embed.success(`✅ Renamed voice channel to: **${newName}**`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to rename the voice channel.')] });
            }
            return;
        }

        // Limit command
        if (subcommand === 'limit') {
            const limit = parseInt(args[1]);
            if (isNaN(limit) || limit < 0 || limit > 99) {
                return message.reply({ embeds: [embed.info('Please provide a valid limit (0-99). Usage: `!tempvc limit <number>`')] });
            }
            try {
                await voiceChannel.setUserLimit(limit);
                const reply = await message.reply({ embeds: [embed.success(`✅ Set user limit to: **${limit === 0 ? 'Unlimited' : limit}**`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to set user limit.')] });
            }
            return;
        }

        // Ban command
        if (subcommand === 'ban') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc ban @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await voiceChannel.permissionOverwrites.edit(member, {
                    Connect: false
                });
                if (member.voice.channel?.id === voiceChannel.id) {
                    await member.voice.disconnect();
                }
                const reply = await message.reply({ embeds: [embed.success(`🚫 Banned **${member.user.tag}** from your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to ban the user.')] });
            }
            return;
        }

        // Unban command
        if (subcommand === 'unban') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc unban @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await voiceChannel.permissionOverwrites.delete(member);
                const reply = await message.reply({ embeds: [embed.success(`✅ Unbanned **${member.user.tag}** from your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to unban the user.')] });
            }
            return;
        }

        // Kick command
        if (subcommand === 'kick') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc kick @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                if (!member.voice.channel || member.voice.channel.id !== voiceChannel.id) {
                    return message.reply({ embeds: [embed.info('This user is not in your voice channel.')] });
                }
                await member.voice.disconnect();
                const reply = await message.reply({ embeds: [embed.success(`✅ Kicked **${member.user.tag}** from your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to kick the user.')] });
            }
            return;
        }

        // Trust command
        if (subcommand === 'trust') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc trust @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await voiceChannel.permissionOverwrites.edit(member, {
                    Connect: true,
                    Speak: true,
                    Stream: true
                });
                const reply = await message.reply({ embeds: [embed.success(`✅ Trusted **${member.user.tag}** in your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to trust the user.')] });
            }
            return;
        }

        // Untrust command
        if (subcommand === 'untrust') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc untrust @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await voiceChannel.permissionOverwrites.delete(member);
                const reply = await message.reply({ embeds: [embed.success(`✅ Untrusted **${member.user.tag}** in your voice channel`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to untrust the user.')] });
            }
            return;
        }

        // Transfer command
        if (subcommand === 'transfer') {
            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embed.info('Please mention a user. Usage: `!tempvc transfer @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                if (!member.voice.channel || member.voice.channel.id !== voiceChannel.id) {
                    return message.reply({ embeds: [embed.info('The user must be in your voice channel.')] });
                }
                // Transfer ownership by giving them all permissions and removing yours
                await voiceChannel.permissionOverwrites.edit(member, {
                    Connect: true,
                    ManageChannels: true,
                    MoveMembers: true,
                    MuteMembers: true,
                    DeafenMembers: true
                });
                await voiceChannel.permissionOverwrites.delete(message.member);
                const reply = await message.reply({ embeds: [embed.success(`✅ Transferred ownership to **${member.user.tag}**`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to transfer ownership.')] });
            }
            return;
        }

        // Claim command
        if (subcommand === 'claim') {
            try {
                await voiceChannel.permissionOverwrites.edit(message.member, {
                    Connect: true,
                    ManageChannels: true,
                    MoveMembers: true,
                    MuteMembers: true,
                    DeafenMembers: true
                });
                const reply = await message.reply({ embeds: [embed.success(`✅ Claimed ownership of **${voiceChannel.name}**`)] });
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to claim the voice channel.')] });
            }
            return;
        }

        // Config command
        if (subcommand === 'config') {
            try {
                const overwrites = voiceChannel.permissionOverwrites.cache;
                const bannedUsers = overwrites.filter(o => o.deny.has(PermissionFlagsBits.Connect) && o.type === 1);
                const trustedUsers = overwrites.filter(o => o.allow.has(PermissionFlagsBits.Connect) && o.type === 1);

                const configEmbed = new EmbedBuilder()
                    .setTitle(`Configuration: ${voiceChannel.name}`)
                    .addFields(
                        { name: 'User Limit', value: voiceChannel.userLimit === 0 ? 'Unlimited' : voiceChannel.userLimit.toString(), inline: true },
                        { name: 'Members', value: voiceChannel.members.size.toString(), inline: true },
                        { name: 'Locked', value: overwrites.find(o => o.id === message.guild.roles.everyone.id)?.deny.has(PermissionFlagsBits.Connect) ? 'Yes' : 'No', inline: true },
                        { name: 'Banned Users', value: bannedUsers.size > 0 ? bannedUsers.map(o => `<@${o.id}>`).join(', ') : 'None' },
                        { name: 'Trusted Users', value: trustedUsers.size > 0 ? trustedUsers.map(o => `<@${o.id}>`).join(', ') : 'None' }
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [configEmbed] });
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embed.error('Failed to fetch configuration.')] });
            }
        }

        return message.reply({ embeds: [embed.info(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/tempvc ${subcommand}\``)] });
    }
};
