const { EmbedBuilder } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

// --- Command Lists ---
const interactionCmds = ['cuddle', 'hug', 'kiss', 'nom', 'pat', 'poke', 'slap', 'stare', 'highfive', 'bite', 'punch', 'handholding', 'tickle', 'hold', 'wave', 'snuggle', 'spank', 'marry', 'pet'];
const reactionCmds = ['blush', 'cry', 'dance', 'pout', 'shrug', 'sleepy', 'smile', 'smug', 'thumbsup', 'thinking', 'triggered', 'teehee', 'happy', 'thumbs', 'pray', 'curse'];
const simpleTextCmds = ['joke', 'fact', 'cat', 'pickup', 'showerthought'];
const textInputCmds = ['reverse', 'mock', 'opinion'];
const memeCmds = ['biden', 'pikachu', 'oogway', 'drake', 'pooh', 'sadcat', 'wanted', 'supreme', 'alert'];

// --- Handlers ---

async function handleInteraction(message, args, cmd) {
    const target = message.mentions.users.first();
    if (!target) return message.reply({ embeds: [embedHelper.info(`Please mention a user. Usage: \`!${cmd} @user\``)] });

    const responses = {
        hug: [`${message.author} gives ${target} a warm hug! 🤗`, `${target} receives a big hug from ${message.author}! 💕`],
        kiss: [`${message.author} kisses ${target}! 💋`, `${target} got kissed by ${message.author}! 😘`],
        slap: [`${message.author} slaps ${target}! 👋`, `${target} just got slapped by ${message.author}! 😱`],
        pat: [`${message.author} pats ${target} on the head! 😊`, `${target} got headpats from ${message.author}! 🥰`],
        poke: [`${message.author} pokes ${target}! 👉`, `${target} got poked by ${message.author}!`],
        cuddle: [`${message.author} cuddles with ${target}! 🥰`, `${target} is cuddling with ${message.author}! 💖`],
        bite: [`${message.author} bites ${target}! 😬`, `${target} just got bitten by ${message.author}! 🦷`],
        punch: [`${message.author} punches ${target}! 👊`, `${target} got punched by ${message.author}! 💥`],
        highfive: [`${message.author} high-fives ${target}! ✋`, `${target} and ${message.author} high-five! 🙌`],
        marry: [`${message.author} proposes to ${target}! 💍`, `${target} got a marriage proposal from ${message.author}! 💒`],
        pet: [`${message.author} pets ${target}! 🐾`, `${target} is being petted by ${message.author}! 😸`]
    };

    const list = responses[cmd] || [`${message.author} **${cmd}s** ${target}!`];
    const text = list[Math.floor(Math.random() * list.length)];

    // Using a default color per command type could be nice
    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor('#2b2d31')
        .setTimestamp();

    return message.reply({ embeds: [embed] });
}

async function handleReaction(message, args, cmd) {
    const reactions = {
        blush: [`${message.author} is blushing! 😊`, `${message.author} turns red! ☺️`],
        cry: [`${message.author} is crying! 😢`, `${message.author} breaks down in tears! 😭`],
        dance: [`${message.author} is dancing! 💃`, `${message.author} busts a move! 🕺`],
        smile: [`${message.author} smiles! 😊`, `${message.author} grins happily! 😄`],
        happy: [`${message.author} is happy! 😊`, `${message.author} feels joyful! 🥳`],
        thinking: [`${message.author} is thinking... 🤔`, `${message.author} ponders deeply! 💭`],
        sleepy: [`${message.author} is feeling sleepy! 😴`, `${message.author} yawns! 🥱`],
        pout: [`${message.author} pouts! 😤`, `${message.author} makes a pouty face! 😾`],
        shrug: [`${message.author} shrugs! 🤷`, `${message.author} doesn't know! 🤷‍♂️`],
        pray: [`${message.author} is praying! 🙏`, `${message.author} says a prayer! 🙏`],
        triggered: [`${message.author} is TRIGGERED! 😡`, `${message.author} is mad! 😠`]
    };

    const list = reactions[cmd] || [`${message.author} is feeling **${cmd}**!`];
    const text = list[Math.floor(Math.random() * list.length)];

    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor('#2b2d31')
        .setTimestamp();

    return message.reply({ embeds: [embed] });
}

async function handleSimpleText(message, args, cmd) {
    let content = '';
    if (cmd === 'joke') {
        const jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "What do you call a bear with no teeth? A gummy bear!",
            "Why did the scarecrow win an award? He was outstanding in his field!",
            "What do you call fake spaghetti? An impasta!",
            "Why don't eggs tell jokes? They'd crack up!",
            "What did the ocean say to the beach? Nothing, it just waved!",
            "Why was the math book sad? It had too many problems!"
        ];
        content = `😂 ${jokes[Math.floor(Math.random() * jokes.length)]}`;
    }
    else if (cmd === 'fact') {
        const facts = [
            "Honey never spoils. Archaeologists have found 3000-year-old honey that's still edible!",
            "Octopuses have three hearts and blue blood!",
            "Bananas are berries, but strawberries aren't!",
            "A group of flamingos is called a 'flamboyance'!",
            "The shortest war in history lasted 38 minutes!",
            "Hot water freezes faster than cold water!",
            "Butterflies can taste with their feet!",
            "A bolt of lightning is five times hotter than the sun!"
        ];
        content = `💡 ${facts[Math.floor(Math.random() * facts.length)]}`;
    }
    else if (cmd === 'cat') content = '🐱 Meow! Here\'s a random cat fact: Cats sleep 70% of their lives!';
    else if (cmd === 'pickup') {
        const lines = [
            "Are you a magician? Because whenever I look at you, everyone else disappears!",
            "Do you have a map? I keep getting lost in your eyes!",
            "Are you a parking ticket? Because you've got FINE written all over you!",
            "Is your name Google? Because you have everything I've been searching for!",
            "Do you believe in love at first sight, or should I walk by again?",
            "Are you a camera? Because every time I look at you, I smile!",
            "If you were a vegetable, you'd be a cute-cumber!",
            "Are you WiFi? Because I'm feeling a connection!"
        ];
        content = `💘 ${lines[Math.floor(Math.random() * lines.length)]}`;
    }
    else if (cmd === 'showerthought') {
        const thoughts = [
            'If you replace "W" with "T" in "What, Where and When", you get the answer to each of them.',
            'Your future self is watching you right now through memories.',
            'The person who would proof read Hitler\'s speeches was a grammar Nazi.',
            'Saying "forward" or "back" is the only way to move your lips forward or backward.',
            'Fire is just a bunch of light having a party.',
            'Somewhere, someone is thinking about you right now.'
        ];
        content = `💭 **Shower Thought:** ${thoughts[Math.floor(Math.random() * thoughts.length)]}`;
    }

    return message.reply({ embeds: [new EmbedBuilder().setDescription(content).setColor('#2b2d31')] });
}

async function handleTextInput(message, args, cmd) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [embedHelper.info(`Please provide text. Usage: \`!${cmd} <text>\``)] });

    let content = '';
    if (cmd === 'reverse') content = text.split('').reverse().join('');
    else if (cmd === 'mock') content = text.split('').map((char, i) => i % 2 === 0 ? char.toLowerCase() : char.toUpperCase()).join('');
    else if (cmd === 'opinion') {
        const opinions = ['Amazing!', 'Great!', 'Good!', 'Okay...', 'Not great.', 'Bad.', 'Terrible!', 'The worst!'];
        content = `My opinion on "${text}": **${opinions[Math.floor(Math.random() * opinions.length)]}**`;
    }

    return message.reply({ embeds: [new EmbedBuilder().setDescription(content).setColor('#2b2d31')] });
}

async function handleMeme(message, args, cmd) {
    return message.reply({ embeds: [embedHelper.info(`🎨 **${cmd.toUpperCase()}** meme generation coming soon!`)] });
}

// --- Main Export Array ---
const commands = [];

// 1. Ship
commands.push({
    name: 'ship',
    description: 'Love Calculator',
    async executeMessage(message, args) {
        const user1 = message.mentions.users.first() || message.author;
        // const user2 = [...message.mentions.users.values()][1] || message.mentions.users.first();
        // If 1 mention: Ship Author + Mention. If 2 mentions: Ship Mention1 + Mention2

        let target1 = message.author;
        let target2 = message.mentions.users.first();

        // If two users mentioned, use them
        if (message.mentions.users.size >= 2) {
            target1 = message.mentions.users.first();
            target2 = [...message.mentions.users.values()][1];
        }

        if (!target2) {
            // If no mentions, maybe error or ship with self (weird).
            // Let's error nicely.
            return message.reply({ embeds: [embedHelper.info('Please mention at least one user to ship with. Usage: `!ship @user` or `!ship @user1 @user2`')] });
        }

        const { createCanvas, loadImage, registerFont } = require('canvas');
        const { AttachmentBuilder } = require('discord.js');

        const canvas = createCanvas(700, 250);
        const ctx = canvas.getContext('2d');

        // Background
        ctx.fillStyle = '#23272A';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Styling
        ctx.strokeStyle = '#ff3333';
        ctx.lineWidth = 10;

        // --- User 1 Avatar ---
        const avatar1 = await loadImage(target1.displayAvatarURL({ extension: 'png', size: 512 }).replace('.webp', '.png'));
        ctx.save();
        ctx.beginPath();
        ctx.arc(150, 125, 100, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar1, 50, 25, 200, 200);
        ctx.restore();
        // Border U1
        ctx.beginPath();
        ctx.arc(150, 125, 100, 0, Math.PI * 2, true);
        ctx.stroke();

        // --- User 2 Avatar ---
        const avatar2 = await loadImage(target2.displayAvatarURL({ extension: 'png', size: 512 }).replace('.webp', '.png'));
        ctx.save();
        ctx.beginPath();
        ctx.arc(550, 125, 100, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar2, 450, 25, 200, 200);
        ctx.restore();
        // Border U2
        ctx.beginPath();
        ctx.arc(550, 125, 100, 0, Math.PI * 2, true);
        ctx.stroke();

        // --- Heart & Text ---
        // Draw Heart (simplified as text or a red circle for now, or load an image if I had one. I'll draw a red heart shape)
        ctx.fillStyle = '#ff3333';
        ctx.beginPath();
        const k = 125; // y-center
        const hx = 350; // x-center
        // Simple Heart Shape
        ctx.moveTo(hx, k + 50);
        ctx.bezierCurveTo(hx - 60, k, hx - 60, k - 70, hx, k - 70);
        ctx.bezierCurveTo(hx + 60, k - 70, hx + 60, k, hx, k + 50);
        ctx.fill();

        // Text
        const percentage = Math.floor(Math.random() * 101);
        ctx.font = 'bold 40px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(`${percentage}%`, 350, 135);

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'ship.png' });

        const shipEmbed = new EmbedBuilder()
            .setTitle('❤️ Relationship Percentage')
            .setDescription(`**${target1.username}** + **${target2.username}**`)
            .setImage('attachment://ship.png')
            .setColor('#ff3333')
            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        return message.reply({ embeds: [shipEmbed], files: [attachment] });
    }
});

// 2. Reaction Game
commands.push({
    name: 'reaction',
    description: 'Reaction Speed Game',
    async executeMessage(message, args) {
        const gameEmbed = new EmbedBuilder()
            .setTitle("React to play the game! 🎮")
            .setDescription("React with the emojis below to play.")
            .setColor('#2b2d31')
            .setTimestamp();

        const response = await message.reply({ embeds: [gameEmbed] });

        const allEmojis = ['🍇', '🍒', '🍊', '🍓', '🍐', '🍍', '🍋', '🍎', '🥝', '🍌', '🥭', '🍏', '🍅', '🍆', '🥑'];
        for (let i = allEmojis.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [allEmojis[i], allEmojis[j]] = [allEmojis[j], allEmojis[i]];
        }
        const emojis = allEmojis.slice(0, 6);

        try {
            for (const emoji of emojis) {
                await response.react(emoji);
            }

            const chosenEmoji = emojis[Math.floor(Math.random() * emojis.length)];
            await response.react(chosenEmoji);

            gameEmbed.setDescription(`The bot chose ${chosenEmoji}! React with it fast!`);
            await response.edit({ embeds: [gameEmbed] });

            const filter = (reaction, user) => reaction.emoji.name === chosenEmoji && !user.bot;
            const collected = await response.awaitReactions({ filter, max: 1, time: 10000, errors: ['time'] });
            const winner = collected.first().users.cache.find(user => !user.bot);

            if (winner) {
                gameEmbed.setDescription(`🎉 <@${winner.id}> won the game!`);
            } else {
                gameEmbed.setDescription("Unable to determine the winner.");
            }
            await response.edit({ embeds: [gameEmbed] });
        } catch (e) {
            gameEmbed.setDescription("Nobody reacted in time! Game over.");
            await response.edit({ embeds: [gameEmbed] });
        }
    }
});

// 3. Truth/Dare/8ball etc.
commands.push({
    name: 'truth',
    async executeMessage(message) {
        const truths = [
            'What\'s the most embarrassing thing you\'ve done in front of a crush?',
            'What\'s a secret you\'ve never told anyone?',
            'Who was your first crush?',
            'What\'s the biggest lie you\'ve told your parents?',
            'What\'s your biggest fear?',
            'Have you ever cheated on a test?',
            'What\'s the most childish thing you still do?'
        ];
        return message.reply({ embeds: [new EmbedBuilder().setTitle('🎭 Truth').setDescription(truths[Math.floor(Math.random() * truths.length)]).setColor('#2b2d31')] });
    }
});

commands.push({
    name: 'dare',
    async executeMessage(message) {
        const dares = [
            'Do 20 pushups right now!',
            'Send a screenshot of your search history!',
            'Change your status to something embarrassing!',
            'Say something nice about everyone online!',
            'Speak in rhymes for the next 5 minutes!',
            'Do your best impression of a celebrity!',
            'Send a voice message singing a song!'
        ];
        return message.reply({ embeds: [new EmbedBuilder().setTitle('🎯 Dare').setDescription(dares[Math.floor(Math.random() * dares.length)]).setColor('#2b2d31')] });
    }
});

commands.push({
    name: '8ball',
    aliases: ['eightball'],
    async executeMessage(message) {
        const responses = [
            '🎱 Yes, definitely!', '🎱 It is certain!', '🎱 Without a doubt!',
            '🎱 Reply hazy, try again.', '🎱 Ask again later.', '🎱 Cannot predict now.',
            '🎱 Don\'t count on it.', '🎱 My reply is no.', '🎱 Outlook not so good.'
        ];
        return message.reply({ embeds: [new EmbedBuilder().setDescription(responses[Math.floor(Math.random() * responses.length)]).setColor('#2b2d31')] });
    }
});

// 4. Rate Commands (cute, intelligence, etc)
const rateCmds = ['cute', 'intelligence', 'horny', 'clown', 'waifu'];
rateCmds.forEach(cmd => {
    commands.push({
        name: cmd,
        async executeMessage(message) {
            if (cmd === 'waifu') {
                const waifus = ['S-Tier! 💖', 'A-Tier! 😊', 'B-Tier! 😄', 'C-Tier! 😅', 'D-Tier! 😬'];
                return message.reply({ embeds: [new EmbedBuilder().setDescription(`Your waifu rating is: ${waifus[Math.floor(Math.random() * waifus.length)]}`).setColor('#ff69b4')] });
            }
            const target = message.mentions.users.first() || message.author;
            const percentage = Math.floor(Math.random() * 101);
            const emoji = percentage > 70 ? '🥵' : percentage > 40 ? '😳' : '😇'; // Default horny
            let text = `is **${percentage}%** ${cmd}! ${emoji}`;
            let color = '#2b2d31';

            if (cmd === 'cute') {
                text = `is **${percentage}%** cute! ${percentage > 70 ? '🥰' : percentage > 40 ? '😊' : '😐'}`;
                color = '#ff69b4';
            }
            if (cmd === 'intelligence') {
                text = `'s intelligence is **${percentage}%**! ${percentage > 70 ? '🧠' : percentage > 40 ? '🤓' : '🙃'}`;
                color = '#00ff00';
            }
            if (cmd === 'clown') {
                text = `is **${percentage}%** a clown! ${percentage > 70 ? '🤡🤡🤡' : percentage > 40 ? '🤡🤡' : '🤡'}`;
                color = '#ff0000';
            }

            return message.reply({ embeds: [new EmbedBuilder().setDescription(`${target} ${text}`).setColor(color)] });
        }
    });
});

// 5. Bulk Generators
interactionCmds.forEach(cmd => commands.push({ name: cmd, executeMessage: (m, a) => handleInteraction(m, a, cmd) }));
reactionCmds.forEach(cmd => commands.push({ name: cmd, executeMessage: (m, a) => handleReaction(m, a, cmd) }));
simpleTextCmds.forEach(cmd => commands.push({ name: cmd, executeMessage: (m, a) => handleSimpleText(m, a, cmd) }));
textInputCmds.forEach(cmd => commands.push({ name: cmd, executeMessage: (m, a) => handleTextInput(m, a, cmd) }));
memeCmds.forEach(cmd => commands.push({ name: cmd, executeMessage: (m, a) => handleMeme(m, a, cmd) }));

module.exports = commands;
