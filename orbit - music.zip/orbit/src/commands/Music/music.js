const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embed = require('../../functions/embedHelper');
const spotify = require('../../functions/spotifyHelper');

const controlCommands = [
    { name: 'play', desc: 'Play a song', stringOption: 'query' },
    { name: 'tts', desc: 'Play TTS message', stringOption: 'text' },
    { name: 'nowplaying', desc: 'Show current song' },
    { name: 'queue', desc: 'Show music queue' },
    { name: 'history', desc: 'Show history' },
    { name: 'search', desc: 'Search for songs', stringOption: 'query' },
    { name: 'grab', desc: 'Save current song to DMs' },
    { name: 'stop', desc: 'Stop music' },
    { name: 'autoplay', desc: 'Toggle autoplay' },
    { name: 'join', desc: 'Join voice' },
    { name: 'leave', desc: 'Leave voice' },
    { name: 'forcefix', desc: 'Force fix connection' },
    { name: 'pause', desc: 'Pause song' },
    { name: 'resume', desc: 'Resume song' },
    { name: 'replay', desc: 'Replay song' },
    { name: 'shuffle', desc: 'Shuffle queue' },
    { name: 'clearqueue', desc: 'Clear queue' },
    { name: 'volume', desc: 'Adjust volume', intOption: 'amount' }
];

const adjustCommands = [
    { name: 'skip', desc: 'Skip current song' },
    { name: 'skipinto', desc: 'Skip into position', intOption: 'position' },
    { name: 'seek', desc: 'Seek to time', stringOption: 'time' },
    { name: 'remove', desc: 'Remove from queue', intOption: 'index' },
    { name: 'move', desc: 'Move in queue', intOption: 'from', intOption2: 'to' },
    { name: 'loop', desc: 'Loop song' },
    { name: 'loopqueue', desc: 'Loop queue' }
];

const configGroups = [
    { name: 'filter', desc: 'Manage filters', subs: [{ name: 'toggle', opt: 'filter' }, { name: 'reset' }, { name: 'show' }] },
    { name: 'djrole', desc: 'Manage DJ roles', subs: [{ name: 'show' }, { name: 'clear' }, { name: 'set', role: true }] },
    { name: 'source', desc: 'Manage sources', subs: [{ name: 'show' }, { name: 'set', opt: 'source' }] },
    { name: '247', desc: 'Manage 24/7', subs: [{ name: 'enable' }, { name: 'disable' }, { name: 'channel', channel: true }] },
    { name: 'djmix', desc: 'Manage DJ mix', subs: [{ name: 'show' }, { name: 'enable' }, { name: 'disable' }] }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('music')
        .setDescription('Music system controls')
        .addSubcommandGroup(group => {
            group.setName('control').setDescription('General music controls');
            controlCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    return sub;
                });
            });
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('edit').setDescription('Adjust current queue/playback');
            adjustCommands.forEach(cmd => {
                group.addSubcommand(sub => {
                    sub.setName(cmd.name).setDescription(cmd.desc);
                    if (cmd.stringOption) sub.addStringOption(o => o.setName(cmd.stringOption).setDescription('Input').setRequired(true));
                    if (cmd.intOption) sub.addIntegerOption(o => o.setName(cmd.intOption).setDescription('Value').setRequired(true));
                    if (cmd.intOption2) sub.addIntegerOption(o => o.setName(cmd.intOption2).setDescription('Target').setRequired(true));
                    return sub;
                });
            });
            return group;
        }),
    // The existing config groups would need to be moved to subcommand level OR we need more groups.
    // Since we can only have 25 total, and we have 2 groups + 5 more groups, that is 7 items.
    // But we cannot nest Groups.
    // Wait! configGroups were already being implemented as top-level commands.
    // If I want them in /music, I can either make them subcommands of a /music config group,
    // but they already have subcommands. You CANNOT have sub-sub-commands.
    // So /music filter toggle -> music (command) filter (group) toggle (subcommand).
    // This is the max depth (3 levels: cmd -> group -> sub).

    // So I can add the configGroups as groups to the SlachCommandBuilder.
    async execute(interaction) {
        const client = interaction.client;
        const channel = interaction.member.voice.channel;
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();

        if (!channel) return interaction.reply({ embeds: [embed.error('❌ You must be in a voice channel.')], ephemeral: true });

        // Helper for queue
        const queue = client.distube.getQueue(interaction.guildId);

        if (group === 'control') {
            if (sub === 'play') {
                const query = interaction.options.getString('query');
                await interaction.deferReply();
                // Check if query is text-based search (not URL) and try Spotify
                let finalQuery = query;
                const spotifyUrl = await spotify.searchTrack(query);
                if (spotifyUrl) {
                    finalQuery = spotifyUrl;
                    console.log(`[SpotifySearch] Resolved "${query}" to ${spotifyUrl}`);
                }
                try {
                    await client.distube.play(channel, finalQuery, {
                        member: interaction.member,
                        textChannel: interaction.channel
                    });
                    // Distube emits playSong/addSong events, so we can editReply or let events handle it.
                    // To avoid double messages, we can just delete the defer or say "Searching..."
                    await interaction.editReply({ embeds: [embed.info('🔎 Request received...')] });
                    setTimeout(() => interaction.deleteReply().catch(() => { }), 3000);
                } catch (e) {
                    await interaction.editReply({ embeds: [embed.error(`❌ Error: ${e.message}`)] });
                }
            } else if (sub === 'stop') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.stop();
                return interaction.reply({ embeds: [embed.success('⏹ Stopped music and left.')] });
            } else if (sub === 'pause') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.pause();
                return interaction.reply({ embeds: [embed.success('⏸ Paused.')] });
            } else if (sub === 'resume') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                queue.resume();
                return interaction.reply({ embeds: [embed.success('▶ Resumed.')] });
            } else if (sub === 'queue') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const q = queue.songs.map((song, i) => `${i === 0 ? 'Playing:' : `${i}.`} ${song.name} - \`${song.formattedDuration}\``).join('\n');
                // Truncate if too long (2000 chars)
                const trimmed = q.length > 1900 ? q.slice(0, 1900) + '...' : q;
                return interaction.reply({ embeds: [embed.info(`**Queue**\n${trimmed}`)] });
            } else if (sub === 'volume') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const vol = interaction.options.getInteger('amount');
                queue.setVolume(vol);
                return interaction.reply({ embeds: [embed.success(`🔊 Volume set to \`${vol}%\``)] });
            } else if (sub === 'nowplaying') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const song = queue.songs[0];
                return interaction.reply({ embeds: [embed.info(`🎶 Now Playing: **${song.name}**\nDuration: \`${song.formattedDuration}\``)] });
            }
        } else if (group === 'edit') {
            if (sub === 'skip') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                try {
                    await queue.skip();
                    return interaction.reply({ embeds: [embed.success('⏭ Skipped.')] });
                } catch (e) {
                    return interaction.reply({ embeds: [embed.error('❌ No more songs to skip to (or error).')] });
                }
            } else if (sub === 'loop') {
                if (!queue) return interaction.reply({ embeds: [embed.error('❌ Nothing playing.')], ephemeral: true });
                const mode = queue.repeatMode === 1 ? 0 : 1;
                queue.setRepeatMode(mode);
                return interaction.reply({ embeds: [embed.success(mode === 1 ? '🔁 Loop enabled for song.' : '➡ Loop disabled.')] });
            }
        } else {
            return interaction.reply({ embeds: [embed.warning('This Command is Work in Progress.')], ephemeral: true });
        }
    },
    async executeMessage(message, args) {
        const client = message.client;
        const channel = message.member.voice.channel;
        if (!channel) return message.reply({ embeds: [embed.error('❌ You must be in a voice channel.')] });

        const sub = args[0] ? args[0].toLowerCase() : 'help';
        const queue = client.distube.getQueue(message.guildId);

        if (sub === 'play') {
            const query = args.slice(1).join(' ');
            if (!query) return message.reply({ embeds: [embed.error('Usage: `!music play <url/name>`')] });

            // Check if query is text-based search (not URL) and try Spotify
            let finalQuery = query;
            const spotifyUrl = await spotify.searchTrack(query);
            if (spotifyUrl) {
                finalQuery = spotifyUrl;
                console.log(`[SpotifySearch] Resolved "${query}" to ${spotifyUrl}`);
            }

            try {
                await client.distube.play(channel, finalQuery, {
                    member: message.member,
                    textChannel: message.channel
                });
                return message.react('🔎');
            } catch (e) {
                return message.reply({ embeds: [embed.error(`❌ Error: ${e.message}`)] });
            }
        }

        else if (sub === 'stop' || sub === 'leave') {
            if (queue) queue.stop();
            return message.react('⏹');
        }

        else if (sub === 'skip') {
            if (queue) try { await queue.skip(); message.react('⏭'); } catch { }
        }

        else if (sub === 'queue') {
            if (!queue) return message.reply({ embeds: [embed.error('Queue empty.')] });
            const q = queue.songs.map((song, i) => `${i === 0 ? 'Playing:' : `${i}.`} ${song.name} - \`${song.formattedDuration}\``).join('\n');
            const trimmed = q.length > 1900 ? q.slice(0, 1900) + '...' : q;
            return message.reply({ embeds: [embed.info(`**Queue**\n${trimmed}`)] });
        } else {
            const helpEmbed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **music play <query>**\n› Play a song.\n\n` +
                    `» **music stop**\n› Stop playback.\n\n` +
                    `» **music skip**\n› Skip current song.\n\n` +
                    `» **music queue**\n› Show queue.\n\n` +
                    `» **music volume <amount>**\n› Set volume.\n\n` +
                    `» **music loop**\n› Toggle loop.\n\n` +
                    `» **music nowplaying**\n› Show current song.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            return message.reply({ embeds: [helpEmbed] });
        }
    }
};

// Subcommand Groups for Config (kept as required by structure, but logic handles mainly control/edit)
configGroups.forEach(g => {
    module.exports.data.addSubcommandGroup(group => {
        group.setName(g.name).setDescription(g.desc);
        g.subs.forEach(s => {
            group.addSubcommand(sub => {
                sub.setName(s.name).setDescription(s.name);
                if (s.opt) sub.addStringOption(o => o.setName(s.opt).setDescription('Value').setRequired(true));
                if (s.role) sub.addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true));
                if (s.channel) sub.addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true));
                return sub;
            });
        });
        return group;
    });
});
