const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const embedHelper = require('../../functions/embedHelper');

const dataPath = path.join(__dirname, '../../data/vcrole.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('vcrole')
        .setDescription('Manage VC roles')
        .addSubcommand(sub => sub.setName('set').setDescription('Set role to give on VC join').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)).addStringOption(opt => opt.setName('type').setDescription('Type').setRequired(false).addChoices({ name: 'Human', value: 'human' }, { name: 'Bot', value: 'bot' })))
        .addSubcommand(sub => sub.setName('clear').setDescription('Clear VC role config'))
        .addSubcommand(sub => sub.setName('show').setDescription('Show VC role config')),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) return interaction.reply({ embeds: [embedHelper.error('❌ No access')] });
        await handleVcRole(interaction);
    },

    async executeMessage(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        await handleVcRole(message, args);
    }
};

async function handleVcRole(context, args) {
    const isMsg = !context.commandName;
    const sub = isMsg ? (args[0] || 'help') : context.options.getSubcommand();
    const guildId = context.guild.id;
    const data = getData();
    if (!data[guildId]) data[guildId] = { human: null, bot: null };

    if (sub === 'set') {
        let role, type;
        if (isMsg) {
            type = args[1]?.toLowerCase() === 'bot' ? 'bot' : 'human';
            const roleId = context.mentions.roles.first()?.id || args[args[1] === 'bot' || args[1] === 'human' ? 2 : 1];
            role = context.guild.roles.cache.get(roleId);
        } else {
            role = context.options.getRole('role');
            type = context.options.getString('type') || 'human';
        }

        if (!role) {
            const msg = { embeds: [embedHelper.error(isMsg ? 'Usage: `!vcrole set [human/bot] @role`' : 'Role required.')], flags: 64 };
            return context.reply(msg);
        }

        data[guildId][type] = role.id;
        setData(data);
        const msg = { embeds: [embedHelper.success(`✅ Set **${type}** VC role to **${role.name}**.`)] };
        return isMsg ? context.reply(msg) : context.reply(msg);
    }

    if (sub === 'clear') {
        data[guildId] = { human: null, bot: null };
        setData(data);
        const msg = { embeds: [embedHelper.success(`✅ Cleared VC role configuration.`)] };
        return isMsg ? context.reply(msg) : context.reply(msg);
    }

    if (sub === 'show') {
        const human = data[guildId].human ? `<@&${data[guildId].human}>` : 'None';
        const bot = data[guildId].bot ? `<@&${data[guildId].bot}>` : 'None';
        const embed = new EmbedBuilder().setTitle('VC Role Config')
            .addFields({ name: 'Human Role', value: human, inline: true }, { name: 'Bot Role', value: bot, inline: true })
            .setColor('#2b2d31');
        return isMsg ? context.reply({ embeds: [embed] }) : context.reply({ embeds: [embed] });
    }

    // Help for message
    if (isMsg) {
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **vcrole set [human/bot] <role>**\n› Set the role to assign when a user joins VC.\n\n` +
                `» **vcrole clear**\n› Clear the VC role configuration.\n\n` +
                `» **vcrole show**\n› Show the current VC role configuration.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${context.author.username}`, iconURL: context.author.displayAvatarURL() });
        context.reply({ embeds: [embed] });
    }
}
