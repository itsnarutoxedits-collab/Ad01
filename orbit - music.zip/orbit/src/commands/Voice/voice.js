const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('voice')
        .setDescription('Voice management commands')
        .addSubcommand(sub => sub.setName('mute').setDescription('Mute a user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('unmute').setDescription('Unmute a user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('deafen').setDescription('Deafen a user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('undeafen').setDescription('Undeafen a user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('muteall').setDescription('Mute all users in channel'))
        .addSubcommand(sub => sub.setName('unmuteall').setDescription('Unmute all users in channel'))
        .addSubcommand(sub => sub.setName('deafenall').setDescription('Deafen all users in channel'))
        .addSubcommand(sub => sub.setName('undeafenall').setDescription('Undeafen all users in channel'))
        .addSubcommand(sub => sub.setName('kick').setDescription('Kick a user from voice').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('kickall').setDescription('Kick all users from channel'))
        .addSubcommand(sub => sub.setName('move').setDescription('Move a user').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('moveall').setDescription('Move all users').addChannelOption(opt => opt.setName('channel').setDescription('Target channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('pull').setDescription('Pull a user to your channel').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('push').setDescription('Push a user to another channel').addUserOption(opt => opt.setName('target').setDescription('The user').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List users in channel')),
    aliases: ['vc'],

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        await handleSubcommand(interaction, sub);
    },

    async executeMessage(message, args) {
        const sub = args[0] ? args[0].toLowerCase() : 'help';
        const validSubs = ['mute', 'unmute', 'deafen', 'undeafen', 'muteall', 'unmuteall', 'deafenall', 'undeafenall', 'kick', 'kickall', 'move', 'moveall', 'pull', 'push', 'list'];

        if (sub === 'help' || !validSubs.includes(sub)) {
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **voice mute <user>**\n› Mute a user in your voice channel.\n\n` +
                    `» **voice unmute <user>**\n› Unmute a user in your voice channel.\n\n` +
                    `» **voice deafen <user>**\n› Deafen a user in your voice channel.\n\n` +
                    `» **voice undeafen <user>**\n› Undeafen a user in your voice channel.\n\n` +
                    `» **voice kick <user>**\n› Kick a user from the voice channel.\n\n` +
                    `» **voice move <user> <channel>**\n› Move a user to another voice channel.\n\n` +
                    `» **voice pull <user>**\n› Pull a user to your voice channel.\n\n` +
                    `» **voice push <user> <channel>**\n› Push a user to another voice channel.\n\n` +
                    `» **voice list**\n› List all users in your voice channel.\n\n` +
                    `» **voice muteall**\n› Mute all users in your voice channel.\n\n` +
                    `» **voice unmuteall**\n› Unmute all users in your voice channel.\n\n` +
                    `» **voice deafenall**\n› Deafen all users in your voice channel.\n\n` +
                    `» **voice undeafenall**\n› Undeafen all users in your voice channel.\n\n` +
                    `» **voice kickall**\n› Kick all users from your voice channel.\n\n` +
                    `» **voice moveall <channel>**\n› Move all users to another voice channel.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            return message.reply({ embeds: [embed] });
        }

        // Pass args shifted by 1 so 'voice mute @user' -> args for handler is '@user'
        // Actually handleSubcommand expects context and specific options extraction, 
        // implies we might need a unified extractor or just pass the original context and let helper handle it.
        // But since we have specific logic per command, let's adapt.

        await handleSubcommand(message, sub, args.slice(1));
    }
};

async function handleSubcommand(context, sub, msgArgs) {
    const member = context.member;
    const isMsg = !context.commandName;

    // Helper to get options
    const getUser = (name) => {
        if (!isMsg) return context.options.getMember(name);
        return context.mentions.members.first();
    };

    const getChannel = (name) => {
        if (!isMsg) return context.options.getChannel(name);
        const id = msgArgs && msgArgs[1]?.replace(/[<#>]/g, ''); // For moveall/push
        return context.guild.channels.cache.get(id);
    };

    // Permission Checks (Simplified for brevity, ideally specific per action)
    const perms = {
        mute: PermissionFlagsBits.MuteMembers,
        unmute: PermissionFlagsBits.MuteMembers,
        deafen: PermissionFlagsBits.DeafenMembers,
        undeafen: PermissionFlagsBits.DeafenMembers,
        muteall: PermissionFlagsBits.MuteMembers,
        unmuteall: PermissionFlagsBits.MuteMembers,
        deafenall: PermissionFlagsBits.DeafenMembers,
        undeafenall: PermissionFlagsBits.DeafenMembers,
        kick: PermissionFlagsBits.MoveMembers,
        kickall: PermissionFlagsBits.MoveMembers,
        move: PermissionFlagsBits.MoveMembers,
        moveall: PermissionFlagsBits.MoveMembers,
        pull: PermissionFlagsBits.MoveMembers,
        push: PermissionFlagsBits.MoveMembers,
        list: PermissionFlagsBits.ViewChannel
    };

    if (perms[sub] && !member.permissions.has(perms[sub])) {
        const msg = { embeds: [embedHelper.error('❌ No access')] };
        return isMsg ? context.reply(msg) : context.reply(msg);
    }

    const channel = member.voice.channel;

    // Single User Actions
    if (['mute', 'unmute', 'deafen', 'undeafen', 'kick', 'move', 'pull', 'push'].includes(sub)) {
        const target = getUser('target');
        if (!target) {
            const msg = { embeds: [embedHelper.error('Please specify a user.')], flags: 64 };
            return context.reply(msg);
        }
        if (!target.voice.channel) {
            const msg = { embeds: [embedHelper.error('User not in VC.')], flags: 64 };
            return context.reply(msg);
        }

        try {
            if (sub === 'mute') await target.voice.setMute(true);
            if (sub === 'unmute') await target.voice.setMute(false);
            if (sub === 'deafen') await target.voice.setDeaf(true);
            if (sub === 'undeafen') await target.voice.setDeaf(false);
            if (sub === 'kick') await target.voice.disconnect();
            if (sub === 'move') {
                const ch = getChannel('channel');
                if (!ch) {
                    const msg = { embeds: [embedHelper.error('Please specify a channel.')], flags: 64 };
                    return context.reply(msg);
                }
                await target.voice.setChannel(ch);
            }
            if (sub === 'pull') {
                if (!channel) {
                    const msg = { embeds: [embedHelper.error('You are not in VC.')], flags: 64 };
                    return context.reply(msg);
                }
                await target.voice.setChannel(channel);
            }
            if (sub === 'push') {
                const ch = getChannel('channel');
                if (!ch) {
                    const msg = { embeds: [embedHelper.error('Please specify a channel.')], flags: 64 };
                    return context.reply(msg);
                }
                await target.voice.setChannel(ch);
            }

            const msg = { embeds: [embedHelper.success(`✅ Action **${sub}** applied to **${target.user.tag}**.`)] };
            return isMsg ? context.reply(msg) : context.reply(msg);
        } catch (e) {
            console.error(e);
            return context.reply({ embeds: [embedHelper.error('An error occurred while executing the command.')], flags: 64 });
        }
    }

    // All Users Actions
    if (['muteall', 'unmuteall', 'deafenall', 'undeafenall', 'kickall', 'moveall'].includes(sub)) {
        if (!channel) return isMsg ? context.reply({ embeds: [embedHelper.error('You are not in a voice channel.')] }) : context.reply({ embeds: [embedHelper.error('You are not in a voice channel.')] });

        let count = 0;
        const targets = channel.members.filter(m => m.id !== member.id && !m.user.bot);

        if (sub === 'moveall') {
            const ch = getChannel('channel');
            if (!ch) {
                const msg = { embeds: [embedHelper.error('Please specify a channel.')], flags: 64 };
                return context.reply(msg);
            }
            for (const [id, m] of targets) { try { await m.voice.setChannel(ch); count++; } catch { } }
        } else {
            for (const [id, m] of targets) {
                try {
                    if (sub === 'muteall') await m.voice.setMute(true);
                    if (sub === 'unmuteall') await m.voice.setMute(false);
                    if (sub === 'deafenall') await m.voice.setDeaf(true);
                    if (sub === 'undeafenall') await m.voice.setDeaf(false);
                    if (sub === 'kickall') await m.voice.disconnect();
                    count++;
                } catch { }
            }
        }
        const msg = { embeds: [embedHelper.success(`✅ Action **${sub}** applied to ${count} members.`)] };
        return isMsg ? context.reply(msg) : context.reply(msg);
    }

    if (sub === 'list') {
        if (!channel) return isMsg ? context.reply({ embeds: [embedHelper.error('You are not in a voice channel.')] }) : context.reply({ embeds: [embedHelper.error('You are not in a voice channel.')] });
        const list = channel.members.map((m, i) => `${i + 1}. ${m.user.tag}`).join('\n');
        const embed = new EmbedBuilder().setTitle(`Members in ${channel.name}`).setDescription(list || 'Empty').setColor('#2b2d31');
        return isMsg ? context.reply({ embeds: [embed] }) : context.reply({ embeds: [embed] });
    }
}
