const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildBanRemove,
    async execute(ban) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[ban.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.moderation || guildConfig.channels?.member;
            if (!logChannel) return;

            const channel = ban.guild.channels.cache.get(logChannel);
            if (!channel) return;

            let executor = null;

            try {
                const auditLogs = await ban.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanRemove,
                    limit: 1
                });
                const unbanLog = auditLogs.entries.first();
                if (unbanLog && unbanLog.target.id === ban.user.id) {
                    executor = unbanLog.executor;
                }
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setTitle('✅ Member Unbanned')
                .setColor('#00ff00')
                .setThumbnail(ban.user.displayAvatarURL())
                .addFields(
                    { name: 'User', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                    { name: 'Unbanned By', value: executor ? `${executor.tag}` : 'Unknown', inline: true }
                )
                .setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (guildBanRemove):', error);
        }
    }
};
