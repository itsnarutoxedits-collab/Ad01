const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberRemove,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.member || guildConfig.channels?.server;
            if (!logChannel) return;

            const channel = member.guild.channels.cache.get(logChannel);
            if (!channel) return;

            let kickedBy = null;
            let wasKicked = false;

            try {
                const auditLogs = await member.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberKick,
                    limit: 1
                });
                const kickLog = auditLogs.entries.first();
                if (kickLog && kickLog.target.id === member.user.id && (Date.now() - kickLog.createdTimestamp) < 5000) {
                    kickedBy = kickLog.executor;
                    wasKicked = true;
                }
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setTitle(wasKicked ? '👢 Member Kicked' : '📤 Member Left')
                .setColor(wasKicked ? '#ff6600' : '#ff0000')
                .setThumbnail(member.user.displayAvatarURL())
                .addFields(
                    { name: 'User', value: `${member.user.tag} (${member.user.id})`, inline: true },
                    { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true }
                );

            if (wasKicked && kickedBy) {
                embed.addFields({ name: 'Kicked By', value: `${kickedBy.tag}` });
            }

            embed.addFields({ name: 'Joined At', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown' });
            embed.setTimestamp();

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (guildMemberRemove):', error);
        }
    }
};
