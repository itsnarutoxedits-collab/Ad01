const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/voicetime.json');

function getData() {
    try {
        if (!fs.existsSync(dataPath)) return {};
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { return {}; }
}

function setData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        if (newState.member.user.bot) return;

        const userId = newState.member.id;
        const guildId = newState.guild.id;
        const now = Date.now();
        const client = newState.client;

        // Ensure global map exists
        if (!client.voiceJoinTimes) client.voiceJoinTimes = new Map();
        const joinTimes = client.voiceJoinTimes;

        const data = getData();
        if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, blacklist: [] };

        const isBlacklisted = (channelId) => data[guildId].blacklist?.includes(channelId);

        // Ignore updates that aren't channel changes (e.g. mute/deafen toggle shouldn't reset timer)
        if (oldState.channelId === newState.channelId) return;

        // HANDLE LEAVE or MOVE (End session)
        if (oldState.channelId && joinTimes.has(userId)) {
            const startTime = joinTimes.get(userId);
            const durationMs = now - startTime;
            const durationMins = Math.floor(durationMs / 60000);

            if (durationMins > 0) {
                if (!data[guildId].users[userId]) data[guildId].users[userId] = { minutes: 0 };
                data[guildId].users[userId].minutes = (data[guildId].users[userId].minutes || 0) + durationMins;

                // CHECK ROLE REWARDS
                const rewards = data[guildId].roleRewards || {};
                const totalMins = data[guildId].users[userId].minutes;

                for (const [minStr, roleId] of Object.entries(rewards)) {
                    const reqMins = parseInt(minStr);
                    if (totalMins >= reqMins) {
                        const role = newState.guild.roles.cache.get(roleId);
                        // Only add if user doesn't have it and role is manageable
                        if (role && !newState.member.roles.cache.has(roleId)) {
                            try {
                                await newState.member.roles.add(role);
                            } catch (e) {
                                // Silent fail usually preferred for background tasks, or log
                                // console.error(`Failed to give reward role ${roleId}`, e);
                            }
                        }
                    }
                }

                // Save data
                setData(data);
            }
            joinTimes.delete(userId);
        }

        // HANDLE JOIN or MOVE (Start session)
        if (newState.channelId) {
            if (isBlacklisted(newState.channelId)) return;
            joinTimes.set(userId, now);
        }
    }
};
