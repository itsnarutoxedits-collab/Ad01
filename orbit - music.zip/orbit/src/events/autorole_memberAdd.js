const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {
            const dataPath = path.join(__dirname, '../data/autorole.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[member.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            // Check if member is a bot
            const isBot = member.user.bot;
            const rolesToAdd = isBot ? (guildConfig.botRoles || []) : (guildConfig.humanRoles || []);

            if (rolesToAdd.length === 0) return;

            // Filter roles that exist in the guild
            const validRoles = rolesToAdd.filter(roleId => member.guild.roles.cache.has(roleId));

            if (validRoles.length > 0) {
                await member.roles.add(validRoles).catch(err => {
                    console.error('Failed to add autorole:', err);
                });
            }
        } catch (error) {
            console.error('Autorole error (guildMemberAdd):', error);
        }
    }
};
