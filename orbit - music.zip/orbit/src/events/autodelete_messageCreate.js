const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        try {
            const dataPath = path.join(__dirname, '../data/autodelete.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[message.guild.id];

            if (!guildConfig || !guildConfig.channels) return;

            const channelId = message.channel.id;
            const timeStr = guildConfig.channels[channelId];
            
            if (!timeStr) return;

            // Check whitelist
            const whitelist = guildConfig.whitelist || [];
            const isUserWhitelisted = whitelist.includes(message.author.id);
            const hasWhitelistedRole = message.member.roles.cache.some(role => whitelist.includes(role.id));
            
            if (isUserWhitelisted || hasWhitelistedRole) return;

            // Parse time string (e.g., "10s", "1m", "2h", "1d")
            const timeMatch = timeStr.match(/^(\d+)([smhd])$/);
            if (!timeMatch) return;

            const value = parseInt(timeMatch[1]);
            const unit = timeMatch[2];
            let milliseconds = 0;

            switch(unit) {
                case 's': milliseconds = value * 1000; break;
                case 'm': milliseconds = value * 60 * 1000; break;
                case 'h': milliseconds = value * 60 * 60 * 1000; break;
                case 'd': milliseconds = value * 24 * 60 * 60 * 1000; break;
            }

            if (milliseconds > 0) {
                setTimeout(() => {
                    message.delete().catch(() => {});
                }, milliseconds);
            }
        } catch (error) {
            console.error('Autodelete error:', error);
        }
    }
};
