const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'antinuke.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
} catch (e) {
    store = {};
}

// In-memory heat map: { guildId: { userId: { heat: number, last: timestamp } } }
const heatMap = {};

const DEFAULT_CONFIG = {
    enabled: false,
    loggingChannel: null,
    // Whitelist is now an object: { userId: { ban: true, kick: false, ... } }
    // Legacy support: if it's an array, we migrate on read
    whitelist: {},
    filters: {},
    minuteLimit: 10,
    hourLimit: 50,
    thresholdHeat: 100,
    heatPerAction: 10,
    decayIntervalSec: 60,
    decayAmount: 1,
    zplus: false,
    panicMode: false
};

// Initialize default filter set
const DEFAULT_FILTERS = {
    ban: false,
    kick: false,
    prune: false,
    memberUpdate: false,
    roleCreate: false,
    roleDelete: false,
    roleUpdate: false,
    channelCreate: false,
    channelDelete: false,
    channelUpdate: false,
    webhookCreate: false,
    webhookDelete: false,
    webhookUpdate: false,
    botAdd: false,
    guildUpdate: false,
    mentionSpam: false
};

// Default whitelist permissions (all true for legacy full bypass)
const ALL_PERMISSIONS = Object.keys(DEFAULT_FILTERS).reduce((acc, key) => {
    acc[key] = true;
    return acc;
}, {});

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function getConfig(guildId) {
    if (!store[guildId]) store[guildId] = Object.assign({}, DEFAULT_CONFIG);

    // Ensure filters exist
    if (!store[guildId].filters || Object.keys(store[guildId].filters).length === 0) {
        store[guildId].filters = Object.assign({}, DEFAULT_FILTERS);
        saveStore();
    }

    // Migrate legacy whitelist (Array -> Object)
    if (Array.isArray(store[guildId].whitelist)) {
        const oldArray = store[guildId].whitelist;
        store[guildId].whitelist = {};
        oldArray.forEach(id => {
            store[guildId].whitelist[id] = { ...ALL_PERMISSIONS };
        });
        saveStore();
    }

    // Ensure whitelist is an object
    if (!store[guildId].whitelist) {
        store[guildId].whitelist = {};
        saveStore();
    }

    return store[guildId];
}

function setConfig(guildId, partial) {
    const cfg = getConfig(guildId);
    store[guildId] = Object.assign({}, cfg, partial);
    saveStore();
    return store[guildId];
}

/**
 * Update whitelist permissions for a user
 * @param {string} guildId 
 * @param {string} userId 
 * @param {Object} permissions Partial permissions object { ban: true, ... }
 */
function updateWhitelist(guildId, userId, permissions) {
    const cfg = getConfig(guildId);
    if (!cfg.whitelist[userId]) {
        cfg.whitelist[userId] = {}; // Start empty
    }

    // Merge permissions
    cfg.whitelist[userId] = { ...cfg.whitelist[userId], ...permissions };

    // Cleanup if all false (optional, but keeps json clean)? No, keep user entry to show they are "in" the system
    saveStore();
    return cfg.whitelist[userId];
}

function removeFromWhitelist(guildId, userId) {
    const cfg = getConfig(guildId);
    if (cfg.whitelist && cfg.whitelist[userId]) {
        delete cfg.whitelist[userId];
        saveStore();
    }
}

function getWhitelist(guildId, userId) {
    const cfg = getConfig(guildId);
    return cfg.whitelist[userId] || null;
}

/**
 * Check if a user bypasses a specific filter
 * @param {string} guildId 
 * @param {string} userId 
 * @param {string} action The filter name e.g. 'ban', 'channelCreate'
 * @returns {boolean} True if whitelisted (bypass), False otherwise
 */
function checkWhitelist(guildId, userId, action) {
    const cfg = getConfig(guildId);
    // Extra owners and Owner always bypass (handled in commands, but good to have here if needed)
    // but usually this function is for "whitelist" specific checks.

    if (!cfg.whitelist || !cfg.whitelist[userId]) return false;

    const perms = cfg.whitelist[userId];
    // If perms[action] is true, they are allowed to do it (bypass antinuke)
    return !!perms[action];
}

function toggleFilter(guildId, filterName) {
    const cfg = getConfig(guildId);
    if (!cfg.filters) cfg.filters = Object.assign({}, DEFAULT_FILTERS);
    cfg.filters[filterName] = !cfg.filters[filterName];
    saveStore();
    return cfg.filters[filterName];
}

function isFilterEnabled(guildId, filterName) {
    const cfg = getConfig(guildId);
    if (!cfg.filters) return false;
    return !!cfg.filters[filterName];
}

function addHeat(guildId, userId, amount) {
    if (!heatMap[guildId]) heatMap[guildId] = {};
    if (!heatMap[guildId][userId]) heatMap[guildId][userId] = { heat: 0, last: Date.now() };

    // Apply decay since last
    const now = Date.now();
    const entry = heatMap[guildId][userId];
    const cfg = getConfig(guildId);
    const elapsedSec = Math.floor((now - entry.last) / 1000);
    if (elapsedSec >= cfg.decayIntervalSec) {
        const steps = Math.floor(elapsedSec / cfg.decayIntervalSec);
        const decay = steps * cfg.decayAmount;
        entry.heat = Math.max(0, entry.heat - decay);
    }

    entry.heat += amount;
    entry.last = now;
    return entry.heat;
}

function getHeat(guildId, userId) {
    if (!heatMap[guildId] || !heatMap[guildId][userId]) return 0;
    // apply decay on read
    const entry = heatMap[guildId][userId];
    const now = Date.now();
    const cfg = getConfig(guildId);
    const elapsedSec = Math.floor((now - entry.last) / 1000);
    if (elapsedSec >= cfg.decayIntervalSec) {
        const steps = Math.floor(elapsedSec / cfg.decayIntervalSec);
        const decay = steps * cfg.decayAmount;
        entry.heat = Math.max(0, entry.heat - decay);
        entry.last = now;
    }
    return entry.heat;
}

module.exports = {
    getConfig,
    setConfig,
    updateWhitelist,
    removeFromWhitelist,
    getWhitelist,
    checkWhitelist,
    addHeat,
    getHeat,
    toggleFilter,
    isFilterEnabled,
    DEFAULT_CONFIG,
    DEFAULT_FILTERS,
    ALL_PERMISSIONS
};

