const { request } = require('undici');

let spotifyToken = null;
let tokenExpiration = 0;

async function getAccessToken() {
    if (spotifyToken && Date.now() < tokenExpiration) {
        return spotifyToken;
    }

    const clientId = process.env.SPOTIFY_CLIENT_ID;
    const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
        console.warn('Spotify Search: Missing Client ID or Secret in .env');
        return null;
    }

    try {
        const response = await request('https://accounts.spotify.com/api/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64')
            },
            body: 'grant_type=client_credentials'
        });

        const data = await response.body.json();
        if (data.access_token) {
            spotifyToken = data.access_token;
            tokenExpiration = Date.now() + (data.expires_in * 1000) - 60000; // Buffer 60s
            return spotifyToken;
        }
    } catch (e) {
        console.error('Spotify Token Error:', e);
    }
    return null;
}

/**
 * Searches for a track on Spotify and returns the URL of the first result.
 * @param {string} query 
 * @returns {Promise<string|null>} Spotify URL or null
 */
async function searchTrack(query) {
    if (!query) return null;
    // If it's already a URL, ignore
    if (query.startsWith('http://') || query.startsWith('https://')) return null;

    const token = await getAccessToken();
    if (!token) return null;

    try {
        const url = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`;
        const response = await request(url, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.body.json();
        if (data.tracks && data.tracks.items.length > 0) {
            return data.tracks.items[0].external_urls.spotify;
        }
    } catch (e) {
        console.error('Spotify Search Error:', e);
    }
    return null;
}

module.exports = { searchTrack };
