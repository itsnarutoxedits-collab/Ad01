const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'embeds.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let data = {};
try {
    data = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
} catch (e) {
    data = {};
}

function saveData() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

function getGuildData(guildId) {
    if (!data[guildId]) data[guildId] = { embeds: {} };
    return data[guildId];
}

function createEmbed(guildId, name) {
    const gd = getGuildData(guildId);
    if (gd.embeds[name]) return false; // Already exists

    gd.embeds[name] = {
        title: 'New Embed',
        description: 'Edit this description',
        color: '#5865F2',
        fields: [],
        footer: { text: '' },
        author: { name: '' },
        timestamp: false,
        lastEdited: Date.now()
    };
    saveData();
    return gd.embeds[name];
}

function getEmbed(guildId, name) {
    const gd = getGuildData(guildId);
    return gd.embeds[name];
}

function deleteEmbed(guildId, name) {
    const gd = getGuildData(guildId);
    if (!gd.embeds[name]) return false;
    delete gd.embeds[name];
    saveData();
    return true;
}

function updateEmbed(guildId, name, updates) {
    const gd = getGuildData(guildId);
    if (!gd.embeds[name]) return false;

    gd.embeds[name] = { ...gd.embeds[name], ...updates, lastEdited: Date.now() };
    saveData();
    return gd.embeds[name];
}

function renameEmbed(guildId, oldName, newName) {
    const gd = getGuildData(guildId);
    if (!gd.embeds[oldName] || gd.embeds[newName]) return false;

    gd.embeds[newName] = gd.embeds[oldName];
    delete gd.embeds[oldName];
    saveData();
    return true;
}

function getAllEmbeds(guildId) {
    return Object.keys(getGuildData(guildId).embeds || {});
}

module.exports = {
    createEmbed,
    getEmbed,
    deleteEmbed,
    updateEmbed,
    renameEmbed,
    getAllEmbeds
};
