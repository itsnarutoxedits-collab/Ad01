const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const statsManager = require('./statsManager');

const DATA_PATH = path.join(__dirname, '..', 'data', 'liveleaderboard.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify([]), 'utf8');
}

ensureDataFile();

let configs = [];
try {
    configs = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
} catch (e) {
    configs = [];
}

function saveConfigs() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(configs, null, 2));
}

function createLeaderboard(guildId, channelId, messageId, type) {
    configs.push({
        guildId,
        channelId,
        messageId,
        type,
        lastUpdated: Date.now()
    });
    saveConfigs();
}

function deleteLeaderboard(guildId, type) {
    const idx = configs.findIndex(c => c.guildId === guildId && (type === 'all' || c.type === type));
    if (idx > -1) {
        if (type === 'all') {
            configs = configs.filter(c => c.guildId !== guildId);
        } else {
            configs.splice(idx, 1);
        }
        saveConfigs();
        return true;
    }
    return false;
}

function getLeaderboards(guildId) {
    return configs.filter(c => c.guildId === guildId);
}

/* --- UPDATE LOOP --- */

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000) % 60;
    const minutes = Math.floor(ms / (1000 * 60)) % 60;
    const hours = Math.floor(ms / (1000 * 60 * 60));
    return `${hours}h ${minutes}m ${seconds}s`;
}

async function updateLeaderboards(client) {
    for (const config of configs) {
        try {
            const guild = client.guilds.cache.get(config.guildId);
            if (!guild) continue;

            const channel = guild.channels.cache.get(config.channelId);
            if (!channel) continue;

            const message = await channel.messages.fetch(config.messageId).catch(() => null);
            if (!message) {
                // Message deleted, remove config? 
                // For safety, maybe just skip or mark invalid. But standard behavior is to stop tracking.
                // deleteLeaderboard(config.guildId, config.type); 
                continue;
            }

            const topUsers = statsManager.getTopUsers(config.guildId, config.type, 10);

            let desc = 'No data yet.';
            if (topUsers.length > 0) {
                desc = topUsers.map((u, i) => {
                    const val = (config.type.includes('voice')) ? formatDuration(u.value) : u.value.toLocaleString();
                    return `${i + 1}. <@${u.id}> | **${val}**`;
                }).join('\n');
            }

            const embed = new EmbedBuilder()
                .setTitle(`Live Leaderboard: ${config.type}`)
                .setDescription(desc)
                .setColor('#2b2d31')
                .setFooter({ text: 'Last updated' })
                .setTimestamp();

            await message.edit({ embeds: [embed] });
            config.lastUpdated = Date.now();

        } catch (err) {
            if (err.code === 50005) {
                console.warn(`[Leaderboard] Cannot edit message ${config.messageId} (Not author). Removing config.`);
                deleteLeaderboard(config.guildId, config.type);
            } else if (err.code === 10008) {
                console.warn(`[Leaderboard] Message ${config.messageId} not found. Removing config.`);
                deleteLeaderboard(config.guildId, config.type);
            } else {
                console.error(`Failed to update leaderboard ${config.guildId}/${config.type}`, err);
            }
        }
    }
}

// Start loop
let interval = null;
function startLoop(client) {
    if (interval) clearInterval(interval);
    // Update immediately on boot
    updateLeaderboards(client);
    // Then every 60s
    interval = setInterval(() => updateLeaderboards(client), 60 * 1000);
}

module.exports = {
    createLeaderboard,
    deleteLeaderboard,
    getLeaderboards,
    startLoop
};
