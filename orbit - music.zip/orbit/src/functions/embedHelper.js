const { EmbedBuilder } = require('discord.js');

/**
 * Create standardized embeds for bot responses
 */
module.exports = {
    // Success embed (green)
    success(description) {
        return new EmbedBuilder()
            .setDescription(description)
            .setColor('#43b581'); // Green
    },

    // Error embed (red)
    error(description) {
        return new EmbedBuilder()
            .setDescription(description)
            .setColor('#f04747'); // Red
    },

    // Info embed (blue)
    info(description) {
        return new EmbedBuilder()
            .setDescription(description)
            .setColor('#5865f2'); // Blue
    },

    // Warning embed (yellow)
    warning(description) {
        return new EmbedBuilder()
            .setDescription(description)
            .setColor('#faa61a'); // Yellow
    },

    // Default embed (dark gray)
    default(description) {
        return new EmbedBuilder()
            .setDescription(description)
            .setColor('#2b2d31'); // Dark gray
    }
};
