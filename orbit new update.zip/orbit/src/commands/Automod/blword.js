const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const automod = require('../../functions/automodManager');
const permit = require('../../functions/permitManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('blword')
        .setDescription('Automod: Configure blacklisted words')
        .addSubcommand(sub => sub.setName('add').setDescription('Add one or more words to the blacklist').addStringOption(opt => opt.setName('words').setDescription('The words to blacklist (comma separated)').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove one or more words from the blacklist').addStringOption(opt => opt.setName('words').setDescription('The words to remove (comma separated)').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset the entire blacklist for this server'))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all blacklisted words'))
        .addSubcommand(sub => sub.setName('export').setDescription('Export the blacklist as a JSON file for this server'))
        .addSubcommandGroup(group =>
            group.setName('punish')
                .setDescription('Manage punishments for using blacklisted words')
                .addSubcommand(sub => sub.setName('ban').setDescription('Punish with ban'))
                .addSubcommand(sub => sub.setName('mute').setDescription('Punish with mute'))
                .addSubcommand(sub => sub.setName('kick').setDescription('Punish with kick'))
        )
        .addSubcommandGroup(group =>
            group.setName('wlchannel')
                .setDescription('Manage the channel whitelist')
                .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to whitelist').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from whitelist').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
                .addSubcommand(sub => sub.setName('reset').setDescription('Reset whitelisted channels'))
                .addSubcommand(sub => sub.setName('show').setDescription('Show whitelisted channels'))
        )
        .addSubcommandGroup(group =>
            group.setName('wlrole')
                .setDescription('Manage the role whitelist')
                .addSubcommand(sub => sub.setName('add').setDescription('Add a role to whitelist').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
                .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role from whitelist').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
                .addSubcommand(sub => sub.setName('reset').setDescription('Reset whitelisted roles'))
                .addSubcommand(sub => sub.setName('show').setDescription('Show whitelisted roles'))
        ),

    async execute(interaction) {
        const guildId = interaction.guild.id;
        const group = interaction.options.getSubcommandGroup(false);
        const subcommand = interaction.options.getSubcommand();

        // Permission check
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const data = automod.getGuildData(guildId);

        if (subcommand === 'add') {
            const words = interaction.options.getString('words').split(',').map(s => s.trim().toLowerCase()).filter(s => s.length > 0);
            const added = [];
            words.forEach(word => {
                if (!data.blacklist.words.includes(word)) {
                    data.blacklist.words.push(word);
                    added.push(word);
                }
            });
            automod.setConfig(guildId, { blacklist: data.blacklist });
            return interaction.reply({ content: added.length > 0 ? `Successfully added **${added.length}** word(s) to the blacklist.` : 'No new words were added.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'remove') {
            const words = interaction.options.getString('words').split(',').map(s => s.trim().toLowerCase());
            const initialCount = data.blacklist.words.length;
            data.blacklist.words = data.blacklist.words.filter(w => !words.includes(w));
            const removedCount = initialCount - data.blacklist.words.length;
            automod.setConfig(guildId, { blacklist: data.blacklist });
            return interaction.reply({ content: `Successfully removed **${removedCount}** word(s) from the blacklist.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'reset') {
            data.blacklist.words = [];
            automod.setConfig(guildId, { blacklist: data.blacklist });
            return interaction.reply({ content: 'Successfully reset the word blacklist.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'show') {
            const embed = new EmbedBuilder()
                .setTitle('Blacklisted Words')
                .setDescription(data.blacklist.words.length > 0 ? data.blacklist.words.map(w => `\`${w}\``).join(', ') : 'No words blacklisted.')
                .setColor('#2b2d31')
                .setFooter({ text: `Orbit™ Automod System`, iconURL: interaction.client.user.displayAvatarURL() });
            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'export') {
            try {
                const jsonBuffer = Buffer.from(JSON.stringify(data.blacklist, null, 2));
                // Send publicly so prefix usage or slash both result in an accessible file
                return interaction.reply({ files: [{ attachment: jsonBuffer, name: `blacklist_${guildId}.json` }] });
            } catch (err) {
                console.error('Failed to export blacklist:', err);
                return interaction.reply({ content: 'Failed to export blacklist.' });
            }
        }

        if (group === 'punish') {
            data.blacklist.punishment = subcommand;
            automod.setConfig(guildId, { blacklist: data.blacklist });
            return interaction.reply({ content: `Successfully set blacklist punishment to **${subcommand}**.`, flags: MessageFlags.Ephemeral });
        }

        if (group === 'wlchannel') {
            if (subcommand === 'add') {
                const channel = interaction.options.getChannel('channel');
                if (!data.blacklist.whitelisted_channels.includes(channel.id)) {
                    data.blacklist.whitelisted_channels.push(channel.id);
                    automod.setConfig(guildId, { blacklist: data.blacklist });
                    return interaction.reply({ content: `Added ${channel} to the channel whitelist.`, flags: MessageFlags.Ephemeral });
                }
                return interaction.reply({ content: 'Channel already whitelisted.', ephemeral: true });
            }
            if (subcommand === 'remove') {
                const channel = interaction.options.getChannel('channel');
                data.blacklist.whitelisted_channels = data.blacklist.whitelisted_channels.filter(id => id !== channel.id);
                automod.setConfig(guildId, { blacklist: data.blacklist });
                return interaction.reply({ content: `Removed ${channel} from the channel whitelist.`, flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'reset') {
                data.blacklist.whitelisted_channels = [];
                automod.setConfig(guildId, { blacklist: data.blacklist });
                return interaction.reply({ content: 'Reset target whitelisted channels.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'show') {
                const content = data.blacklist.whitelisted_channels.length > 0 ? data.blacklist.whitelisted_channels.map(id => `<#${id}>`).join(', ') : 'None';
                return interaction.reply({ content: `Whitelisted Channels: ${content}`, flags: MessageFlags.Ephemeral });
            }
        }

        if (group === 'wlrole') {
            // Similar logic for roles
            if (subcommand === 'add') {
                const role = interaction.options.getRole('role');
                if (!data.blacklist.whitelisted_roles.includes(role.id)) {
                    data.blacklist.whitelisted_roles.push(role.id);
                    automod.setConfig(guildId, { blacklist: data.blacklist });
                    return interaction.reply({ content: `Added ${role} to the role whitelist.`, flags: MessageFlags.Ephemeral });
                }
                return interaction.reply({ content: 'Role already whitelisted.', ephemeral: true });
            }
            if (subcommand === 'remove') {
                const role = interaction.options.getRole('role');
                data.blacklist.whitelisted_roles = data.blacklist.whitelisted_roles.filter(id => id !== role.id);
                automod.setConfig(guildId, { blacklist: data.blacklist });
                return interaction.reply({ content: `Removed ${role} from the role whitelist.`, flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'reset') {
                data.blacklist.whitelisted_roles = [];
                automod.setConfig(guildId, { blacklist: data.blacklist });
                return interaction.reply({ content: 'Reset target whitelisted roles.', flags: MessageFlags.Ephemeral });
            }
            if (subcommand === 'show') {
                const content = data.blacklist.whitelisted_roles.length > 0 ? data.blacklist.whitelisted_roles.map(id => `<@&${id}>`).join(', ') : 'None';
                return interaction.reply({ content: `Whitelisted Roles: ${content}`, flags: MessageFlags.Ephemeral });
            }
        }
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const secondArg = args[1] ? args[1].toLowerCase() : 'help';
        const guildId = message.guild.id;

        const mainHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **blword add**\n› Add one or more words to the blacklist.\n\n` +
                `» **blword punish**\n› Manage punishments for using blacklisted words.\n\n` +
                `» **blword remove**\n› Remove one or more words from the blacklist.\n\n` +
                `» **blword reset**\n› Reset the entire blacklist for this server.\n\n` +
                `» **blword show**\n› Show all blacklisted words.\n\n` +
                `» **blword wlchannel**\n› Manage the channel whitelist.\n\n` +
                `» **blword wlrole**\n› Manage the role whitelist.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const wlchannelHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **blword wlchannel add**\n› Add a channel to the whitelist.\n\n` +
                `» **blword wlchannel remove**\n› Remove a channel from the whitelist.\n\n` +
                `» **blword wlchannel reset**\n› Reset the channel whitelist for this server.\n\n` +
                `» **blword wlchannel show**\n› Show all whitelisted channels.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const wlroleHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **blword wlrole add**\n› Add a role to the whitelist.\n\n` +
                `» **blword wlrole remove**\n› Remove a role from the whitelist.\n\n` +
                `» **blword wlrole reset**\n› Reset the role whitelist for this server.\n\n` +
                `» **blword wlrole show**\n› Show all whitelisted roles.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const punishHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **blword punish ban**\n› Set punishment to ban.\n\n` +
                `» **blword punish kick**\n› Set punishment to kick.\n\n` +
                `» **blword punish mute**\n› Set punishment to mute.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'reset', 'show', 'punish', 'wlchannel', 'wlrole'].includes(subcommand)) {
            return message.reply({ embeds: [mainHelp] });
        }

        if (subcommand === 'wlchannel' && (secondArg === 'help' || !args[1])) {
            return message.reply({ embeds: [wlchannelHelp] });
        }
        if (subcommand === 'wlrole' && (secondArg === 'help' || !args[1])) {
            return message.reply({ embeds: [wlroleHelp] });
        }
        if (subcommand === 'punish' && (secondArg === 'help' || !args[1])) {
            return message.reply({ embeds: [punishHelp] });
        }

        // Permission check
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply('❌ No access');
        }

        const data = automod.getGuildData(guildId);

        if (subcommand === 'add') {
            const words = args.slice(1).join(' ').split(',').map(s => s.trim().toLowerCase()).filter(s => s.length > 0);
            if (words.length === 0) {
                return message.reply('Please provide words to blacklist. Usage: `!blword add word1, word2, word3`');
            }
            const added = [];
            words.forEach(word => {
                if (!data.blacklist.words.includes(word)) {
                    data.blacklist.words.push(word);
                    added.push(word);
                }
            });
            automod.setConfig(guildId, { blacklist: data.blacklist });
            const reply = await message.reply(added.length > 0 ? `✅ Successfully added **${added.length}** word(s) to the blacklist.` : 'No new words were added.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'remove') {
            const words = args.slice(1).join(' ').split(',').map(s => s.trim().toLowerCase());
            if (words.length === 0) {
                return message.reply('Please provide words to remove. Usage: `!blword remove word1, word2`');
            }
            const initialCount = data.blacklist.words.length;
            data.blacklist.words = data.blacklist.words.filter(w => !words.includes(w));
            const removedCount = initialCount - data.blacklist.words.length;
            automod.setConfig(guildId, { blacklist: data.blacklist });
            const reply = await message.reply(`✅ Successfully removed **${removedCount}** word(s) from the blacklist.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'reset') {
            data.blacklist.words = [];
            automod.setConfig(guildId, { blacklist: data.blacklist });
            const reply = await message.reply('✅ Successfully reset the word blacklist.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'show') {
            const words = data.blacklist.words.length > 0 ? data.blacklist.words.join(', ') : 'None';
            const embed = new EmbedBuilder()
                .setTitle('Blacklisted Words')
                .setDescription(words)
                .setColor('#2b2d31')
                .setFooter({ text: `Total: ${data.blacklist.words.length} words` });
            return message.reply({ embeds: [embed] });
        }

        if (subcommand === 'export') {
            try {
                const jsonBuffer = Buffer.from(JSON.stringify(data.blacklist, null, 2));
                return message.reply({ files: [{ attachment: jsonBuffer, name: `blacklist_${guildId}.json` }] });
            } catch (err) {
                console.error('Failed to export blacklist (message):', err);
                return message.reply('Failed to export blacklist.');
            }
        }

        if (subcommand === 'punish') {
            const type = secondArg;
            if (!['ban', 'kick', 'mute'].includes(type)) {
                return message.reply({ embeds: [punishHelp] });
            }
            data.blacklist.punishment = type;
            automod.setConfig(guildId, { blacklist: data.blacklist });
            const reply = await message.reply(`✅ Set blacklist punishment to: **${type}**`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'wlchannel') {
            const action = secondArg;
            if (!['add', 'remove', 'reset', 'show'].includes(action)) {
                return message.reply({ embeds: [wlchannelHelp] });
            }

            if (action === 'add') {
                const channelId = args[2] ? args[2].replace(/[<#>]/g, '') : null;
                if (!channelId) {
                    return message.reply('Please mention a channel. Usage: `!blword wlchannel add #channel`');
                }
                const channel = message.guild.channels.cache.get(channelId);
                if (!channel) {
                    return message.reply('Invalid channel provided.');
                }
                if (!data.blacklist.whitelisted_channels.includes(channelId)) {
                    data.blacklist.whitelisted_channels.push(channelId);
                    automod.setConfig(guildId, { blacklist: data.blacklist });
                    const reply = await message.reply(`✅ Added ${channel} to whitelisted channels.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                } else {
                    return message.reply('This channel is already whitelisted.');
                }
            } else if (action === 'remove') {
                const channelId = args[2] ? args[2].replace(/[<#>]/g, '') : null;
                if (!channelId) {
                    return message.reply('Please mention a channel. Usage: `!blword wlchannel remove #channel`');
                }
                data.blacklist.whitelisted_channels = data.blacklist.whitelisted_channels.filter(id => id !== channelId);
                automod.setConfig(guildId, { blacklist: data.blacklist });
                const reply = await message.reply('✅ Removed channel from whitelist.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'reset') {
                data.blacklist.whitelisted_channels = [];
                automod.setConfig(guildId, { blacklist: data.blacklist });
                const reply = await message.reply('✅ Reset whitelisted channels.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'show') {
                const content = data.blacklist.whitelisted_channels.length > 0 ? data.blacklist.whitelisted_channels.map(id => `<#${id}>`).join(', ') : 'None';
                return message.reply(`**Whitelisted Channels:** ${content}`);
            }
            return;
        }

        if (subcommand === 'wlrole') {
            const action = secondArg;
            if (!['add', 'remove', 'reset', 'show'].includes(action)) {
                return message.reply({ embeds: [wlroleHelp] });
            }

            if (action === 'add') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                if (!roleId) {
                    return message.reply('Please mention a role. Usage: `!blword wlrole add @role`');
                }
                const role = message.guild.roles.cache.get(roleId);
                if (!role) {
                    return message.reply('Invalid role provided.');
                }
                if (!data.blacklist.whitelisted_roles.includes(roleId)) {
                    data.blacklist.whitelisted_roles.push(roleId);
                    automod.setConfig(guildId, { blacklist: data.blacklist });
                    const reply = await message.reply(`✅ Added ${role} to whitelisted roles.`);
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                } else {
                    return message.reply('This role is already whitelisted.');
                }
            } else if (action === 'remove') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                if (!roleId) {
                    return message.reply('Please mention a role. Usage: `!blword wlrole remove @role`');
                }
                data.blacklist.whitelisted_roles = data.blacklist.whitelisted_roles.filter(id => id !== roleId);
                automod.setConfig(guildId, { blacklist: data.blacklist });
                const reply = await message.reply('✅ Removed role from whitelist.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'reset') {
                data.blacklist.whitelisted_roles = [];
                automod.setConfig(guildId, { blacklist: data.blacklist });
                const reply = await message.reply('✅ Reset whitelisted roles.');
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'show') {
                const content = data.blacklist.whitelisted_roles.length > 0 ? data.blacklist.whitelisted_roles.map(id => `<@&${id}>`).join(', ') : 'None';
                return message.reply(`**Whitelisted Roles:** ${content}`);
            }
            return;
        }

        return message.reply({ content: `The \`${subcommand}\` feature is currently available via slash command: \`/blword ${subcommand}\`` });
    }
};
