const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    MessageFlags,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const embedManager = require('../../functions/embedManager');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('embed')
            .setDescription('Embed management commands')
            .addSubcommand(sub => sub.setName('create').setDescription('Create a new embed (Interactive)').addStringOption(opt => opt.setName('name').setDescription('Name for the embed').setRequired(true)))
            .addSubcommand(sub => sub.setName('edit').setDescription('Edit an existing embed (Interactive)').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('rename').setDescription('Rename an embed').addStringOption(opt => opt.setName('name').setDescription('Current name').setRequired(true)).addStringOption(opt => opt.setName('newname').setDescription('New name').setRequired(true)))
            .addSubcommand(sub => sub.setName('show').setDescription('Show an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('send').setDescription('Send an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel')))
            .addSubcommand(sub => sub.setName('list').setDescription('List all embeds'))
            .addSubcommand(sub => sub.setName('guide').setDescription('Show guide')),

        async execute(interaction) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return interaction.reply({ content: '❌ Manage Guild permission required.', flags: MessageFlags.Ephemeral });
            }

            const sub = interaction.options.getSubcommand();
            const guildId = interaction.guild.id;

            if (sub === 'create') {
                const name = interaction.options.getString('name');
                const embed = embedManager.createEmbed(guildId, name);
                if (!embed) return interaction.reply({ content: `❌ Embed **${name}** already exists.`, flags: MessageFlags.Ephemeral });

                return interaction.reply({
                    content: `✅ Embed **${name}** created! Use \`/embed edit ${name}\` to customize it.`,
                    flags: MessageFlags.Ephemeral
                });
            }

            if (sub === 'delete') {
                const name = interaction.options.getString('name');
                const success = embedManager.deleteEmbed(guildId, name);
                return interaction.reply({ content: success ? `✅ Deleted embed **${name}**.` : `❌ Embed **${name}** not found.`, flags: MessageFlags.Ephemeral });
            }

            if (sub === 'rename') {
                const name = interaction.options.getString('name');
                const newName = interaction.options.getString('newname');
                const success = embedManager.renameEmbed(guildId, name, newName);
                if (!success) return interaction.reply({ content: `❌ Failed. Check if **${name}** exists and **${newName}** is unused.`, flags: MessageFlags.Ephemeral });
                return interaction.reply({ content: `✅ Renamed **${name}** to **${newName}**.`, flags: MessageFlags.Ephemeral });
            }

            if (sub === 'list') {
                const names = embedManager.getAllEmbeds(guildId);
                return interaction.reply({
                    embeds: [new EmbedBuilder().setTitle('Saved Embeds').setDescription(names.length ? names.join('\n') : 'No embeds found.').setColor('#2b2d31')],
                    flags: MessageFlags.Ephemeral
                });
            }

            if (sub === 'show') {
                const name = interaction.options.getString('name');
                const data = embedManager.getEmbed(guildId, name);
                if (!data) return interaction.reply({ content: `❌ Embed **${name}** not found.`, flags: MessageFlags.Ephemeral });
                return interaction.reply({ embeds: [buildDiscordEmbed(data)] });
            }

            if (sub === 'send') {
                const name = interaction.options.getString('name');
                const channel = interaction.options.getChannel('channel') || interaction.channel;
                const data = embedManager.getEmbed(guildId, name);
                if (!data) return interaction.reply({ content: `❌ Embed **${name}** not found.`, flags: MessageFlags.Ephemeral });

                try {
                    await channel.send({ embeds: [buildDiscordEmbed(data)] });
                    return interaction.reply({ content: `✅ Sent **${name}** to ${channel}.`, flags: MessageFlags.Ephemeral });
                } catch (e) {
                    return interaction.reply({ content: `❌ Failed to send to ${channel}. Check permissions.`, flags: MessageFlags.Ephemeral });
                }
            }

            if (sub === 'edit') {
                const name = interaction.options.getString('name');
                const data = embedManager.getEmbed(guildId, name);
                if (!data) return interaction.reply({ content: `❌ Embed **${name}** not found.`, flags: MessageFlags.Ephemeral });

                // Interactive Edit Panel
                const embed = buildDiscordEmbed(data);

                const row1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`embed_edit_title_${name}`).setLabel('Title').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`embed_edit_desc_${name}`).setLabel('Description').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`embed_edit_color_${name}`).setLabel('Color').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`embed_edit_author_${name}`).setLabel('Author').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`embed_edit_footer_${name}`).setLabel('Footer').setStyle(ButtonStyle.Secondary)
                );
                const row2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`embed_edit_image_${name}`).setLabel('Image/Thumb').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`embed_edit_field_${name}`).setLabel('Add Field').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId(`embed_edit_preview_${name}`).setLabel('Refresh Preview').setStyle(ButtonStyle.Success)
                );

                return interaction.reply({
                    content: `Editing **${name}**`,
                    embeds: [embed],
                    components: [row1, row2],
                    flags: MessageFlags.Ephemeral
                });
            }
        },

        // --- INTERACTION HANDLING ---

        async handleComponent(interaction) {
            const id = interaction.customId;
            if (!id.startsWith('embed_edit_')) return;

            const parts = id.split('_');
            const action = parts[2]; // title, desc, etc
            const name = parts.slice(3).join('_'); // name might contain underscores
            const guildId = interaction.guild.id;

            if (action === 'preview') {
                const data = embedManager.getEmbed(guildId, name);
                if (!data) return interaction.reply({ content: '❌ Embed not found.', flags: MessageFlags.Ephemeral });
                return interaction.update({ embeds: [buildDiscordEmbed(data)] });
            }

            // For fields, maybe just a modal to add one?
            if (action === 'field') {
                const modal = new ModalBuilder().setCustomId(`embed_modal_field_${name}`).setTitle('Add Field');
                modal.addComponents(
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('f_name').setLabel('Field Name').setStyle(TextInputStyle.Short).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('f_value').setLabel('Field Value').setStyle(TextInputStyle.Paragraph).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('f_inline').setLabel('Inline? (true/false)').setStyle(TextInputStyle.Short).setRequired(false))
                );
                return interaction.showModal(modal);
            }

            // Standard property edits via Modal
            const modal = new ModalBuilder().setCustomId(`embed_modal_${action}_${name}`).setTitle(`Edit ${action}`);

            if (action === 'title') {
                modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Title').setStyle(TextInputStyle.Short).setRequired(true)));
            } else if (action === 'desc') {
                modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Description').setStyle(TextInputStyle.Paragraph).setRequired(true)));
            } else if (action === 'color') {
                modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Color (Hex)').setStyle(TextInputStyle.Short).setRequired(true)));
            }

            // ... more handlers for Author/Footer/Image if needed, keeping it simple for now or needing more Modals.
            // Let's support Author Name and Footer Text for now.
            else if (action === 'author') {
                modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Author Name').setStyle(TextInputStyle.Short).setRequired(true)));
            } else if (action === 'footer') {
                modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('val').setLabel('Footer Text').setStyle(TextInputStyle.Short).setRequired(true)));
            } else if (action === 'image') {
                modal.addComponents(
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('img').setLabel('Image URL').setStyle(TextInputStyle.Short).setRequired(false)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('thumb').setLabel('Thumbnail URL').setStyle(TextInputStyle.Short).setRequired(false))
                );
            }

            await interaction.showModal(modal);
        },

        async handleModal(interaction) {
            const id = interaction.customId;
            if (!id.startsWith('embed_modal_')) return;

            const parts = id.split('_');
            const action = parts[2];
            const name = parts.slice(3).join('_');
            const guildId = interaction.guild.id;

            let updates = {};

            if (action === 'field') {
                const fName = interaction.fields.getTextInputValue('f_name');
                const fValue = interaction.fields.getTextInputValue('f_value');
                const fInline = interaction.fields.getTextInputValue('f_inline') === 'true';
                const current = embedManager.getEmbed(guildId, name);
                if (current) {
                    updates.fields = [...current.fields, { name: fName, value: fValue, inline: fInline }];
                }
            } else if (action === 'image') {
                const img = interaction.fields.getTextInputValue('img');
                const thumb = interaction.fields.getTextInputValue('thumb');
                updates.image = img || null;
                updates.thumbnail = thumb || null;
            } else {
                const val = interaction.fields.getTextInputValue('val');
                if (action === 'title') updates.title = val;
                if (action === 'desc') updates.description = val;
                if (action === 'color') updates.color = val;
                if (action === 'author') updates.author = { name: val };
                if (action === 'footer') updates.footer = { text: val };
            }

            embedManager.updateEmbed(guildId, name, updates);

            // Re-render the edit panel
            const newData = embedManager.getEmbed(guildId, name);
            const embed = buildDiscordEmbed(newData);

            // We can't update the ORIGINAL message easily from ModalSubmit unless we deferUpdate?
            // Actually `update` on ModalSubmit works if we are replying to the component that opened it? 
            // No, Modals are separate. We usually have to editReply.
            // But we don't have reference to the original "Editing..." message here easily unless we fetch it.
            // Simple approach: Reply with "Updated!" and new preview.

            await interaction.reply({ content: `✅ Updated **${name}**! Click "Refresh Preview" on the controls above to see changes.`, embeds: [embed], flags: MessageFlags.Ephemeral });
        },

        async executeMessage(message, args) {
            const sub = args[0]?.toLowerCase();
            const guildId = message.guild.id;

            // Prefix Help
            if (!sub || sub === 'help') {
                const helpEmbed = new EmbedBuilder()
                    .setDescription(
                        `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                        `» **embed create <name>**\n› Create a new embed.\n\n` +
                        `» **embed edit <name>**\n› Edit an existing embed.\n\n` +
                        `» **embed delete <name>**\n› Delete an embed.\n\n` +
                        `» **embed rename <name> <newname>**\n› Rename an embed.\n\n` +
                        `» **embed send <name> [channel]**\n› Send an embed.\n\n` +
                        `» **embed list**\n› List all embeds.\n\n` +
                        `» **embed show <name>**\n› Show an embed.`
                    )
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
                return message.reply({ embeds: [helpEmbed] });
            }

            if (sub === 'create') {
                const name = args[1];
                if (!name) return message.reply('Usage: `!embed create <name>`');
                if (embedManager.createEmbed(guildId, name)) return message.reply(`✅ Created embed **${name}**.`);
                return message.reply(`❌ Embed **${name}** already exists.`);
            }
            // ... legacy prefix support mapping to manager ...
            // For brevity, I'm focusing on the requested "Fix embed" which implies Slash. 
            // But keeping basic prefix parity is good.
            if (sub === 'delete') {
                const name = args[1];
                if (embedManager.deleteEmbed(guildId, name)) return message.reply('✅ Deleted.');
                return message.reply('❌ Not found.');
            }
            if (sub === 'send') {
                const name = args[1];
                const channel = message.mentions.channels.first() || message.channel;
                const data = embedManager.getEmbed(guildId, name);
                if (!data) return message.reply('❌ Not found.');
                await channel.send({ embeds: [buildDiscordEmbed(data)] });
                return message.reply('✅ Sent.');
            }

            // List/Show
            if (sub === 'list') return message.reply(`Embeds: ${embedManager.getAllEmbeds(guildId).join(', ')}`);
        }
    },
    {
        data: new SlashCommandBuilder().setName('variables').setDescription('Show variables'),
        async execute(interaction) {
            interaction.reply({ content: 'Variables: {user}, {guild.name}, {member.count}...', flags: MessageFlags.Ephemeral });
        },
        async executeMessage(message) {
            message.reply('Variables: {user}, {guild.name}, {member.count}...');
        }
    }
];

function buildDiscordEmbed(data) {
    const e = new EmbedBuilder();
    if (data.title) e.setTitle(data.title);
    if (data.description) e.setDescription(data.description);
    if (data.color) e.setColor(data.color);
    if (data.author?.name) e.setAuthor(data.author);
    if (data.footer?.text) e.setFooter(data.footer);
    if (data.image) e.setImage(data.image);
    if (data.thumbnail) e.setThumbnail(data.thumbnail);
    if (data.fields) e.addFields(data.fields);
    if (data.timestamp) e.setTimestamp();
    return e;
}
