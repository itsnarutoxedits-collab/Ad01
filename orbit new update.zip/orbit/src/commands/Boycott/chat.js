const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const permissionChecker = require('../../functions/permissionChecker');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('chat')
        .setDescription('Manage chat bans')
        .addSubcommand(sub => sub.setName('ban').setDescription('Ban a user from chatting').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('unban').setDescription('Unban a user from chatting').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('banlist').setDescription('Show list of chat banned users')),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageMessages')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Chat Ban System').setDescription(`Executed chat subcommand: **${sub}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
            return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **chat ban @user**\n› Ban a user from chatting.\n\n` +
                `» **chat unban @user**\n› Unban a user from chatting.\n\n` +
                `» **chat banlist**\n› Show list of chat banned users.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['ban', 'unban', 'banlist'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/chatban.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { banned: [] };

        if (subcommand === 'banlist') {
            const banned = data[guildId].banned || [];
            if (!banned.length) return message.reply({ embeds: [embedHelper.info('No users are chat banned.')] });
            const listEmbed = new EmbedBuilder()
                .setTitle('🔇 Chat Banned Users')
                .setDescription(banned.map(id => `<@${id}>`).join('\n'))
                .setColor('#FF0000');
            return message.reply({ embeds: [listEmbed] });
        }

        if (subcommand === 'ban') {
            const target = message.mentions.users.first();
            if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!chat ban @user`')] });
            if (data[guildId].banned.includes(target.id)) {
                return message.reply('User is already chat banned.');
            }
            data[guildId].banned.push(target.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ ${target} has been chat banned.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'unban') {
            const target = message.mentions.users.first();
            if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!chat unban @user`')] });
            if (!data[guildId].banned.includes(target.id)) {
                return message.reply('User is not chat banned.');
            }
            data[guildId].banned = data[guildId].banned.filter(id => id !== target.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply(`✅ ${target} has been unbanned from chat.`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply({ embeds: [embedHelper.info(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/chat ${subcommand}\``)] });
    }
};
