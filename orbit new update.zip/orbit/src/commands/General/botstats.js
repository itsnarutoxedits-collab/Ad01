const { EmbedBuilder } = require('discord.js');
const os = require('os');
const fs = require('fs');
const path = require('path');

// Stats commands - prefix only to save slash command slots
module.exports = [
    {
        name: 'stats',
        async executeMessage(message, args) {
            const client = message.client;
            
            // Uptime calculation
            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor((uptime % 86400) / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = Math.floor(uptime % 60);
            
            // Memory usage
            const memUsage = process.memoryUsage();
            const totalMem = os.totalmem();
            const usedMem = totalMem - os.freemem();
            const memPercent = ((usedMem / totalMem) * 100).toFixed(1);
            
            // CPU usage
            const cpuUsage = process.cpuUsage();
            const cpuPercent = (((cpuUsage.user + cpuUsage.system) / 1000000) / uptime * 100).toFixed(1);
            
            // Count files and lines
            let fileCount = 0;
            let commandCount = 0;
            let totalLines = 0;
            
            const countFiles = (dir) => {
                try {
                    const files = fs.readdirSync(dir);
                    files.forEach(file => {
                        const filePath = path.join(dir, file);
                        const stat = fs.statSync(filePath);
                        if (stat.isDirectory()) {
                            countFiles(filePath);
                        } else if (file.endsWith('.js')) {
                            fileCount++;
                            if (filePath.includes('/commands/')) {
                                commandCount++;
                            }
                            try {
                                const content = fs.readFileSync(filePath, 'utf8');
                                totalLines += content.split('\n').length;
                            } catch (e) {}
                        }
                    });
                } catch (e) {}
            };
            
            const srcPath = path.join(__dirname, '../../');
            countFiles(srcPath);
            
            // Calculate total users
            let totalUsers = 0;
            client.guilds.cache.forEach(guild => {
                totalUsers += guild.memberCount;
            });
            
            // API Latency test
            const apiStart = Date.now();
            await message.channel.sendTyping().catch(() => {});
            const apiLatency = Date.now() - apiStart;
            
            const embed = new EmbedBuilder()
                .setTitle(`${client.user.username} Statistics`)
                .setDescription(
                    `🤖 **${client.user.username}** : ${client.user.id}\n` +
                    `⏰ **Uptime** : ${days}d ${hours}h ${minutes}m ${seconds}s\n\n` +
                    `**Modules**\n` +
                    `> 📦 **Discord.Js** : ${require('discord.js').version}\n` +
                    `> 🟢 **Node Version** : ${process.version}\n\n` +
                    `**Latency**\n` +
                    `> ⏱️ **Websocket Latency** : ${Math.round(client.ws.ping)}ms\n` +
                    `> ⏱️ **API Latency** : ${apiLatency}ms\n\n` +
                    `**Supports**\n` +
                    `> 🏰 **Guilds** : ${client.guilds.cache.size}\n` +
                    `> 👥 **Users** : ${totalUsers.toLocaleString()}\n` +
                    `> 📺 **Channels** : ${client.channels.cache.size}\n\n` +
                    `**Codebase**\n` +
                    `> 📁 **Codebase** : ${fileCount} files\n` +
                    `> 💻 **Command Base** : ${commandCount}\n` +
                    `> 📝 **Total Base** : ${totalLines.toLocaleString()} lines\n\n` +
                    `**System**\n` +
                    `> 🐧 **OS** : ${os.type()} ${os.release()}\n` +
                    `> ⚙️ **CPU** : ${cpuPercent}%\n` +
                    `> 💾 **RAM** : ${(usedMem / 1024 / 1024 / 1024).toFixed(1)}GB (${memPercent}%)\n` +
                    `> 🔧 **Cores** : ${os.cpus().length}`
                )
                .setColor('#2b2d31')
                .setThumbnail(client.user.displayAvatarURL())
                .setTimestamp();
                
            return message.reply({ embeds: [embed] });
        }
    },
    {
        name: 'uptime',
        async executeMessage(message, args) {
            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor((uptime % 86400) / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = Math.floor(uptime % 60);
            
            const embed = new EmbedBuilder()
                .setTitle('⏰ Bot Uptime')
                .setDescription(`**${days}** days, **${hours}** hours, **${minutes}** minutes, **${seconds}** seconds`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },
    {
        name: 'ping',
        async executeMessage(message, args) {
            const sent = await message.reply('🏓 Pinging...');
            const embed = new EmbedBuilder()
                .setTitle('🏓 Pong!')
                .addFields(
                    { name: 'Latency', value: `${sent.createdTimestamp - message.createdTimestamp}ms`, inline: true },
                    { name: 'API Latency', value: `${Math.round(message.client.ws.ping)}ms`, inline: true }
                )
                .setColor('#2b2d31');
            return sent.edit({ content: null, embeds: [embed] });
        }
    },
    {
        name: 'users',
        async executeMessage(message, args) {
            const embed = new EmbedBuilder()
                .setTitle('👥 Total Users')
                .setDescription(`The bot can see **${message.client.users.cache.size}** users across **${message.client.guilds.cache.size}** servers`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    }
];
