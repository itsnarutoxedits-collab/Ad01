const { EmbedBuilder } = require('discord.js');
const afk = require('../../functions/afkManager');
const embed = require('../../functions/embedHelper');

// Prefix-only commands (no slash registration to save on 100 command limit)
module.exports = [
    // Server Banner
    {
        name: 'serverbanner',
        async executeMessage(message, args) {
            const banner = message.guild.bannerURL({ size: 1024 });
            if (!banner) {
                return message.reply({ embeds: [embed.error('This server has no banner set.')] });
            }
            const embed = new EmbedBuilder()
                .setTitle(`${message.guild.name} Banner`)
                .setImage(banner)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Server Icon
    {
        name: 'servericon',
        async executeMessage(message, args) {
            const icon = message.guild.iconURL({ size: 1024 });
            if (!icon) {
                return message.reply({ embeds: [embed.error('This server has no icon set.')] });
            }
            const embed = new EmbedBuilder()
                .setTitle(`${message.guild.name} Icon`)
                .setImage(icon)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Avatar
    {
        name: 'avatar',
        async executeMessage(message, args) {
            const userId = args[0] ? args[0].replace(/[<@!>]/g, '') : message.author.id;
            const user = await message.client.users.fetch(userId).catch(() => null) || message.author;
            const avatar = user.displayAvatarURL({ size: 1024, dynamic: true });
            const embed = new EmbedBuilder()
                .setTitle(`${user.username}'s Avatar`)
                .setImage(avatar)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Banner
    {
        name: 'banner',
        async executeMessage(message, args) {
            const userId = args[0] ? args[0].replace(/[<@!>]/g, '') : message.author.id;
            const user = await message.client.users.fetch(userId, { force: true }).catch(() => null) || message.author;
            const banner = user.bannerURL({ size: 1024 });
            if (!banner) {
                return message.reply({ embeds: [embed.error(`${user.username} has no banner set.`)] });
            }
            const embed = new EmbedBuilder()
                .setTitle(`${user.username}'s Banner`)
                .setImage(banner)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // User Info
    {
        name: 'userinfo',
        async executeMessage(message, args) {
            const userId = args[0] ? args[0].replace(/[<@!>]/g, '') : message.author.id;
            const user = await message.client.users.fetch(userId).catch(() => null) || message.author;
            const member = await message.guild.members.fetch(user.id).catch(() => null);
            
            const embed = new EmbedBuilder()
                .setTitle(`User Information: ${user.username}`)
                .setThumbnail(user.displayAvatarURL({ size: 256 }))
                .addFields(
                    { name: 'Username', value: user.username, inline: true },
                    { name: 'ID', value: user.id, inline: true },
                    { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true }
                )
                .setColor('#2b2d31');
            
            if (member) {
                embed.addFields(
                    { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Roles', value: member.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.toString()).join(', ') || 'None', inline: false }
                );
            }
            
            return message.reply({ embeds: [embed] });
        }
    },

    // Server Info
    {
        name: 'serverinfo',
        async executeMessage(message, args) {
            const guild = message.guild;
            const owner = await guild.fetchOwner();
            
            const embed = new EmbedBuilder()
                .setTitle(`Server Information: ${guild.name}`)
                .setThumbnail(guild.iconURL({ size: 256 }))
                .addFields(
                    { name: 'Server Name', value: guild.name, inline: true },
                    { name: 'Server ID', value: guild.id, inline: true },
                    { name: 'Owner', value: owner.user.username, inline: true },
                    { name: 'Member Count', value: `${guild.memberCount}`, inline: true },
                    { name: 'Created At', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true }
                )
                .setColor('#2b2d31');
            
            if (guild.bannerURL()) {
                embed.setImage(guild.bannerURL({ size: 1024 }));
            }
            
            return message.reply({ embeds: [embed] });
        }
    },

    // Member Count
    {
        name: 'membercount',
        async executeMessage(message, args) {
            const guild = message.guild;
            const embed = new EmbedBuilder()
                .setTitle('Member Count')
                .setDescription(`Total Members: **${guild.memberCount}**`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Boost Count
    {
        name: 'boostcount',
        async executeMessage(message, args) {
            const guild = message.guild;
            const embed = new EmbedBuilder()
                .setTitle('Boost Count')
                .setDescription(`Total Boosts: **${guild.premiumSubscriptionCount || 0}**\nBoost Level: **${guild.premiumTier}**`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Joined At
    {
        name: 'joinedat',
        async executeMessage(message, args) {
            const userId = args[0] ? args[0].replace(/[<@!>]/g, '') : message.author.id;
            const user = await message.client.users.fetch(userId).catch(() => null) || message.author;
            const member = await message.guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                return message.reply('User not found in this server.');
            }
            const embed = new EmbedBuilder()
                .setTitle('Join Date')
                .setDescription(`${user.username} joined **${message.guild.name}** <t:${Math.floor(member.joinedTimestamp / 1000)}:R>`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // AFK
    {
        name: 'afk',
        async executeMessage(message, args) {
            const reason = args.join(' ') || 'AFK';
            afk.setAFK(message.author.id, reason, Date.now());
            return message.reply(`✅ You are now AFK: ${reason}`);
        }
    },

    // Choose
    {
        name: 'choose',
        async executeMessage(message, args) {
            const options = args.join(' ').split(',').map(o => o.trim()).filter(o => o);
            if (options.length < 2) {
                return message.reply('Please provide at least 2 options separated by commas.');
            }
            const chosen = options[Math.floor(Math.random() * options.length)];
            const embed = new EmbedBuilder()
                .setTitle('🎲 Choice')
                .setDescription(`I choose: **${chosen}**`)
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // First Message
    {
        name: 'fmsg',
        async executeMessage(message, args) {
            try {
                const messages = await message.channel.messages.fetch({ limit: 1, after: '0' });
                const firstMsg = messages.first();
                if (!firstMsg) {
                    return message.reply('Could not fetch the first message.');
                }
                const embed = new EmbedBuilder()
                    .setTitle('First Message')
                    .setDescription(`[Jump to Message](${firstMsg.url})`)
                    .addFields(
                        { name: 'Author', value: `<@${firstMsg.author.id}>`, inline: true },
                        { name: 'Sent', value: `<t:${Math.floor(firstMsg.createdTimestamp / 1000)}:R>`, inline: true }
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            } catch (error) {
                console.error(error);
                return message.reply('Failed to fetch the first message.');
            }
        }
    },

    // Vote
    {
        name: 'vote',
        async executeMessage(message, args) {
            const embed = new EmbedBuilder()
                .setTitle('🗳️ Vote for Orbit')
                .setDescription('Support us by voting on these platforms:\n\n[Top.gg](https://top.gg)\n[Discord.bots.gg](https://discord.bots.gg)')
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Status
    {
        name: 'status',
        async executeMessage(message, args) {
            const embed = new EmbedBuilder()
                .setTitle('🟢 Bot Status')
                .setDescription('Bot is online and operational!')
                .addFields(
                    { name: 'Ping', value: `${Math.round(message.client.ws.ping)}ms`, inline: true },
                    { name: 'Servers', value: `${message.client.guilds.cache.size}`, inline: true }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Profile (placeholder)
    {
        name: 'profile',
        async executeMessage(message, args) {
            const userId = args[0] ? args[0].replace(/[<@!>]/g, '') : message.author.id;
            const user = await message.client.users.fetch(userId).catch(() => null) || message.author;
            const embed = new EmbedBuilder()
                .setTitle(`${user.username}'s Profile`)
                .setThumbnail(user.displayAvatarURL({ size: 256 }))
                .setDescription('Profile system coming soon!')
                .setColor('#2b2d31');
            return message.reply({ embeds: [embed] });
        }
    },

    // Timer (placeholder)
    {
        name: 'timer',
        async executeMessage(message, args) {
            const time = args[0] || '1m';
            return message.reply(`⏰ Timer set for ${time}. (Feature coming soon)`);
        }
    }
];
