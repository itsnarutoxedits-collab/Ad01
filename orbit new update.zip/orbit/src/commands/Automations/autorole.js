const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autorole')
        .setDescription('Configure auto-roles for new members and bots')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable auto-role module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable auto-role module'))
        .addSubcommand(sub => sub.setName('show').setDescription('Show auto-role settings'))
        .addSubcommandGroup(group => group.setName('humans').setDescription('Manage auto-roles for humans')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role for humans').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role for humans').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset human auto-roles'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show human auto-roles'))
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable human auto-roles'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable human auto-roles')))
        .addSubcommandGroup(group => group.setName('bots').setDescription('Manage auto-roles for bots')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role for bots').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role for bots').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset bot auto-roles'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show bot auto-roles'))
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable bot auto-roles'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable bot auto-roles'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageRoles')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Auto Role').setDescription(`Executed autorole command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **autorole enable/disable**\n› Enable or disable the auto-role module.\n\n` +
                `» **autorole show**\n› Show auto-role settings.\n\n` +
                `» **autorole humans**\n› Manage auto-roles for humans (add/remove/reset/show/enable/disable).\n\n` +
                `» **autorole bots**\n› Manage auto-roles for bots (add/remove/reset/show/enable/disable).`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['enable', 'disable', 'show', 'humans', 'bots'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        if (!message.member.permissions.has('ManageRoles')) {
            return message.reply('❌ No access');
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/autorole.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, humanRoles: [], botRoles: [] };

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Autorole module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Autorole module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'show') {
            const cfg = data[guildId];
            const humanRolesList = (cfg.humanRoles || []).map(id => `<@&${id}>`).join(', ') || 'None';
            const botRolesList = (cfg.botRoles || []).map(id => `<@&${id}>`).join(', ') || 'None';
            const showEmbed = new EmbedBuilder()
                .setTitle('Autorole Configuration')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Human Roles', value: humanRolesList },
                    { name: 'Bot Roles', value: botRolesList }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [showEmbed] });
        }

        if (subcommand === 'humans' || subcommand === 'bots') {
            const type = subcommand;
            const action = args[1] ? args[1].toLowerCase() : null;
            const roleKey = type === 'humans' ? 'humanRoles' : 'botRoles';

            if (!data[guildId][roleKey]) data[guildId][roleKey] = [];

            if (action === 'add') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                if (!roleId) {
                    return message.reply(`Please mention a role. Usage: \`!autorole ${type} add @role\``);
                }
                const role = message.guild.roles.cache.get(roleId);
                if (!role) {
                    return message.reply('Invalid role provided.');
                }
                if (data[guildId][roleKey].includes(roleId)) {
                    return message.reply(`This role is already in the ${type} auto-role list.`);
                }
                data[guildId][roleKey].push(roleId);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply(`✅ Added ${role} to ${type} auto-roles.`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'remove') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                if (!roleId) {
                    return message.reply(`Please mention a role. Usage: \`!autorole ${type} remove @role\``);
                }
                data[guildId][roleKey] = data[guildId][roleKey].filter(id => id !== roleId);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply(`✅ Removed role from ${type} auto-roles.`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'reset') {
                data[guildId][roleKey] = [];
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                const reply = await message.reply(`✅ Reset ${type} auto-roles.`);
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } else if (action === 'show') {
                const rolesList = data[guildId][roleKey].map(id => `<@&${id}>`).join(', ') || 'None';
                return message.reply(`**${type.charAt(0).toUpperCase() + type.slice(1)} Auto-Roles**\n${rolesList}`);
            } else {
                return message.reply(`Usage: \`!autorole ${type} <add/remove/reset/show>\``);
            }
            return;
        }

        return message.reply(`Subcommand \`${subcommand}\` is best configured via slash command for now: \`/autorole ${subcommand}\``);
    }
};
