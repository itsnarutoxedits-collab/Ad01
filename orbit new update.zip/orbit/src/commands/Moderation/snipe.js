const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('snipe')
        .setDescription('Retrieve the last deleted message in this channel'),

    async execute(interaction) {
        const snipes = interaction.client.snipes;
        const channelId = interaction.channel.id;

        if (!snipes || !snipes.has(channelId)) {
            return interaction.reply({
                embeds: [embedHelper.error('There is nothing to snipe here!')],
                flags: MessageFlags.Ephemeral
            });
        }

        const snipe = snipes.get(channelId);

        const embed = new EmbedBuilder()
            .setAuthor({ name: snipe.author.tag, iconURL: snipe.author.displayAvatarURL() })
            .setDescription(snipe.content || '*No content (image only)*')
            .setColor('#2F3136')
            .setFooter({ text: `Sniped by ${interaction.user.username} | Message deleted` })
            .setTimestamp(snipe.timestamp);

        if (snipe.image) {
            embed.setImage(snipe.image);
        }

        await interaction.reply({ embeds: [embed] });
    },

    async executeMessage(message, args) {
        const snipes = message.client.snipes;
        const channelId = message.channel.id;

        if (args[0] === 'help') {
            const helpEmbed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **snipe**\n› Retrieve the last deleted message in this channel.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            return message.reply({ embeds: [helpEmbed] });
        }

        if (!snipes || !snipes.has(channelId)) {
            const msg = await message.reply({ embeds: [embedHelper.error('There is nothing to snipe here!')] });
            setTimeout(() => msg.delete().catch(() => { }), 3000);
            return;
        }

        const snipe = snipes.get(channelId);

        const embed = new EmbedBuilder()
            .setAuthor({ name: snipe.author.tag, iconURL: snipe.author.displayAvatarURL() })
            .setDescription(snipe.content || '*No content (image only)*')
            .setColor('#2F3136')
            .setFooter({ text: `Sniped by ${message.author.username} | Message deleted` })
            .setTimestamp(snipe.timestamp);

        if (snipe.image) {
            embed.setImage(snipe.image);
        }

        await message.reply({ embeds: [embed] });
    }
};
