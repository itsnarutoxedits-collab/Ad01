const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const moment = require('moment');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('userinfo')
            .setDescription('Get information about a user')
            .addUserOption(opt => opt.setName('target').setDescription('The user')),
        async execute(interaction) {
            const target = interaction.options.getMember('target') || interaction.member;
            await replyUserInfo(interaction, target);
        },
        async executeMessage(message, args) {
            const target = message.mentions.members.first() || message.member;
            await replyUserInfo(message, target);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('serverinfo')
            .setDescription('Get information about the server'),
        async execute(interaction) {
            await replyServerInfo(interaction, interaction.guild);
        },
        async executeMessage(message) {
            await replyServerInfo(message, message.guild);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('avatar')
            .setDescription('Get user avatar')
            .addUserOption(opt => opt.setName('target').setDescription('Target user')),
        async execute(interaction) {
            const user = interaction.options.getUser('target') || interaction.user;
            await replyAvatar(interaction, user);
        },
        async executeMessage(message) {
            const user = message.mentions.users.first() || message.author;
            await replyAvatar(message, user);
        }
    }
];

async function replyUserInfo(context, member) {
    if (!member) return; // Should not happen with defaults
    const user = member.user;
    const roles = member.roles.cache
        .filter(r => r.id !== context.guild.id)
        .map(r => r).join(', ') || 'None';

    const embed = new EmbedBuilder()
        .setTitle(`User Info: ${user.tag}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setColor(member.displayHexColor)
        .addFields(
            { name: 'ID', value: user.id, inline: true },
            { name: 'Joined Server', value: moment(member.joinedAt).format('LLLL'), inline: true },
            { name: 'Account Created', value: moment(user.createdAt).format('LLLL'), inline: true },
            { name: 'Roles', value: roles.length > 1024 ? 'Too many roles' : roles }
        )
        .setFooter({ text: `Requested by ${context.member ? context.member.user.tag : context.user.tag}` });

    // Handle both Interaction and Message
    if (context.reply) await context.reply({ embeds: [embed] });
}

async function replyServerInfo(context, guild) {
    const owner = await guild.fetchOwner();
    const embed = new EmbedBuilder()
        .setTitle(guild.name)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setColor('Blue')
        .addFields(
            { name: 'Owner', value: owner.user.tag, inline: true },
            { name: 'Members', value: `${guild.memberCount}`, inline: true },
            { name: 'Created At', value: moment(guild.createdAt).format('LLLL'), inline: false },
            { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
            { name: 'Channels', value: `${guild.channels.cache.size}`, inline: true },
            { name: 'Boosts', value: `${guild.premiumSubscriptionCount}`, inline: true }
        );
    if (context.reply) await context.reply({ embeds: [embed] });
}

async function replyAvatar(context, user) {
    const embed = new EmbedBuilder()
        .setTitle(`Avatar: ${user.tag}`)
        .setImage(user.displayAvatarURL({ dynamic: true, size: 4096 }))
        .setColor('Blue');
    if (context.reply) await context.reply({ embeds: [embed] });
}
