const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, PermissionFlagsBits } = require('discord.js');
const moment = require('moment');

module.exports = [
    // Banner Command
    {
        data: new SlashCommandBuilder()
            .setName('banner')
            .setDescription('Get user or server banner')
            .addUserOption(opt => opt.setName('target').setDescription('The user')),
        async execute(interaction) {
            const target = interaction.options.getUser('target') || interaction.user;
            await replyBanner(interaction, target);
        },
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;
            await replyBanner(message, target);
        }
    },
    // Server Icon Command
    {
        data: new SlashCommandBuilder()
            .setName('servericon')
            .setDescription('Get server icon'),
        async execute(interaction) {
            await replyServerIcon(interaction);
        },
        async executeMessage(message) {
            await replyServerIcon(message);
        }
    },
    // Role Info Command
    {
        data: new SlashCommandBuilder()
            .setName('roleinfo')
            .setDescription('Get information about a role')
            .addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)),
        async execute(interaction) {
            const role = interaction.options.getRole('role');
            await replyRoleInfo(interaction, role);
        },
        async executeMessage(message, args) {
            const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
            if (!role) return message.reply('Please provide a valid role.');
            await replyRoleInfo(message, role);
        }
    },
    // First Message Command
    {
        data: new SlashCommandBuilder()
            .setName('firstmsg')
            .setDescription('Get the first message in this channel'),
        async execute(interaction) {
            await replyFirstMsg(interaction);
        },
        async executeMessage(message) {
            await replyFirstMsg(message);
        }
    },
    // Invite Command
    {
        data: new SlashCommandBuilder()
            .setName('botinvite')
            .setDescription('Get bot invite link'),
        async execute(interaction) {
            await replyInvite(interaction);
        },
        async executeMessage(message) {
            await replyInvite(message);
        }
    }
];

// --- Helpers ---

async function replyBanner(context, user) {
    const fetchedUser = await user.fetch({ force: true }); // Force fetch to get banner
    const bannerUrl = fetchedUser.bannerURL({ dynamic: true, size: 4096 });
    const userDisplay = context.member ? (context.member.user || context.user) : context.author;

    if (!bannerUrl) {
        return context.reply ? context.reply({ content: `${user.tag} does not have a banner.`, ephemeral: true }) : context.channel.send(`${user.tag} does not have a banner.`);
    }

    const embed = new EmbedBuilder()
        .setTitle(`Banner of ${user.tag}`)
        .setImage(bannerUrl)
        .setColor(fetchedUser.hexAccentColor || '#2b2d31')
        .setFooter({ text: `Requested by ${userDisplay.tag}`, iconURL: userDisplay.displayAvatarURL() });

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel('Link').setStyle(ButtonStyle.Link).setURL(bannerUrl)
    );

    if (context.reply) await context.reply({ embeds: [embed], components: [row] });
    else await context.channel.send({ embeds: [embed], components: [row] });
}

async function replyServerIcon(context) {
    const guild = context.guild;
    const icon = guild.iconURL({ dynamic: true, size: 4096 });

    if (!icon) return context.reply ? context.reply('This server has no icon.') : context.channel.send('This server has no icon.');

    const embed = new EmbedBuilder()
        .setTitle(`${guild.name} Icon`)
        .setImage(icon)
        .setColor('#2b2d31');

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel('Link').setStyle(ButtonStyle.Link).setURL(icon)
    );

    if (context.reply) await context.reply({ embeds: [embed], components: [row] });
    else await context.channel.send({ embeds: [embed], components: [row] });
}

async function replyRoleInfo(context, role) {
    const guild = context.guild;
    const created = `<t:${Math.round(role.createdTimestamp / 1000)}:R>`;

    const embed = new EmbedBuilder()
        .setTitle(`Role Info: ${role.name}`)
        .setColor(role.hexColor)
        .addFields(
            { name: 'ID', value: role.id, inline: true },
            { name: 'Color', value: role.hexColor, inline: true },
            { name: 'Position', value: `${role.position}`, inline: true },
            { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
            { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
            { name: 'Managed', value: role.managed ? 'Yes' : 'No', inline: true },
            { name: 'Created', value: created, inline: true },
            { name: 'Permissions', value: role.permissions.toArray().length > 0 ? role.permissions.toArray().map(p => `\`${p}\``).join(', ').slice(0, 1024) : 'None' }
        );

    if (context.reply) await context.reply({ embeds: [embed] });
    else await context.channel.send({ embeds: [embed] });
}

async function replyFirstMsg(context) {
    const channel = context.channel;
    const messages = await channel.messages.fetch({ after: 1, limit: 1 });
    const msg = messages.first();

    if (!msg) return context.reply ? context.reply('Could not find the first message.') : context.channel.send('Could not find the first message.');

    const embed = new EmbedBuilder()
        .setTitle('First Message')
        .setURL(msg.url)
        .setDescription(msg.content || '*(No Content)*')
        .addFields(
            { name: 'Author', value: `${msg.author}`, inline: true },
            { name: 'Sent At', value: `<t:${Math.round(msg.createdTimestamp / 1000)}:F>`, inline: true }
        )
        .setColor('#2b2d31');

    if (context.reply) await context.reply({ embeds: [embed] });
    else await context.channel.send({ embeds: [embed] });
}

async function replyInvite(context) {
    const client = context.client;
    const link = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;

    const embed = new EmbedBuilder()
        .setDescription(`[Click here to invite me](${link})`)
        .setColor('#2b2d31');

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel('Invite Me').setStyle(ButtonStyle.Link).setURL(link)
    );

    if (context.reply) await context.reply({ embeds: [embed], components: [row] });
    else await context.channel.send({ embeds: [embed], components: [row] });
}
