const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const embed = require('../../functions/embedHelper');

const giveawayPath = path.join(__dirname, '../../data/giveaways.json');

function getGiveawayData() {
    if (!fs.existsSync(giveawayPath)) {
        fs.writeFileSync(giveawayPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(giveawayPath, 'utf8'));
}

function setGiveawayData(data) {
    fs.writeFileSync(giveawayPath, JSON.stringify(data, null, 2));
}

const createCommand = (name, description, executeLogic) => ({
    data: new SlashCommandBuilder()
        .setName(name)
        .setDescription(description),
    async execute(interaction) {
        await executeLogic(interaction);
    }
});

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('gcreate')
            .setDescription('Create a giveaway')
            .addStringOption(opt => opt.setName('duration').setDescription('Duration (e.g. 1h, 1d)').setRequired(true))
            .addIntegerOption(opt => opt.setName('winners').setDescription('Number of winners').setRequired(true))
            .addStringOption(opt => opt.setName('prize').setDescription('Giveaway prize').setRequired(true)),
        async execute(interaction) {
            const prize = interaction.options.getString('prize');
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Giveaway Created').setDescription(`Giveaway for **${prize}** has been started!`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply('❌ No access');
            }
            if (args.length < 3) {
                return message.reply({ embeds: [embed.error('Usage: `!gcreate <duration> <winners> <prize>`\nExample: `!gcreate 1d 1 Discord Nitro`')] });
            }
            const duration = args[0];
            const winners = parseInt(args[1]);
            const prize = args.slice(2).join(' ');

            if (isNaN(winners) || winners < 1) {
                return message.reply({ embeds: [embed.error('Winners must be a valid number (1 or more).')] });
            }

            // Parse duration
            const durationMatch = duration.match(/(\d+)([smhd])/);
            if (!durationMatch) {
                return message.reply({ embeds: [embed.error('Invalid duration format. Use: s (seconds), m (minutes), h (hours), d (days)\nExample: `1d` or `12h`')] });
            }
            const durationValue = parseInt(durationMatch[1]);
            const durationUnit = durationMatch[2];
            let milliseconds = 0;
            switch (durationUnit) {
                case 's': milliseconds = durationValue * 1000; break;
                case 'm': milliseconds = durationValue * 60 * 1000; break;
                case 'h': milliseconds = durationValue * 60 * 60 * 1000; break;
                case 'd': milliseconds = durationValue * 24 * 60 * 60 * 1000; break;
            }

            const endTime = Date.now() + milliseconds;
            const endTimestamp = Math.floor(endTime / 1000);

            const giveawayEmbed = new EmbedBuilder()
                .setTitle('New Giveaway 🎉')
                .setDescription(
                    `✅ **${prize}**\n\n` +
                    `• Winner Count : ${winners}\n` +
                    `• Hosted By : ${message.author}\n\n` +
                    `• React with 🎉 to Participate\n\n` +
                    `Ends at • <t:${endTimestamp}:R>`
                )
                .setColor('#2b2d31')
                .setThumbnail('https://cdn.discordapp.com/emojis/1234567890123456789.png'); // Gift icon placeholder

            const giveawayMsg = await message.channel.send({ embeds: [giveawayEmbed] });
            await giveawayMsg.react('🎉');

            const data = getGiveawayData();
            if (!data[message.guild.id]) data[message.guild.id] = {};
            data[message.guild.id][giveawayMsg.id] = {
                prize,
                winners,
                duration,
                channelId: message.channel.id,
                hostId: message.author.id,
                endTime,
                ended: false
            };
            setGiveawayData(data);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('gend')
            .setDescription('End a giveaway')
            .addStringOption(opt => opt.setName('messageid').setDescription('The ID of the giveaway message').setRequired(true)),
        async execute(interaction) {
            await interaction.reply('Ending giveaway...');
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply('❌ No access');
            }
            if (!args[0]) {
                return message.reply('Please provide the giveaway message ID. Usage: `!gend <messageid>`');
            }
            const messageId = args[0];
            const data = getGiveawayData();

            if (!data[message.guild.id] || !data[message.guild.id][messageId]) {
                return message.reply('Giveaway not found.');
            }

            const giveaway = data[message.guild.id][messageId];
            const channel = message.guild.channels.cache.get(giveaway.channelId);
            if (!channel) {
                return message.reply('Giveaway channel not found.');
            }

            try {
                const giveawayMsg = await channel.messages.fetch(messageId);
                const reaction = giveawayMsg.reactions.cache.get('🎉');
                if (reaction) {
                    const users = await reaction.users.fetch();
                    const entries = users.filter(u => !u.bot);
                    const winners = entries.random(Math.min(giveaway.winners, entries.size));

                    const endEmbed = new EmbedBuilder()
                        .setTitle('🎉 GIVEAWAY ENDED 🎉')
                        .setDescription(`**Prize:** ${giveaway.prize}\n**Winners:** ${winners.map(w => w.toString()).join(', ') || 'No valid entries'}`).setColor('#ff0000')
                        .setTimestamp();

                    await giveawayMsg.edit({ embeds: [endEmbed] });
                    if (winners.size > 0) {
                        await channel.send(`Congratulations ${winners.map(w => w.toString()).join(', ')}! You won **${giveaway.prize}**!`);
                    }
                }

                data[message.guild.id][messageId].ended = true;
                setGiveawayData(data);
                const reply = await message.reply('✅ Giveaway ended!');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply('Failed to end giveaway.');
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('greroll')
            .setDescription('Reroll a giveaway')
            .addStringOption(opt => opt.setName('messageid').setDescription('The ID of the giveaway message').setRequired(true)),
        async execute(interaction) {
            await interaction.reply('Rerolling giveaway...');
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply('❌ No access');
            }
            if (!args[0]) {
                return message.reply('Please provide the giveaway message ID. Usage: `!greroll <messageid>`');
            }
            const messageId = args[0];
            const data = getGiveawayData();

            if (!data[message.guild.id] || !data[message.guild.id][messageId]) {
                return message.reply('Giveaway not found.');
            }

            const giveaway = data[message.guild.id][messageId];
            const channel = message.guild.channels.cache.get(giveaway.channelId);
            if (!channel) {
                return message.reply('Giveaway channel not found.');
            }

            try {
                const giveawayMsg = await channel.messages.fetch(messageId);
                const reaction = giveawayMsg.reactions.cache.get('🎉');
                if (reaction) {
                    const users = await reaction.users.fetch();
                    const entries = users.filter(u => !u.bot);
                    const winners = entries.random(Math.min(giveaway.winners, entries.size));

                    if (winners.size > 0) {
                        await channel.send(`🎉 New winner(s): ${winners.map(w => w.toString()).join(', ')}! You won **${giveaway.prize}**!`);
                        const reply = await message.reply('✅ Giveaway rerolled!');
                        setTimeout(() => reply.delete().catch(() => { }), 3000);
                    } else {
                        return message.reply('No valid entries to reroll.');
                    }
                } else {
                    return message.reply('No reactions found on giveaway.');
                }
            } catch (error) {
                console.error(error);
                return message.reply('Failed to reroll giveaway.');
            }
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('glist')
            .setDescription('List all active giveaways'),
        async execute(interaction) {
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Active Giveaways').setDescription('No active giveaways found.').setColor('#000000')] });
        },
        async executeMessage(message, args) {
            const data = getGiveawayData();
            const guildGiveaways = data[message.guild.id] || {};
            const active = Object.entries(guildGiveaways)
                .filter(([id, g]) => !g.ended)
                .map(([id, g]) => `**Prize:** ${g.prize}\n**Channel:** <#${g.channelId}>\n**ID:** ${id}`);

            const listEmbed = new EmbedBuilder()
                .setTitle('Active Giveaways')
                .setDescription(active.length > 0 ? active.join('\n\n') : 'No active giveaways.')
                .setColor('#2b2d31');
            return message.reply({ embeds: [listEmbed] });
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('gdelete')
            .setDescription('Delete a giveaway')
            .addStringOption(opt => opt.setName('messageid').setDescription('The ID of the giveaway message').setRequired(true)),
        async execute(interaction) {
            await interaction.reply('Deleting giveaway...');
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply('❌ No access');
            }
            if (!args[0]) {
                return message.reply('Please provide the giveaway message ID. Usage: `!gdelete <messageid>`');
            }
            const messageId = args[0];
            const data = getGiveawayData();

            if (!data[message.guild.id] || !data[message.guild.id][messageId]) {
                return message.reply('Giveaway not found.');
            }

            const giveaway = data[message.guild.id][messageId];
            const channel = message.guild.channels.cache.get(giveaway.channelId);

            try {
                if (channel) {
                    const giveawayMsg = await channel.messages.fetch(messageId).catch(() => null);
                    if (giveawayMsg) await giveawayMsg.delete();
                }
                delete data[message.guild.id][messageId];
                setGiveawayData(data);
                const reply = await message.reply('✅ Giveaway deleted!');
                setTimeout(() => reply.delete().catch(() => { }), 3000);
            } catch (error) {
                console.error(error);
                return message.reply('Failed to delete giveaway.');
            }
        }
    }
];
