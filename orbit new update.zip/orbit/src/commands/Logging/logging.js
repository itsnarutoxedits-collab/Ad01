const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const permissionChecker = require('../../functions/permissionChecker');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('logging')
        .setDescription('Configure server logging')
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a logging configuration'))
        .addSubcommand(sub => sub.setName('status').setDescription('Show logging status'))
        .addSubcommand(sub => sub.setName('wizard').setDescription('Start the logging setup wizard'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable logging module'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable logging module'))
        .addSubcommandGroup(group => group.setName('setup').setDescription('Setup logging channels')
            .addSubcommand(sub => sub.setName('clear').setDescription('Clear logging setup'))
            .addSubcommand(sub => sub.setName('channel').setDescription('Set a channel for a log type').addStringOption(opt => opt.setName('type').setDescription('Log type').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('auto').setDescription('Auto-setup all logging channels')))
        .addSubcommandGroup(group => group.setName('ignore').setDescription('Manage logging ignore list')
            .addSubcommand(sub => sub.setName('channel').setDescription('Ignore a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('show').setDescription('Show ignore list'))
            .addSubcommand(sub => sub.setName('user').setDescription('Ignore a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('embed').setDescription('Ignore embeds in a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('role').setDescription('Ignore a role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
            .addSubcommand(sub => sub.setName('voice').setDescription('Ignore voice actions in a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove an ignore rule').addStringOption(opt => opt.setName('id').setDescription('The ID to remove').setRequired(true)))),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Logging System').setDescription(`Executed logging command: **${path}**`).setColor('#000000')] });
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **logging setup**\n› Setup logging channels.\n\n` +
                `» **logging ignore**\n› Manage ignore list.\n\n` +
                `» **logging enable/disable**\n› Enable/Disable module.\n\n` +
                `» **logging status**\n› Show status.\n\n` +
                `» **logging wizard**\n› Start setup wizard.\n\n` +
                `» **logging remove**\n› Remove configuration.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['setup', 'ignore', 'status', 'wizard', 'enable', 'disable', 'remove'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/logging.json');
        
        let data = {};
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }
        
        const guildId = message.guild.id;
        if (!data[guildId]) data[guildId] = { enabled: false, channels: {} };

        // Check if user has permission (Owner, Extra Owner, or Administrator)
        if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
            return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
        }

        if (subcommand === 'setup') {
            const setupSub = args[1] ? args[1].toLowerCase() : 'help';
            
            if (setupSub === 'help' || !['channel', 'clear', 'auto'].includes(setupSub)) {
                const setupEmbed = new EmbedBuilder()
                    .setDescription(
                        `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                        `» **logging setup channel <type> #channel**\n› Set log channel for specific type.\n\n` +
                        `» **logging setup clear**\n› Clear all logging setup.\n\n` +
                        `» **logging setup auto**\n› Auto-setup all logging channels.`
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [setupEmbed] });
            }

            if (setupSub === 'clear') {
                data[guildId].channels = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ Cleared all logging channel configurations.')] });
            }

            if (setupSub === 'auto') {
                // Create logging channels automatically with proper permissions
                try {
                    const types = ['message', 'member', 'voice', 'server', 'moderation'];
                    for (const type of types) {
                        const channel = await message.guild.channels.create({
                            name: `${type}-logs`,
                            type: 0,
                            reason: 'Auto-setup logging channels',
                            permissionOverwrites: [
                                {
                                    id: message.guild.id, // @everyone role
                                    deny: ['ViewChannel', 'SendMessages']
                                },
                                {
                                    id: message.client.user.id, // Bot
                                    allow: ['ViewChannel', 'SendMessages', 'EmbedLinks']
                                },
                                {
                                    id: message.guild.ownerId, // Server owner
                                    allow: ['ViewChannel', 'SendMessages', 'ManageChannels']
                                }
                            ]
                        });
                        data[guildId].channels[type] = channel.id;
                    }
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                    return message.reply({ embeds: [embedHelper.success('✅ Auto-setup completed! Created 5 locked logging channels.')] });
                } catch (error) {
                    console.error('Logging auto-setup error:', error);
                    return message.reply({ embeds: [embedHelper.error('❌ Failed to auto-setup channels. Check bot permissions.')] });
                }
            }

            if (setupSub === 'channel') {
                const logType = args[2];
                const channel = message.mentions.channels.first();
                
                if (!logType) return message.reply({ embeds: [embedHelper.info('Please provide a log type. Example: `!logging setup channel message #logs`')] });
                if (!channel) return message.reply({ embeds: [embedHelper.info('Please mention a channel. Example: `!logging setup channel message #logs`')] });
                
                data[guildId].channels[logType] = channel.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Set ${logType} logs to ${channel}`)] });
            }
        }

        if (subcommand === 'ignore') {
            const ignoreSub = args[1] ? args[1].toLowerCase() : 'help';
            
            if (ignoreSub === 'help' || !['channel', 'user', 'role', 'voice', 'embed', 'show', 'remove'].includes(ignoreSub)) {
                const ignoreEmbed = new EmbedBuilder()
                    .setDescription(
                        `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                        `» **logging ignore channel #channel**\n› Ignore logging in a channel.\n\n` +
                        `» **logging ignore user @user**\n› Ignore a user's actions.\n\n` +
                        `» **logging ignore role @role**\n› Ignore a role's actions.\n\n` +
                        `» **logging ignore show**\n› Show ignore list.\n\n` +
                        `» **logging ignore remove <id>**\n› Remove from ignore list.`
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [ignoreEmbed] });
            }

            if (!data[guildId].ignores) data[guildId].ignores = [];

            if (ignoreSub === 'show') {
                if (!data[guildId].ignores.length) return message.reply({ embeds: [embedHelper.info('No ignores configured.')] });
                return message.reply(`**Ignored IDs**: ${data[guildId].ignores.map(id => `\`${id}\``).join(', ')}`);
            }

            if (ignoreSub === 'remove') {
                const id = args[2];
                if (!id) return message.reply({ embeds: [embedHelper.info('Please provide an ID to remove. Example: `!logging ignore remove 123456789`')] });
                data[guildId].ignores = data[guildId].ignores.filter(i => i !== id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Removed \`${id}\` from ignore list.`)] });
            }

            if (ignoreSub === 'channel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Please mention a channel. Example: `!logging ignore channel #general`')] });
                if (data[guildId].ignores.includes(channel.id)) return message.reply('This channel is already ignored.');
                data[guildId].ignores.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${channel} to ignore list.`)] });
            }

            if (ignoreSub === 'user') {
                const user = message.mentions.users.first();
                if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user. Example: `!logging ignore user @User`')] });
                if (data[guildId].ignores.includes(user.id)) return message.reply('This user is already ignored.');
                data[guildId].ignores.push(user.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${user} to ignore list.`)] });
            }

            if (ignoreSub === 'role') {
                const role = message.mentions.roles.first();
                if (!role) return message.reply({ embeds: [embedHelper.info('Please mention a role. Example: `!logging ignore role @Role`')] });
                if (data[guildId].ignores.includes(role.id)) return message.reply('This role is already ignored.');
                data[guildId].ignores.push(role.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${role} to ignore list.`)] });
            }

            if (ignoreSub === 'voice') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Please mention a voice channel. Example: `!logging ignore voice #VC`')] });
                if (data[guildId].ignores.includes(channel.id)) return message.reply('This channel is already ignored.');
                data[guildId].ignores.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added voice channel ${channel} to ignore list.`)] });
            }

            if (ignoreSub === 'embed') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Please mention a channel. Example: `!logging ignore embed #channel`')] });
                if (data[guildId].ignores.includes(`embed_${channel.id}`)) return message.reply('Embeds in this channel are already ignored.');
                data[guildId].ignores.push(`embed_${channel.id}`);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Ignoring embeds in ${channel}.`)] });
            }
        }

        if (subcommand === 'wizard') {
            return message.reply({ embeds: [embedHelper.info('The wizard with interactive prompts is best used via slash command: `/logging wizard`')] });
        }

        if (subcommand === 'enable') {
            data[guildId].enabled = true;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Logging module has been enabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'disable') {
            data[guildId].enabled = false;
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply('✅ Logging module has been disabled.');
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        if (subcommand === 'status') {
            const cfg = data[guildId];
            const channelList = Object.entries(cfg.channels || {}).map(([type, id]) => `${type}: <#${id}>`).join('\n') || 'None';
            const statusEmbed = new EmbedBuilder()
                .setTitle('Logging Status')
                .addFields(
                    { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: 'Configured', value: Object.keys(cfg.channels || {}).length.toString(), inline: true },
                    { name: 'Channels', value: channelList }
                )
                .setColor('#2b2d31');
            return message.reply({ embeds: [statusEmbed] });
        }

        if (subcommand === 'remove') {
            data[guildId] = { enabled: false, channels: {} };
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            const reply = await message.reply({ embeds: [embedHelper.success('✅ Logging configuration has been removed.')] });
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        return message.reply({ embeds: [embedHelper.default(`Subcommand \`${subcommand}\` executed successfully.`)] });
    }
};
