const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const permit = require('../../functions/permitManager');
const embed = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('trusted')
        .setDescription('Permit: Manage trusted users')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a trusted user').addUserOption(opt => opt.setName('user').setDescription('The user to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a trusted user').addUserOption(opt => opt.setName('user').setDescription('The user to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all trusted users'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all trusted users')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // Permission check: Owner or ExtraOwner
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: 'Only the server owner or extra owners can use this command.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'add') {
            const user = interaction.options.getUser('user');
            const added = permit.addEntry(guildId, 'trusted', user.id);
            return interaction.reply({ content: added ? `Successfully added **${user.tag}** to trusted users.` : `**${user.tag}** is already trusted.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'remove') {
            const user = interaction.options.getUser('user');
            const removed = permit.removeEntry(guildId, 'trusted', user.id);
            return interaction.reply({ content: removed ? `Successfully removed **${user.tag}** from trusted users.` : `**${user.tag}** is not a trusted user.`, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'reset') {
            permit.resetList(guildId, 'trusted');
            return interaction.reply({ content: 'Successfully reset all trusted users.', flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'show') {
            const trusted = permit.getEntries(guildId, 'trusted');
            if (trusted.length === 0) return interaction.reply({ content: 'No trusted users configured.', flags: MessageFlags.Ephemeral });

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(trusted.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = trusted.slice(start, end);

                return new EmbedBuilder()
                    .setTitle('Trusted Users')
                    .setDescription(current.map(id => `<@${id}> (${id})`).join('\n'))
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1}/${totalPages} | Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('prev').setEmoji('⬅️').setStyle(ButtonStyle.Secondary).setDisabled(p === 0),
                    new ButtonBuilder().setCustomId('next').setEmoji('➡️').setStyle(ButtonStyle.Secondary).setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const response = await interaction.reply({ embeds: [getEmbed(page)], components: getButtons(page), flags: MessageFlags.Ephemeral });
            if (totalPages > 1) {
                const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
                collector.on('collect', async i => {
                    if (i.customId === 'prev') page--;
                    else page++;
                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });
                collector.on('end', () => interaction.editReply({ components: [] }).catch(() => { }));
            }
        }
    },

    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const guildId = message.guild.id;

        const helpEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **trusted add**\n› Add an trusted user for this server.\n\n` +
                `» **trusted remove**\n› Remove an trusted user from this server.\n\n` +
                `» **trusted reset**\n› Removes all trusted users from this server.\n\n` +
                `» **trusted show**\n› Show all trusted users for this server.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'reset', 'show'].includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed] });
        }

        // Permission check: Owner or ExtraOwner
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(guildId, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embed.error('Only the server owner or extra owners can use this command.')] });
        }

        if (subcommand === 'add') {
            const user = message.mentions.users.first() || (args[1] ? { id: args[1], tag: args[1] } : null);
            if (!user) return message.reply({ embeds: [embed.error('Please mention a user or provide a valid ID.')] });
            const added = permit.addEntry(guildId, 'trusted', user.id);
            return message.reply({ embeds: [added ? embed.success(`Successfully added **${user.tag || user.id}** to trusted users.`) : embed.info(`User is already trusted.`)] });
        }

        if (subcommand === 'remove') {
            const user = message.mentions.users.first() || (args[1] ? { id: args[1], tag: args[1] } : null);
            if (!user) return message.reply({ embeds: [embed.error('Please mention a user or provide a valid ID.')] });
            const removed = permit.removeEntry(guildId, 'trusted', user.id);
            return message.reply({ embeds: [removed ? embed.success(`Successfully removed **${user.tag || user.id}** from trusted users.`) : embed.info(`User is not trusted.`)] });
        }

        if (subcommand === 'reset') {
            permit.resetList(guildId, 'trusted');
            return message.reply({ embeds: [embed.success('Successfully reset all trusted users.')] });
        }

        if (subcommand === 'show') {
            const trusted = permit.getEntries(guildId, 'trusted');
            if (trusted.length === 0) return message.reply({ embeds: [embed.info('No trusted users configured.')] });

            let page = 0;
            const perPage = 10;
            const totalPages = Math.ceil(trusted.length / perPage);

            const getEmbed = (p) => {
                const start = p * perPage;
                const end = start + perPage;
                const current = trusted.slice(start, end);

                return new EmbedBuilder()
                    .setTitle('Trusted Users')
                    .setDescription(current.map(id => `<@${id}> (${id})`).join('\n'))
                    .setColor('#2b2d31')
                    .setFooter({ text: `Page ${p + 1}/${totalPages} | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            };

            const getButtons = (p) => {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('prev').setEmoji('⬅️').setStyle(ButtonStyle.Secondary).setDisabled(p === 0),
                    new ButtonBuilder().setCustomId('next').setEmoji('➡️').setStyle(ButtonStyle.Secondary).setDisabled(p === totalPages - 1)
                );
                return totalPages > 1 ? [row] : [];
            };

            const msg = await message.reply({ embeds: [getEmbed(page)], components: getButtons(page) });
            if (totalPages > 1) {
                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 30000 });
                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) return i.reply({ content: "This button is not for you.", flags: MessageFlags.Ephemeral });
                    if (i.customId === 'prev') page--;
                    else page++;
                    await i.update({ embeds: [getEmbed(page)], components: getButtons(page) });
                });
                collector.on('end', () => msg.edit({ components: [] }).catch(() => { }));
            }
        }
    }
};
