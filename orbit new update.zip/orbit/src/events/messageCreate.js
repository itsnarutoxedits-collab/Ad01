const { EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const automod = require('../functions/automodManager');
const permit = require('../functions/permitManager');
const afk = require('../functions/afkManager');
const fs = require('fs');
const path = require('path');


module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (message.author.bot || !message.guild) return;

        // --- STICKY MESSAGES ---
        try {
            const fs = require('fs');
            const path = require('path');
            const stickyPath = path.join(__dirname, '../data/sticky.json');
            if (fs.existsSync(stickyPath)) {
                const stickyData = JSON.parse(fs.readFileSync(stickyPath, 'utf8'));
                if (stickyData[message.guild.id] && stickyData[message.guild.id][message.channel.id]) {
                    const channelData = stickyData[message.guild.id][message.channel.id];

                    // Delete old sticky
                    if (channelData.lastMessageId) {
                        const oldMsg = await message.channel.messages.fetch(channelData.lastMessageId).catch(() => { });
                        if (oldMsg) await oldMsg.delete().catch(() => { });
                    }

                    // Send new sticky
                    const newMsg = await message.channel.send(channelData.message);

                    // Update ID
                    channelData.lastMessageId = newMsg.id;
                    fs.writeFileSync(stickyPath, JSON.stringify(stickyData, null, 2));
                }
            }
        } catch (e) {
            console.error('Sticky Message Error:', e);
        }

        // --- DYNAMIC CUSTOM ROLES ---
        try {
            const fs = require('fs');
            const crPath = path.join(__dirname, '../data/customrole.json');
            if (fs.existsSync(crPath)) {
                const crData = JSON.parse(fs.readFileSync(crPath, 'utf8'));
                const guildData = crData[message.guild.id];

                let prefix = '!';
                try {
                    const prefixManager = require('../functions/prefixManager');
                    prefix = await prefixManager.getPrefix(message.guild.id);
                } catch (e) { }

                const usedPrefix = prefix;
                // Actually, let's check if prefix is available.

                if (guildData && guildData.names) {
                    const args = message.content.trim().split(/ +/);
                    // Simple check for now: starts with '!' or prefix logic
                    // Assuming prefix '!' for custom roles if not found.
                    // But to be safe, I'll rely on the command handling logic if I can find where prefix is parsed.
                    // messageCreate lines viewed earlier don't show prefix definition in the scope I'm pasting into.
                    // I will duplicate prefix fetching or just use message.content.startsWith check if I can assume standard prefix.

                    // Bitzxier uses: message.guild.prefix

                    const usedPrefix = "!"; // Default for now to avoid breakage.
                    if (message.content.startsWith(usedPrefix)) {
                        const cmdName = args[0].slice(usedPrefix.length).toLowerCase();
                        if (guildData.names.includes(cmdName)) {
                            const idx = guildData.names.indexOf(cmdName);
                            const roleId = guildData.roles[idx];
                            const reqRole = guildData.reqrole;

                            if (reqRole && !message.member.roles.cache.has(reqRole)) {
                                return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setDescription(`❌ You need <@&${reqRole}> to use custom roles.`)] });
                            }

                            const role = message.guild.roles.cache.get(roleId);
                            if (!role) return message.reply('❌ Role not found.');

                            const targetMember = message.mentions.members.first();
                            if (!targetMember) return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setDescription('Usage: `!<role> @user`')] });

                            if (targetMember.roles.cache.has(role.id)) {
                                await targetMember.roles.remove(role);
                                return message.reply({ embeds: [new EmbedBuilder().setColor('Green').setDescription(`Removed ${role} from ${targetMember}.`)] });
                            } else {
                                await targetMember.roles.add(role);
                                return message.reply({ embeds: [new EmbedBuilder().setColor('Green').setDescription(`Added ${role} to ${targetMember}.`)] });
                            }
                        }
                    }
                }
            }
        } catch (e) { console.error('Custom Role Error:', e); }

        // --- AFK: Check if user is AFK and remove status ---
        const userAfk = afk.getAFK(message.author.id);
        if (userAfk) {
            afk.removeAFK(message.author.id);
            const duration = Date.now() - userAfk.timestamp;
            const minutes = Math.floor(duration / 60000);
            const timeStr = minutes > 0 ? `${minutes}m` : 'just now';
            await message.reply(`Welcome back! Your AFK status has been removed (was AFK for ${timeStr}).`).catch(() => { });
        }

        // --- AFK: Check mentions for AFK users ---
        for (const user of message.mentions.users.values()) {
            if (user.bot) continue;
            const mentionedAfk = afk.getAFK(user.id);
            if (mentionedAfk) {
                const duration = Date.now() - mentionedAfk.timestamp;
                const minutes = Math.floor(duration / 60000);
                const timeStr = minutes > 0 ? `${minutes}m ago` : 'just now';
                await message.reply(`${user.username} is currently AFK: ${mentionedAfk.reason} (${timeStr})`).catch(() => { });
                break; // Only reply once per message
            }
        }

        // --- AUTORESPONDER: Check for triggers ---
        const autoresponderPath = path.join(__dirname, '../data/autoresponder.json');
        if (fs.existsSync(autoresponderPath)) {
            try {
                const arData = JSON.parse(fs.readFileSync(autoresponderPath, 'utf8'));
                const arConfig = arData[message.guild.id];
                if (arConfig && arConfig.enabled && arConfig.responders) {
                    // Check ignore list
                    const arIgnore = arConfig.ignore || { users: [], channels: [] };
                    const isIgnored = arIgnore.users.includes(message.author.id) || arIgnore.channels.includes(message.channel.id);

                    if (!isIgnored) {
                        const content = message.content.toLowerCase();
                        for (const responder of arConfig.responders) {
                            if (!responder.enabled) continue;
                            if (content.includes(responder.trigger.toLowerCase())) {
                                await message.reply(responder.response).catch(() => { });
                                break; // Only respond once per message
                            }
                        }
                    }
                }
            } catch (e) { console.error('Autoresponder error:', e); }
        }

        // --- AUTOREACT: Check for triggers ---
        const autoreactPath = path.join(__dirname, '../data/autoreact.json');
        if (fs.existsSync(autoreactPath)) {
            try {
                const reactData = JSON.parse(fs.readFileSync(autoreactPath, 'utf8'));
                const reactConfig = reactData[message.guild.id];
                if (reactConfig && reactConfig.enabled && reactConfig.reactions) {
                    // Check ignore list
                    const reactIgnore = reactConfig.ignore || { users: [], channels: [] };
                    const isIgnored = reactIgnore.users.includes(message.author.id) || reactIgnore.channels.includes(message.channel.id);

                    if (!isIgnored) {
                        const content = message.content.toLowerCase();
                        for (const reaction of reactConfig.reactions) {
                            if (!reaction.enabled) continue;
                            if (content.includes(reaction.trigger.toLowerCase())) {
                                await message.react(reaction.emoji).catch(() => { });
                            }
                        }
                    }
                }
            } catch (e) { console.error('Autoreact error:', e); }
        }


        // --- AUTOMOD: Blacklist Words Check ---
        const amConfig = automod.getGuildData(message.guild.id);
        const blacklist = amConfig.blacklist || { words: [], punishment: 'mute', whitelisted_channels: [], whitelisted_roles: [] };

        if (blacklist.words.length > 0) {
            // Check Exemptions
            const isOwner = message.author.id === message.guild.ownerId;
            const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
            const isChannelWl = blacklist.whitelisted_channels.includes(message.channel.id);
            const isRoleWl = blacklist.whitelisted_roles.some(rid => message.member.roles.cache.has(rid));

            if (!isOwner && !isEO && !isChannelWl && !isRoleWl) {
                const content = message.content.toLowerCase();

                // Improved matching logic:
                // 1) Exact phrase match for entries containing spaces
                // 2) Whole-word match (\bword\b) for single words
                // 3) Normalized fallback: remove non-alphanumerics and check includes for longer tokens (>=4 chars)
                function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&'); }
                const normalizedContent = content.replace(/[^a-z0-9]/g, '');
                let caught = null;
                for (const w of blacklist.words) {
                    const lw = String(w || '').toLowerCase().trim();
                    if (!lw) continue;

                    if (/\s/.test(lw)) {
                        // If blacklist entry is a phrase, do a simple substring check
                        if (content.includes(lw)) {
                            caught = w;
                            break;
                        }
                    } else {
                        // Whole-word match first
                        const wordRe = new RegExp(`\\b${escapeRegex(lw)}\\b`, 'i');
                        const wordReMatches = !!wordRe.test(content);

                        // Normalized fallback: remove punctuation/whitespace and check contains
                        const nw = lw.replace(/[^a-z0-9]/g, '');
                        const normalizedIncludes = (nw.length >= 4) && normalizedContent.includes(nw);

                        // Extra fallback: stripped-spaces content includes (defensive)
                        const strippedSpaces = content.replace(/\s+/g, '');
                        const spaceStrippedIncludes = (nw.length >= 3) && strippedSpaces.includes(nw);



                        if (wordReMatches) {
                            caught = w;
                            break;
                        }

                        if (normalizedIncludes || spaceStrippedIncludes) {
                            caught = w;
                            break;
                        }
                    }
                }


                if (caught) {
                    // Action
                    try {
                        if (message.deletable) {
                            await message.delete();
                        }
                        const warning = await message.channel.send({ content: `${message.author}, that word is not allowed here!` });
                        setTimeout(() => warning.delete().catch(() => { }), 5000);

                        // Punishment Logic (Basic)
                        /* 
                        if (blacklist.punishment === 'mute') { ... } 
                        (Implementing basic deletion/warn for now as per "checking messages" request)
                        */
                        return; // Stop processing
                    } catch (e) {
                        console.error('Automod action failed:', e);
                    }
                }
            }
        }

        // --- AUTOMOD: Extended Filters Check ---
        const filters = amConfig.filters || {};

        // Check Exemptions (Owner, EO, Whitelisted Roles/Channels/Users)
        // Re-using exemption checks from blacklist section
        const blacklistExempt = blacklist.whitelisted_channels.includes(message.channel.id) ||
            blacklist.whitelisted_roles.some(rid => message.member.roles.cache.has(rid));

        const isExempt = message.author.id === message.guild.ownerId ||
            permit.isExtraOwner(message.guild.id, message.author.id) ||
            permit.isUserInList(message.guild.id, 'ignore_bypass', message.author.id) ||
            permit.isUserInList(message.guild.id, 'ignore_user', message.author.id) ||
            permit.getEntries(message.guild.id, 'ignore_role').some(rId => message.member.roles.cache.has(rId)) || // Fix: use some() for roles
            blacklistExempt; // Using blacklist whitelist as a proxy if no specific filter whitelist exists yet

        if (!isExempt) {
            let triggered = null;
            const content = message.content;

            // 1. Anti-Link
            if (filters.links?.enabled) {
                if (/(https?:\/\/[^\s]+)/g.test(content)) triggered = 'Links are not allowed.';
            }

            // 2. Anti-Invite
            if (!triggered && filters.invites?.enabled) {
                if (/(discord\.(gg|io|me|li)|discord\.com\/invite)\/.+/i.test(content)) triggered = 'Discord invites are not allowed.';
            }

            // 3. Anti-Mention
            if (!triggered && filters.mentions?.enabled) {
                const limit = filters.mentions.threshold || 5;
                if (message.mentions.users.size > limit) triggered = `Too many mentions (Limit: ${limit}).`;
            }

            // 4. Anti-Caps
            if (!triggered && filters.caps?.enabled) {
                const limit = filters.caps.threshold || 70;
                if (content.length > 10) { // Min length to trigger
                    const capsCount = content.replace(/[^A-Z]/g, "").length;
                    const percent = (capsCount / content.length) * 100;
                    if (percent > limit) triggered = `Too many caps (Limit: ${limit}%).`;
                }
            }

            // 5. Anti-Spoiler
            if (!triggered && filters.spoilers?.enabled) {
                const limit = filters.spoilers.threshold || 3;
                const spoilerCount = (content.match(/\|\|.*?\|\|/g) || []).length;
                if (spoilerCount > limit) triggered = `Too many spoilers (Limit: ${limit}).`;
            }

            // 6. Anti-Newlines
            if (!triggered && filters.newlines?.enabled) {
                const limit = filters.newlines.threshold || 10;
                const newlineCount = (content.match(/\n/g) || []).length;
                if (newlineCount > limit) triggered = `Too many newlines (Limit: ${limit}).`;
            }

            if (triggered) {
                try {
                    if (message.deletable) await message.delete();
                    const warning = await message.channel.send(`${message.author}, ${triggered}`);
                    setTimeout(() => warning.delete().catch(() => { }), 5000);
                    return;
                } catch (e) {
                    console.error('Automod extended filter action failed:', e);
                }
            }
        }

        // --- MEDIA CHANNELS: Enforce Attachments Only ---
        const mediaPath = path.join(__dirname, '../data/media.json');

        if (fs.existsSync(mediaPath) && !message.author.bot) {
            try {
                const mediaData = JSON.parse(fs.readFileSync(mediaPath, 'utf8'));
                const guildMediaConfig = mediaData[message.guild.id];

                // console.log(`DEBUG: Checking media for channel ${message.channel.id} in guild ${message.guild.id}`);

                if (guildMediaConfig && guildMediaConfig.channels.includes(message.channel.id)) {
                    // Check Bypasses
                    const isBypassedUser = guildMediaConfig.bypassUsers.includes(message.author.id);
                    const isBypassedRole = guildMediaConfig.bypassRoles.some(rId => message.member.roles.cache.has(rId));
                    // Strict Parity with Bitzxier: No implicit Owner/Admin bypass.
                    // To bypass, users/roles must be explicitly whitelisted.
                    /*
                    const isOwner = message.author.id === message.guild.ownerId;
                    const isAdmin = message.member.permissions.has(PermissionFlagsBits.Administrator);
                    */

                    /*
                    console.log('DEBUG: Media Channel Hit', {
                        user: message.author.tag,
                        isBypassedUser,
                        isBypassedRole,
                        // isOwner,
                        // isAdmin,
                        hasAttachment: message.attachments.size > 0
                    });
                    */

                    // if (!isBypassedUser && !isBypassedRole && !isOwner && !isAdmin) {
                    if (!isBypassedUser && !isBypassedRole) {
                        // Check for attachments ONLY (Bitzxier parity)
                        const hasAttachment = message.attachments.size > 0;
                        // const hasLink = /(https?:\/\/[^\s]+)/g.test(message.content); 

                        if (!hasAttachment) { // Removed !hasLink
                            if (message.deletable) await message.delete();
                            const warning = await message.channel.send(`${message.author}, this channel is media-only! Please post images.`);
                            // Bitzxier message: "You are not allowed to send messages here without attachments."
                            setTimeout(() => warning.delete().catch(() => { }), 4000);
                            return;
                        }
                    }
                }

            } catch (e) {
                console.error('Media channel check failed:', e);
            }
        }

        // Get guild-specific prefixes or use default
        const prefixPath = path.join(__dirname, '../data/prefix.json');
        const defaultPrefix = process.env.PREFIX || '!';

        let guildPrefixes = [defaultPrefix];
        try {
            if (fs.existsSync(prefixPath)) {
                const prefixData = JSON.parse(fs.readFileSync(prefixPath, 'utf8'));
                if (prefixData[message.guild.id] && prefixData[message.guild.id].prefixes) {
                    guildPrefixes = prefixData[message.guild.id].prefixes;
                }
            }
        } catch (e) {
            // Use default prefix if there's an error
        }

        // Check for mention-based prefixless invocation (only allowed for users in the server's no-prefix list)
        try {
            const noprefixMgr = require('../functions/noprefixManager');
            const mentionRegex = new RegExp(`^<@!?${client.user.id}>\\s*`);
            if (mentionRegex.test(message.content)) {
                const after = message.content.replace(mentionRegex, '').trim();
                if (after) {
                    const mentionArgs = after.split(/ +/);
                    const mentionCommandName = mentionArgs.shift().toLowerCase();

                    const gid = message.guild.id;
                    const uid = message.author.id;

                    // Only allow if user is in the no-prefix list for this guild
                    if (noprefixMgr.hasUser(gid, uid)) {
                        const command = client.commands.get(mentionCommandName);
                        if (command) {
                            // Reuse same permission checks as prefix commands
                            if (!permit.isUserInList(gid, 'ignore_bypass', uid)) {
                                if (permit.isUserInList(gid, 'ignore_user', uid)) return;
                                if (permit.isUserInList(gid, 'ignore_channel', message.channel.id)) return;
                                const ignoredRoles = permit.getEntries(gid, 'ignore_role');
                                if (ignoredRoles.some(roleId => message.member.roles.cache.has(roleId))) return;
                                if (permit.isUserInList(gid, 'ignore_command', mentionCommandName)) return;
                            }

                            // Only support prefix-style (message) handlers for now
                            if (typeof command.executeMessage === 'function') {
                                try {
                                    return await command.executeMessage(message, mentionArgs);
                                } catch (err) {
                                    console.error(`Error in executeMessage for mention-invoked ${mentionCommandName}:`, err);
                                    return message.reply({ content: 'There was an error while executing the command.' });
                                }
                            }
                        }
                    }
                }
            }
        } catch (e) {
            console.error('Error handling mention-based no-prefix invocation:', e);
        }

        // Check if message starts with any of the guild's prefixes
        const usedPrefix = guildPrefixes.find(prefix => message.content.startsWith(prefix));

        let commandName = null;
        let args = [];

        if (usedPrefix) {
            args = message.content.slice(usedPrefix.length).trim().split(/ +/);
            commandName = args.shift().toLowerCase();
        } else {
            // Check for No Prefix Access (if no prefix was used)
            try {
                const noprefixMgr = require('../functions/noprefixManager');
                if (noprefixMgr.hasUser(message.guild.id, message.author.id)) {
                    const rawArgs = message.content.trim().split(/ +/);
                    const potentialName = rawArgs[0].toLowerCase();
                    // Validate command existence to prevent spamming logs or false positives
                    const potentialCmd = client.commands.get(potentialName) ||
                        client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(potentialName));
                    if (potentialCmd) {
                        commandName = potentialName;
                        args = rawArgs.slice(1);
                    }
                }
            } catch (e) {
                // Ignore errors in noprefix check
            }
        }

        if (!commandName) return;

        const command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
        if (!command) return;

        const gid = message.guild.id;
        const uid = message.author.id;

        // 1. Bypass check
        if (!permit.isUserInList(gid, 'ignore_bypass', uid)) {
            // 2. User ignore
            if (permit.isUserInList(gid, 'ignore_user', uid)) return;
            // 3. Channel ignore
            if (permit.isUserInList(gid, 'ignore_channel', message.channel.id)) return;
            // 4. Role ignore
            const memberRoles = message.member.roles.cache.keys();
            const ignoredRoles = permit.getEntries(gid, 'ignore_role');
            if (ignoredRoles.some(roleId => message.member.roles.cache.has(roleId))) return;
            // 5. Command ignore
            if (permit.isUserInList(gid, 'ignore_command', commandName)) return;
        }

        // --- PREMIUM CHECK & EXPIRY NOTIFICATION ---
        try {
            const premMgr = require('../functions/premiumManager');
            const expiry = premMgr.checkExpiry(uid, gid);

            if (expiry.userExpired) {
                const invite = "https://discord.gg/orbit"; // Placeholder or config
                message.author.send({
                    embeds: [new EmbedBuilder().setColor('Red').setDescription(`Your Premium has expired. [Click here](${invite}) to renew.`)]
                }).catch(() => { });
            }

            if (expiry.guildExpired) {
                const invite = "https://discord.gg/orbit";
                message.channel.send({
                    embeds: [new EmbedBuilder().setColor('Red').setDescription(`This server's Premium subscription has expired. [Click here](${invite}) to renew.`)]
                }).then(m => setTimeout(() => m.delete().catch(() => { }), 5000));
            }

            // Command Premium Enforcement
            // If command requires premium (e.g. command.premium = true), check it.
            // Note: Orbit commands might not have .premium prop yet, but if they do:
            if (command.premium) {
                const isGuildPrem = premMgr.isGuildPremium(gid);
                const isUserPrem = premMgr.getPremiumUser(uid); // already validated/cleaned

                // Allow if Guild is Premium OR User is Premium?
                // Bitzxier usually allows if SERVER is premium.
                // Let's allow if either.
                if (!isGuildPrem && !isUserPrem && !client.config.owner.includes(uid)) {
                    const invite = "https://discord.gg/orbit";
                    return message.reply({
                        embeds: [new EmbedBuilder().setColor('Gold').setDescription(`This command requires **Premium**. [Click here](${invite}) to purchase.`)]
                    });
                }
            }
        } catch (e) { console.error('Premium check error:', e); }

        // Debug: log antinuke prefix invocations to help troubleshoot parsing
        if (commandName === 'antinuke') {
            try {

            } catch (e) {
                console.error('DEBUG: failed to log antinuke args', e);
            }
        }

        // New Logic: If command has executeMessage, use it for prefix commands
        if (typeof command.executeMessage === 'function') {
            try {
                return await command.executeMessage(message, args);
            } catch (error) {
                console.error(`Error in executeMessage for ${commandName}:`, error);
                return message.reply({ content: 'There was an error while executing the message command!' });
            }
        }

        // If command has no executeMessage, try to use the slash command handler (fallback)
        if (!command.data) {
            return message.reply('This command is not available for prefix usage.');
        }

        // --- Helper to Shim Interaction (Fallback) ---
        try {
            const commandData = command.data.toJSON ? command.data.toJSON() : command.data;
            const fakeInteraction = {
                user: message.author,
                member: message.member,
                guild: message.guild,
                channel: message.channel,
                client: client,
                createdTimestamp: message.createdTimestamp,

                // Helper methods
                reply: async (options) => {
                    const payload = typeof options === 'string' ? { content: options } : options;
                    // Handle ephemeral by sending a reply and deleting it after a delay (or DMing)
                    // But in message context, ephemeral doesn't technically exist. 
                    // We'll just reply normally.
                    return await message.reply(payload);
                },
                deferReply: async () => {
                    return await message.channel.sendTyping();
                },
                editReply: async (options) => {
                    // Since we don't have a real interaction hook, we can't edit the "Thinking" state easily 
                    // without tracking the sent message. using a simple send for now.
                    const payload = typeof options === 'string' ? { content: options } : options;
                    return await message.channel.send(payload);
                },
                followUp: async (options) => {
                    const payload = typeof options === 'string' ? { content: options } : options;
                    return await message.channel.send(payload);
                },

                // Options Parser (The Hard Part)
                options: {
                    getSubcommandGroup: (required = false) => {
                        // Check if command has groups
                        const groups = commandData.options?.filter(o => o.type === 2); // 2 = SubcommandGroup
                        if (groups && groups.length > 0) {
                            if (groups.some(g => g.name === args[0])) return args[0];
                        }
                        if (required) throw new Error('Subcommand group required but not found');
                        return null;
                    },
                    getSubcommand: (required = true) => {
                        // Logic depending on if there is a group
                        const groups = commandData.options?.filter(o => o.type === 2);
                        const subcommands = commandData.options?.filter(o => o.type === 1); // 1 = Subcommand

                        // Case 1: Group -> Subcommand
                        if (groups && groups.length > 0 && groups.some(g => g.name === args[0])) {
                            return args[1]; // Group is at index 0, subcommand at index 1
                        }

                        // Case 2: Just Subcommand (no group)
                        // If there are groups defined but args[0] matches a direct subcommand (rare but possible in mixed structure)
                        // OR if there are no groups defined
                        if (subcommands && subcommands.some(s => s.name === args[0])) {
                            return args[0];
                        }

                        if (required) {
                            // If required is true (default), we only return null if we really can't find it.
                            // But native behavior throws error. 
                            // However, for our mainrole check `getSubcommand(false)`, we want null.
                            // Wait, logic above returns args[0] or args[1] or undefined (implicit).
                            // If we fell through, it means not found.
                            return null;
                        }
                        return null;
                    },
                    getString: (name) => findOption(name, 'string'),
                    getUser: (name) => findOption(name, 'user'),
                    getMember: (name) => findOption(name, 'user'), // Same as user for message context usually
                    getChannel: (name) => findOption(name, 'channel'),
                    getRole: (name) => findOption(name, 'role'),
                    getInteger: (name) => findOption(name, 'integer'),
                    getNumber: (name) => findOption(name, 'number'),
                    getBoolean: (name) => findOption(name, 'boolean'),
                    getAttachment: (name) => findOption(name, 'attachment'),
                }
            };

            // Argument Mapping Helper
            function findOption(optName, type) {
                // 1. Determine structure (Group? Subcommand? Base?)
                let optionsList = commandData.options || [];
                let currentArgIndex = 0;

                const groupName = fakeInteraction.options.getSubcommandGroup(false);
                const subName = fakeInteraction.options.getSubcommand(false);

                if (groupName) {
                    const group = optionsList.find(o => o.name === groupName);
                    optionsList = group.options || [];
                    currentArgIndex++; // consume group arg
                }

                if (subName) {
                    const sub = optionsList.find(o => o.name === subName);
                    // Standard subcommand structure has options inside
                    optionsList = sub.options || [];
                    currentArgIndex++; // consume sub arg
                }

                // 2. Find the index of the requested option in the definition
                // We assume positional arguments match the order of defined options (required ones first ideally)
                // Filter out non-params? No, builders put parameters in order.
                const paramIndex = optionsList.findIndex(o => o.name === optName);

                if (paramIndex === -1) return null; // Option not found in definition

                const targetArgIndex = currentArgIndex + paramIndex;
                const rawArg = args[targetArgIndex];

                if (!rawArg) return null;

                // 3. Cast/Fetch type
                if (type === 'user') {
                    const id = rawArg.replace(/[<@!>]/g, '');
                    return message.guild.members.cache.get(id)?.user || null; // Return User object
                }
                if (type === 'channel') {
                    const id = rawArg.replace(/[<@#>]/g, '');
                    return message.guild.channels.cache.get(id) || null;
                }
                if (type === 'role') {
                    const id = rawArg.replace(/[<@&>]/g, '');
                    return message.guild.roles.cache.get(id) || null;
                }
                if (type === 'integer') {
                    return parseInt(rawArg);
                }
                if (type === 'number') {
                    return parseFloat(rawArg);
                }
                if (type === 'boolean') {
                    return rawArg === 'true' || rawArg === 'yes' || rawArg === 'on';
                }

                // string (or rest)
                return rawArg;
            }

            // Execute
            await command.execute(fakeInteraction);

        } catch (error) {
            console.error(error);
            await message.reply({ content: 'There was an error while executing this command!' });
        }
    }
};
