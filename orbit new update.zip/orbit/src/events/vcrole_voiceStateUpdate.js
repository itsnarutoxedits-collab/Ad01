const { Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../../data/vcrole.json');

function getData() {
    try {
        if (fs.existsSync(dataPath)) return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (e) { }
    return {};
}

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        // Check if user joined a channel (newState.channelId is set, oldState.channelId is null or different)
        if (!newState.channelId || newState.channelId === oldState.channelId) return;

        const guildId = newState.guild.id;
        const data = getData();
        const config = data[guildId];

        if (!config) return;

        const member = newState.member;
        const roleId = member.user.bot ? config.bot : config.human;

        if (roleId) {
            const role = newState.guild.roles.cache.get(roleId);
            if (role && !member.roles.cache.has(roleId)) {
                try {
                    await member.roles.add(role);
                    // console.log(`Assigned VC role ${role.name} to ${member.user.tag}`);
                } catch (e) {
                    console.error(`Failed to assign VC role in ${newState.guild.name}:`, e);
                }
            }
        }
    },
};
