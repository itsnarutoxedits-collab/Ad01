const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageDelete,
    async execute(message, client) {
        if (!message.guild || message.author?.bot) return;

        // Initialize snipes map if it doesn't exist
        if (!client.snipes) client.snipes = new Map();

        client.snipes.set(message.channel.id, {
            content: message.content,
            author: message.author,
            image: message.attachments.first() ? message.attachments.first().proxyURL : null,
            timestamp: new Date()
        });
    }
};
